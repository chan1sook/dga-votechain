import{Y as e}from"./entry.1f1a3be4.js";const s=()=>e("userId",()=>{});export{s as u};
