import{Y as s}from"./entry.1f1a3be4.js";const r=()=>s("permissions",()=>[]);export{r as u};
