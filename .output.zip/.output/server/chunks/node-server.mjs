globalThis._importMeta_=globalThis._importMeta_||{url:"file:///_entry.js",env:process.env};import 'node-fetch-native/polyfill';
import { Server as Server$1 } from 'node:http';
import { Server } from 'node:https';
import destr from 'destr';
import { defineEventHandler, handleCacheHeaders, createEvent, eventHandler, setHeaders, sendRedirect, proxyRequest, getRequestHeader, getRequestHeaders, setResponseHeader, createError, getCookie, setCookie, createApp, createRouter as createRouter$1, toNodeListener, fetchWithEvent, lazyEventHandler } from 'h3';
import { createFetch as createFetch$1, Headers } from 'ofetch';
import { createCall, createFetch } from 'unenv/runtime/fetch/index';
import { createHooks } from 'hookable';
import { snakeCase } from 'scule';
import { hash } from 'ohash';
import { parseURL, withoutBase, joinURL, withQuery, withLeadingSlash, withoutTrailingSlash } from 'ufo';
import { createStorage, prefixStorage } from 'unstorage';
import unstorage_47drivers_47redis from 'unstorage/drivers/redis';
import defu from 'defu';
import { toRouteMatcher, createRouter } from 'radix3';
import mongoose, { model, Schema } from 'mongoose';
import { promises } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'pathe';
import dayjs from 'dayjs';
import { nanoid } from 'nanoid';
import axios from 'axios';

const _runtimeConfig = {"app":{"baseURL":"/","buildAssetsDir":"/_nuxt/","cdnURL":""},"nitro":{"envPrefix":"NUXT_","routeRules":{"/__nuxt_error":{"cache":false},"/_nuxt/**":{"headers":{"cache-control":"public, max-age=2592000, immutable"}}}},"public":{"DID_API_URL":"https://connect.dga.or.th"},"MONGODB_URI":"mongodb://localhost:27017","DB_NAME":"dga_evote_test","DID_CLIENT_KEY":"c0a10258-6142-4257-8aea-c374e151bfe5","DID_CLIENT_SECRET":"MCqudBiP8EX","DID_VERIFY_CODE":"3e2727957a1bd9f47b11ff347fca362b6060941decb4","DID_LOGIN_CALLBACK":"https://e-vote.sensesiot.net/api/callback/login"};
const ENV_PREFIX = "NITRO_";
const ENV_PREFIX_ALT = _runtimeConfig.nitro.envPrefix ?? process.env.NITRO_ENV_PREFIX ?? "_";
const getEnv = (key) => {
  const envKey = snakeCase(key).toUpperCase();
  return destr(
    process.env[ENV_PREFIX + envKey] ?? process.env[ENV_PREFIX_ALT + envKey]
  );
};
function isObject(input) {
  return typeof input === "object" && !Array.isArray(input);
}
function overrideConfig(obj, parentKey = "") {
  for (const key in obj) {
    const subKey = parentKey ? `${parentKey}_${key}` : key;
    const envValue = getEnv(subKey);
    if (isObject(obj[key])) {
      if (isObject(envValue)) {
        obj[key] = { ...obj[key], ...envValue };
      }
      overrideConfig(obj[key], subKey);
    } else {
      obj[key] = envValue ?? obj[key];
    }
  }
}
overrideConfig(_runtimeConfig);
const config$1 = deepFreeze(_runtimeConfig);
const useRuntimeConfig = () => config$1;
function deepFreeze(object) {
  const propNames = Object.getOwnPropertyNames(object);
  for (const name of propNames) {
    const value = object[name];
    if (value && typeof value === "object") {
      deepFreeze(value);
    }
  }
  return Object.freeze(object);
}

const _assets = {

};

function normalizeKey(key) {
  if (!key) {
    return "";
  }
  return key.split("?")[0].replace(/[/\\]/g, ":").replace(/:+/g, ":").replace(/^:|:$/g, "");
}

const assets$1 = {
  getKeys() {
    return Promise.resolve(Object.keys(_assets))
  },
  hasItem (id) {
    id = normalizeKey(id);
    return Promise.resolve(id in _assets)
  },
  getItem (id) {
    id = normalizeKey(id);
    return Promise.resolve(_assets[id] ? _assets[id].import() : null)
  },
  getMeta (id) {
    id = normalizeKey(id);
    return Promise.resolve(_assets[id] ? _assets[id].meta : {})
  }
};

const storage = createStorage({});

const useStorage = () => storage;

storage.mount('/assets', assets$1);

storage.mount('session', unstorage_47drivers_47redis({"driver":"redis","url":"redis://localhost:6379/"}));

const defaultCacheOptions = {
  name: "_",
  base: "/cache",
  swr: true,
  maxAge: 1
};
function defineCachedFunction(fn, opts) {
  opts = { ...defaultCacheOptions, ...opts };
  const pending = {};
  const group = opts.group || "nitro";
  const name = opts.name || fn.name || "_";
  const integrity = hash([opts.integrity, fn, opts]);
  const validate = opts.validate || (() => true);
  async function get(key, resolver, shouldInvalidateCache) {
    const cacheKey = [opts.base, group, name, key + ".json"].filter(Boolean).join(":").replace(/:\/$/, ":index");
    const entry = await useStorage().getItem(cacheKey) || {};
    const ttl = (opts.maxAge ?? opts.maxAge ?? 0) * 1e3;
    if (ttl) {
      entry.expires = Date.now() + ttl;
    }
    const expired = shouldInvalidateCache || entry.integrity !== integrity || ttl && Date.now() - (entry.mtime || 0) > ttl || !validate(entry);
    const _resolve = async () => {
      const isPending = pending[key];
      if (!isPending) {
        if (entry.value !== void 0 && (opts.staleMaxAge || 0) >= 0) {
          entry.value = void 0;
          entry.integrity = void 0;
          entry.mtime = void 0;
          entry.expires = void 0;
        }
        pending[key] = Promise.resolve(resolver());
      }
      entry.value = await pending[key];
      if (!isPending) {
        entry.mtime = Date.now();
        entry.integrity = integrity;
        delete pending[key];
        if (validate(entry)) {
          useStorage().setItem(cacheKey, entry).catch((error) => console.error("[nitro] [cache]", error));
        }
      }
    };
    const _resolvePromise = expired ? _resolve() : Promise.resolve();
    if (opts.swr && entry.value) {
      _resolvePromise.catch(console.error);
      return entry;
    }
    return _resolvePromise.then(() => entry);
  }
  return async (...args) => {
    const shouldBypassCache = opts.shouldBypassCache?.(...args);
    if (shouldBypassCache) {
      return fn(...args);
    }
    const key = await (opts.getKey || getKey)(...args);
    const shouldInvalidateCache = opts.shouldInvalidateCache?.(...args);
    const entry = await get(key, () => fn(...args), shouldInvalidateCache);
    let value = entry.value;
    if (opts.transform) {
      value = await opts.transform(entry, ...args) || value;
    }
    return value;
  };
}
const cachedFunction = defineCachedFunction;
function getKey(...args) {
  return args.length > 0 ? hash(args, {}) : "";
}
function escapeKey(key) {
  return key.replace(/[^\dA-Za-z]/g, "");
}
function defineCachedEventHandler(handler, opts = defaultCacheOptions) {
  const _opts = {
    ...opts,
    getKey: async (event) => {
      const key = await opts.getKey?.(event);
      if (key) {
        return escapeKey(key);
      }
      const url = event.node.req.originalUrl || event.node.req.url;
      const friendlyName = escapeKey(decodeURI(parseURL(url).pathname)).slice(
        0,
        16
      );
      const urlHash = hash(url);
      return `${friendlyName}.${urlHash}`;
    },
    validate: (entry) => {
      if (entry.value.code >= 400) {
        return false;
      }
      if (entry.value.body === void 0) {
        return false;
      }
      return true;
    },
    group: opts.group || "nitro/handlers",
    integrity: [opts.integrity, handler]
  };
  const _cachedHandler = cachedFunction(
    async (incomingEvent) => {
      const reqProxy = cloneWithProxy(incomingEvent.node.req, { headers: {} });
      const resHeaders = {};
      let _resSendBody;
      const resProxy = cloneWithProxy(incomingEvent.node.res, {
        statusCode: 200,
        getHeader(name) {
          return resHeaders[name];
        },
        setHeader(name, value) {
          resHeaders[name] = value;
          return this;
        },
        getHeaderNames() {
          return Object.keys(resHeaders);
        },
        hasHeader(name) {
          return name in resHeaders;
        },
        removeHeader(name) {
          delete resHeaders[name];
        },
        getHeaders() {
          return resHeaders;
        },
        end(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2();
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return this;
        },
        write(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2();
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return this;
        },
        writeHead(statusCode, headers2) {
          this.statusCode = statusCode;
          if (headers2) {
            for (const header in headers2) {
              this.setHeader(header, headers2[header]);
            }
          }
          return this;
        }
      });
      const event = createEvent(reqProxy, resProxy);
      event.context = incomingEvent.context;
      const body = await handler(event) || _resSendBody;
      const headers = event.node.res.getHeaders();
      headers.etag = headers.Etag || headers.etag || `W/"${hash(body)}"`;
      headers["last-modified"] = headers["Last-Modified"] || headers["last-modified"] || (/* @__PURE__ */ new Date()).toUTCString();
      const cacheControl = [];
      if (opts.swr) {
        if (opts.maxAge) {
          cacheControl.push(`s-maxage=${opts.maxAge}`);
        }
        if (opts.staleMaxAge) {
          cacheControl.push(`stale-while-revalidate=${opts.staleMaxAge}`);
        } else {
          cacheControl.push("stale-while-revalidate");
        }
      } else if (opts.maxAge) {
        cacheControl.push(`max-age=${opts.maxAge}`);
      }
      if (cacheControl.length > 0) {
        headers["cache-control"] = cacheControl.join(", ");
      }
      const cacheEntry = {
        code: event.node.res.statusCode,
        headers,
        body
      };
      return cacheEntry;
    },
    _opts
  );
  return defineEventHandler(async (event) => {
    if (opts.headersOnly) {
      if (handleCacheHeaders(event, { maxAge: opts.maxAge })) {
        return;
      }
      return handler(event);
    }
    const response = await _cachedHandler(event);
    if (event.node.res.headersSent || event.node.res.writableEnded) {
      return response.body;
    }
    if (handleCacheHeaders(event, {
      modifiedTime: new Date(response.headers["last-modified"]),
      etag: response.headers.etag,
      maxAge: opts.maxAge
    })) {
      return;
    }
    event.node.res.statusCode = response.code;
    for (const name in response.headers) {
      event.node.res.setHeader(name, response.headers[name]);
    }
    return response.body;
  });
}
function cloneWithProxy(obj, overrides) {
  return new Proxy(obj, {
    get(target, property, receiver) {
      if (property in overrides) {
        return overrides[property];
      }
      return Reflect.get(target, property, receiver);
    },
    set(target, property, value, receiver) {
      if (property in overrides) {
        overrides[property] = value;
        return true;
      }
      return Reflect.set(target, property, value, receiver);
    }
  });
}
const cachedEventHandler = defineCachedEventHandler;

const config = useRuntimeConfig();
const _routeRulesMatcher = toRouteMatcher(
  createRouter({ routes: config.nitro.routeRules })
);
function createRouteRulesHandler() {
  return eventHandler((event) => {
    const routeRules = getRouteRules(event);
    if (routeRules.headers) {
      setHeaders(event, routeRules.headers);
    }
    if (routeRules.redirect) {
      return sendRedirect(
        event,
        routeRules.redirect.to,
        routeRules.redirect.statusCode
      );
    }
    if (routeRules.proxy) {
      let target = routeRules.proxy.to;
      if (target.endsWith("/**")) {
        let targetPath = event.path;
        const strpBase = routeRules.proxy._proxyStripBase;
        if (strpBase) {
          targetPath = withoutBase(targetPath, strpBase);
        }
        target = joinURL(target.slice(0, -3), targetPath);
      }
      return proxyRequest(event, target, {
        fetch: $fetch.raw,
        ...routeRules.proxy
      });
    }
  });
}
function getRouteRules(event) {
  event.context._nitro = event.context._nitro || {};
  if (!event.context._nitro.routeRules) {
    const path = new URL(event.node.req.url, "http://localhost").pathname;
    event.context._nitro.routeRules = getRouteRulesForPath(
      withoutBase(path, useRuntimeConfig().app.baseURL)
    );
  }
  return event.context._nitro.routeRules;
}
function getRouteRulesForPath(path) {
  return defu({}, ..._routeRulesMatcher.matchAll(path).reverse());
}

function defineNitroPlugin(def) {
  return def;
}

function isVoterRole(role) {
  return role !== "guest";
}
function isAdminRole(role) {
  return !["guest", "voter"].includes(role);
}
function isDeveloperRole(role) {
  return role === "developer";
}

function legacyRoleToPermissionsExcludes(role) {
  switch (role) {
    case "voter":
      return ["access-pages:user", "request-permissions", "vote-topic", "request-topic"];
    case "admin":
      return [
        "access-pages:admin",
        "create-topic",
        "change-topic",
        "create-news",
        "change-news",
        "change-permissions:basic"
      ];
    case "developer":
      return ["access-pages:developer", "change-permissions:advance"];
    default:
      return [];
  }
}
function legacyRoleToPermissions(role) {
  const permissions = [];
  if (isVoterRole(role)) {
    permissions.push(...legacyRoleToPermissionsExcludes("voter"));
  }
  if (isAdminRole(role)) {
    permissions.push(...legacyRoleToPermissionsExcludes("admin"));
  }
  if (isDeveloperRole(role)) {
    permissions.push(...legacyRoleToPermissionsExcludes("developer"));
  }
  return permissions;
}
function getAdvancePermissions() {
  return combinePermissions(
    legacyRoleToPermissionsExcludes("admin"),
    ...legacyRoleToPermissionsExcludes("developer")
  );
}
function isContainsAdvancePermissions(...selections) {
  return removePermissions(selections, ...getAdvancePermissions()).length === 0;
}
function checkPermissionNeeds(availables, ...needs) {
  const needsArrs = removePermissions(needs, ...availables);
  return needsArrs.length === 0;
}
function checkPermissionSelections(availables, ...selections) {
  for (const permission of availables) {
    if (selections.includes(permission)) {
      return true;
    }
  }
  return false;
}
function combinePermissions(a, ...others) {
  const result = a.slice(0);
  for (const permission of others) {
    if (!result.includes(permission)) {
      result.push(permission);
    }
  }
  return result;
}
function removePermissions(target, ...removed) {
  const result = target.slice(0);
  for (const permission of removed) {
    const targetIndex = result.indexOf(permission);
    if (targetIndex !== -1) {
      result.splice(targetIndex, 1);
    }
  }
  return result;
}

const schema = new Schema({
  userid: {
    type: String,
    required: true
  },
  role: {
    type: String
  },
  permissions: [String]
}, { timestamps: true });
schema.static("ensureUserData", function ensureUserData(userid) {
  return this.findOneAndUpdate({
    userid
  }, {
    $setOnInsert: {
      userid,
      permissions: legacyRoleToPermissions("voter")
    }
  }, {
    new: true,
    upsert: true
  });
});
const UserModel = model("user", schema);

const _19LuD90F8y = defineNitroPlugin(async (nitroApp) => {
  console.log("[Config] View Config");
  const { MONGODB_URI, DB_NAME, DID_LOGIN_CALLBACK, public: { DID_API_URL } } = useRuntimeConfig();
  console.log(`MONGODB_URI: ${MONGODB_URI}`);
  console.log(`DB_NAME: ${DB_NAME}`);
  console.log(`DID_API_URL: ${DID_API_URL}`);
  console.log(`DID_LOGIN_CALLBACK: ${DID_LOGIN_CALLBACK}`);
  console.log("[MongoDB] Init");
  await mongoose.connect(`${MONGODB_URI}/${DB_NAME}`);
  console.log("[MongoDB] Connected!");
  console.log("[Migration] Permissions Migration Start");
  const allUsers = await UserModel.find({ role: { $exists: true } });
  for (const user of allUsers) {
    if (user.role) {
      user.permissions = legacyRoleToPermissions(user.role);
      user.role = void 0;
    }
  }
  const { modifiedCount, matchedCount } = await UserModel.bulkSave(allUsers);
  console.log(`[Migration] Match: ${matchedCount} / Updated: ${modifiedCount}`);
  console.log("[Migration] Permissions Migration Completed");
});

const plugins = [
  _19LuD90F8y
];

function hasReqHeader(event, name, includes) {
  const value = getRequestHeader(event, name);
  return value && typeof value === "string" && value.toLowerCase().includes(includes);
}
function isJsonRequest(event) {
  return hasReqHeader(event, "accept", "application/json") || hasReqHeader(event, "user-agent", "curl/") || hasReqHeader(event, "user-agent", "httpie/") || hasReqHeader(event, "sec-fetch-mode", "cors") || event.path.startsWith("/api/") || event.path.endsWith(".json");
}
function normalizeError(error) {
  const cwd = typeof process.cwd === "function" ? process.cwd() : "/";
  const stack = (error.stack || "").split("\n").splice(1).filter((line) => line.includes("at ")).map((line) => {
    const text = line.replace(cwd + "/", "./").replace("webpack:/", "").replace("file://", "").trim();
    return {
      text,
      internal: line.includes("node_modules") && !line.includes(".cache") || line.includes("internal") || line.includes("new Promise")
    };
  });
  const statusCode = error.statusCode || 500;
  const statusMessage = error.statusMessage ?? (statusCode === 404 ? "Not Found" : "");
  const message = error.message || error.toString();
  return {
    stack,
    statusCode,
    statusMessage,
    message
  };
}

const errorHandler = (async function errorhandler(error, event) {
  const { stack, statusCode, statusMessage, message } = normalizeError(error);
  const errorObject = {
    url: event.node.req.url,
    statusCode,
    statusMessage,
    message,
    stack: "",
    data: error.data
  };
  event.node.res.statusCode = errorObject.statusCode !== 200 && errorObject.statusCode || 500;
  if (errorObject.statusMessage) {
    event.node.res.statusMessage = errorObject.statusMessage;
  }
  if (error.unhandled || error.fatal) {
    const tags = [
      "[nuxt]",
      "[request error]",
      error.unhandled && "[unhandled]",
      error.fatal && "[fatal]",
      Number(errorObject.statusCode) !== 200 && `[${errorObject.statusCode}]`
    ].filter(Boolean).join(" ");
    console.error(tags, errorObject.message + "\n" + stack.map((l) => "  " + l.text).join("  \n"));
  }
  if (isJsonRequest(event)) {
    event.node.res.setHeader("Content-Type", "application/json");
    event.node.res.end(JSON.stringify(errorObject));
    return;
  }
  const isErrorPage = event.node.req.url?.startsWith("/__nuxt_error");
  const res = !isErrorPage ? await useNitroApp().localFetch(withQuery(joinURL(useRuntimeConfig().app.baseURL, "/__nuxt_error"), errorObject), {
    headers: getRequestHeaders(event),
    redirect: "manual"
  }).catch(() => null) : null;
  if (!res) {
    const { template } = await import('./error-500.mjs');
    event.node.res.setHeader("Content-Type", "text/html;charset=UTF-8");
    event.node.res.end(template(errorObject));
    return;
  }
  for (const [header, value] of res.headers.entries()) {
    setResponseHeader(event, header, value);
  }
  if (res.status && res.status !== 200) {
    event.node.res.statusCode = res.status;
  }
  if (res.statusText) {
    event.node.res.statusMessage = res.statusText;
  }
  event.node.res.end(await res.text());
});

const assets = {
  "/favicon.ico": {
    "type": "image/vnd.microsoft.icon",
    "etag": "\"10be-n8egyE9tcb7sKGr/pYCaQ4uWqxI\"",
    "mtime": "2023-02-28T16:04:07.000Z",
    "size": 4286,
    "path": "../public/favicon.ico"
  },
  "/_nuxt/admin.39175974.js": {
    "type": "application/javascript",
    "etag": "\"17cd-1fr1fMr3yTsqKhVlsv+W1C+/SgY\"",
    "mtime": "2023-03-13T13:11:17.651Z",
    "size": 6093,
    "path": "../public/_nuxt/admin.39175974.js"
  },
  "/_nuxt/approve.6e101083.js": {
    "type": "application/javascript",
    "etag": "\"bfe-yy5hXEvaKSZu0npxkhrEGug3vBU\"",
    "mtime": "2023-03-13T13:11:17.645Z",
    "size": 3070,
    "path": "../public/_nuxt/approve.6e101083.js"
  },
  "/_nuxt/auth-admin.e66ad3ce.js": {
    "type": "application/javascript",
    "etag": "\"25d-sYWvQUYIr8I5Ihn8mb6+iT/2Ips\"",
    "mtime": "2023-03-13T13:11:17.645Z",
    "size": 605,
    "path": "../public/_nuxt/auth-admin.e66ad3ce.js"
  },
  "/_nuxt/auth-dev.bdd5f21c.js": {
    "type": "application/javascript",
    "etag": "\"261-7fwotoSvRMYDSgg/+5CO+5a5Mx4\"",
    "mtime": "2023-03-13T13:11:17.645Z",
    "size": 609,
    "path": "../public/_nuxt/auth-dev.bdd5f21c.js"
  },
  "/_nuxt/auth-guest.58b704bb.js": {
    "type": "application/javascript",
    "etag": "\"22e-xxZ0b03lZgKe/X5pKUn5G+In/Ns\"",
    "mtime": "2023-03-13T13:11:17.648Z",
    "size": 558,
    "path": "../public/_nuxt/auth-guest.58b704bb.js"
  },
  "/_nuxt/auth-voter.ef6cbf66.js": {
    "type": "application/javascript",
    "etag": "\"206-f/x6ibU0rSiVc6i+M16q0Mx5ZJk\"",
    "mtime": "2023-03-13T13:11:17.650Z",
    "size": 518,
    "path": "../public/_nuxt/auth-voter.ef6cbf66.js"
  },
  "/_nuxt/BasicCard.06fc7be8.js": {
    "type": "application/javascript",
    "etag": "\"212-7OZ/V8bjsP2pVoc6H5pv89xWs5w\"",
    "mtime": "2023-03-13T13:11:17.651Z",
    "size": 530,
    "path": "../public/_nuxt/BasicCard.06fc7be8.js"
  },
  "/_nuxt/BasicCard.b00ab4e8.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"897-osSkArc3EeAZFzOEkg90Eilv2bc\"",
    "mtime": "2023-03-13T13:11:17.645Z",
    "size": 2199,
    "path": "../public/_nuxt/BasicCard.b00ab4e8.css"
  },
  "/_nuxt/BasicListItem.3bdc0d73.js": {
    "type": "application/javascript",
    "etag": "\"32d-6kkUZIeh4RNtYKDuYQ90Z5eC55k\"",
    "mtime": "2023-03-13T13:11:17.652Z",
    "size": 813,
    "path": "../public/_nuxt/BasicListItem.3bdc0d73.js"
  },
  "/_nuxt/BasicListItem.bb203c09.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"466-8G2udaWT8mgtZCxykkkPQSA49sM\"",
    "mtime": "2023-03-13T13:11:17.645Z",
    "size": 1126,
    "path": "../public/_nuxt/BasicListItem.bb203c09.css"
  },
  "/_nuxt/create.2d086bff.js": {
    "type": "application/javascript",
    "etag": "\"1674-HeB0DB1+cD9A5YgLYFfWcLGHlPU\"",
    "mtime": "2023-03-13T13:11:17.650Z",
    "size": 5748,
    "path": "../public/_nuxt/create.2d086bff.js"
  },
  "/_nuxt/create.9765c711.js": {
    "type": "application/javascript",
    "etag": "\"10a1-jLScRONgxy1S5ISlnS77SKOSM2Y\"",
    "mtime": "2023-03-13T13:11:17.647Z",
    "size": 4257,
    "path": "../public/_nuxt/create.9765c711.js"
  },
  "/_nuxt/DetailCard.5956d7f2.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"87d-VvVDyXFO5fiHes4hVagzF+PQSBk\"",
    "mtime": "2023-03-13T13:11:17.645Z",
    "size": 2173,
    "path": "../public/_nuxt/DetailCard.5956d7f2.css"
  },
  "/_nuxt/DetailCard.f95db50b.js": {
    "type": "application/javascript",
    "etag": "\"245-xLW/tvLpjg/JJz3bpr5BHRW+39E\"",
    "mtime": "2023-03-13T13:11:17.651Z",
    "size": 581,
    "path": "../public/_nuxt/DetailCard.f95db50b.js"
  },
  "/_nuxt/developer.6153a9e6.js": {
    "type": "application/javascript",
    "etag": "\"10d1-09Lc+5PZq8k11F0W0s5ofnMzo6g\"",
    "mtime": "2023-03-13T13:11:17.651Z",
    "size": 4305,
    "path": "../public/_nuxt/developer.6153a9e6.js"
  },
  "/_nuxt/entry.1f1a3be4.js": {
    "type": "application/javascript",
    "etag": "\"257f6-J1fkE+j4+bqMj2oUTXrhqVsk/HI\"",
    "mtime": "2023-03-13T13:11:17.652Z",
    "size": 153590,
    "path": "../public/_nuxt/entry.1f1a3be4.js"
  },
  "/_nuxt/entry.7fc7b232.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"3701-2tnkcmNjQs7StL8WILz2p4LZ0Ag\"",
    "mtime": "2023-03-13T13:11:17.645Z",
    "size": 14081,
    "path": "../public/_nuxt/entry.7fc7b232.css"
  },
  "/_nuxt/error-component.4338fec9.js": {
    "type": "application/javascript",
    "etag": "\"442-GTBy7N4qIfI1Hje2VIJ9kMdqg5c\"",
    "mtime": "2023-03-13T13:11:17.645Z",
    "size": 1090,
    "path": "../public/_nuxt/error-component.4338fec9.js"
  },
  "/_nuxt/error-component.a34db7f6.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"b9-QmL7Jv8BR1TD/jPtZxbDgi1i7Pk\"",
    "mtime": "2023-03-13T13:11:17.645Z",
    "size": 185,
    "path": "../public/_nuxt/error-component.a34db7f6.css"
  },
  "/_nuxt/fetch.035cb748.js": {
    "type": "application/javascript",
    "etag": "\"2bce-rvrA53UBxYSvY97fOeF+O7bYY+M\"",
    "mtime": "2023-03-13T13:11:17.651Z",
    "size": 11214,
    "path": "../public/_nuxt/fetch.035cb748.js"
  },
  "/_nuxt/index.66066b73.js": {
    "type": "application/javascript",
    "etag": "\"1cb4-d6T7cszQJlZNjsFCnvPRf35igso\"",
    "mtime": "2023-03-13T13:11:17.641Z",
    "size": 7348,
    "path": "../public/_nuxt/index.66066b73.js"
  },
  "/_nuxt/login.124534d5.js": {
    "type": "application/javascript",
    "etag": "\"52b-A/2X2VWDubEI7iWzb5EFKP5iEYc\"",
    "mtime": "2023-03-13T13:11:17.650Z",
    "size": 1323,
    "path": "../public/_nuxt/login.124534d5.js"
  },
  "/_nuxt/MaterialIcon.88d58c50.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"6c-nl+LbcfxJrf19454MP7+pDPD15w\"",
    "mtime": "2023-03-13T13:11:17.645Z",
    "size": 108,
    "path": "../public/_nuxt/MaterialIcon.88d58c50.css"
  },
  "/_nuxt/MaterialIcon.c16f6bf8.js": {
    "type": "application/javascript",
    "etag": "\"148-M4OzKMvyA86eiabIhIfi6YcabDw\"",
    "mtime": "2023-03-13T13:11:17.651Z",
    "size": 328,
    "path": "../public/_nuxt/MaterialIcon.c16f6bf8.js"
  },
  "/_nuxt/news.2dced499.js": {
    "type": "application/javascript",
    "etag": "\"358-tYVhvNCJm3u12YRUMu8rjuEr5wk\"",
    "mtime": "2023-03-13T13:11:17.650Z",
    "size": 856,
    "path": "../public/_nuxt/news.2dced499.js"
  },
  "/_nuxt/nuxt-link.8943ed35.js": {
    "type": "application/javascript",
    "etag": "\"f42-8Rj2YQuPaOOpleZyKJFbU+x/Yds\"",
    "mtime": "2023-03-13T13:11:17.651Z",
    "size": 3906,
    "path": "../public/_nuxt/nuxt-link.8943ed35.js"
  },
  "/_nuxt/permissions.9caf66cc.js": {
    "type": "application/javascript",
    "etag": "\"5cd-zr+UWPAzF8fJQl3MFO+e9tgTVS8\"",
    "mtime": "2023-03-13T13:11:17.645Z",
    "size": 1485,
    "path": "../public/_nuxt/permissions.9caf66cc.js"
  },
  "/_nuxt/request.99133854.js": {
    "type": "application/javascript",
    "etag": "\"b2a-ryJKHhzOMBbZvs14g4fv591J8tA\"",
    "mtime": "2023-03-13T13:11:17.645Z",
    "size": 2858,
    "path": "../public/_nuxt/request.99133854.js"
  },
  "/_nuxt/request.c92999a3.js": {
    "type": "application/javascript",
    "etag": "\"1689-ZHbMJec/H5EBWWoWcTCCU/P5G0Q\"",
    "mtime": "2023-03-13T13:11:17.650Z",
    "size": 5769,
    "path": "../public/_nuxt/request.c92999a3.js"
  },
  "/_nuxt/topic.18f68b32.js": {
    "type": "application/javascript",
    "etag": "\"456-HnZ169/ik99OARoTpTBfaM3Vo8I\"",
    "mtime": "2023-03-13T13:11:17.645Z",
    "size": 1110,
    "path": "../public/_nuxt/topic.18f68b32.js"
  },
  "/_nuxt/usePermissions.dd9a085b.js": {
    "type": "application/javascript",
    "etag": "\"5c-0WwtQnaTKtgw9s+Qdpsb6X1GFvo\"",
    "mtime": "2023-03-13T13:11:17.645Z",
    "size": 92,
    "path": "../public/_nuxt/usePermissions.dd9a085b.js"
  },
  "/_nuxt/useUserId.cde1cac3.js": {
    "type": "application/javascript",
    "etag": "\"57-EDSFiXsFRXv+7qlgbHWY1VQ/tl4\"",
    "mtime": "2023-03-13T13:11:17.647Z",
    "size": 87,
    "path": "../public/_nuxt/useUserId.cde1cac3.js"
  },
  "/_nuxt/_id_.36f4e13c.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"7fc-jPktO2/qvtPE+MBhA84xgnz+I3s\"",
    "mtime": "2023-03-13T13:11:17.645Z",
    "size": 2044,
    "path": "../public/_nuxt/_id_.36f4e13c.css"
  },
  "/_nuxt/_id_.3f8e9e75.js": {
    "type": "application/javascript",
    "etag": "\"126e-oZYxHYZ41B/OB+Tjk/DrwssvuNE\"",
    "mtime": "2023-03-13T13:11:17.651Z",
    "size": 4718,
    "path": "../public/_nuxt/_id_.3f8e9e75.js"
  },
  "/_nuxt/_id_.6b61a7b0.js": {
    "type": "application/javascript",
    "etag": "\"a78-AZf7s5SVw6CX7CdP6QYpnrRdfqQ\"",
    "mtime": "2023-03-13T13:11:17.645Z",
    "size": 2680,
    "path": "../public/_nuxt/_id_.6b61a7b0.js"
  },
  "/_nuxt/_id_.74aeef9b.js": {
    "type": "application/javascript",
    "etag": "\"1075-FJcGVNB+l0lya+dHSbWMHj0MJLc\"",
    "mtime": "2023-03-13T13:11:17.650Z",
    "size": 4213,
    "path": "../public/_nuxt/_id_.74aeef9b.js"
  },
  "/_nuxt/_id_.847d3e67.js": {
    "type": "application/javascript",
    "etag": "\"1866-2LVTMcj4Mv93nYmA2xGLzze8feU\"",
    "mtime": "2023-03-13T13:11:17.651Z",
    "size": 6246,
    "path": "../public/_nuxt/_id_.847d3e67.js"
  },
  "/_nuxt/_id_.9dd470a7.js": {
    "type": "application/javascript",
    "etag": "\"141b-cIY58Pvl0ck0o9wDppJ/qBJliRU\"",
    "mtime": "2023-03-13T13:11:17.652Z",
    "size": 5147,
    "path": "../public/_nuxt/_id_.9dd470a7.js"
  },
  "/_nuxt/_id_.a3b625bc.js": {
    "type": "application/javascript",
    "etag": "\"8bf-9cBqsEUSi/oTjB0hSGL/6wObyVE\"",
    "mtime": "2023-03-13T13:11:17.651Z",
    "size": 2239,
    "path": "../public/_nuxt/_id_.a3b625bc.js"
  },
  "/_nuxt/_id_.c2712f83.js": {
    "type": "application/javascript",
    "etag": "\"7b9-L+/z8sYYcWPXHYEGU98sMyqQlUM\"",
    "mtime": "2023-03-13T13:11:17.645Z",
    "size": 1977,
    "path": "../public/_nuxt/_id_.c2712f83.js"
  },
  "/_nuxt/_plugin-vue_export-helper.c27b6911.js": {
    "type": "application/javascript",
    "etag": "\"5b-eFCz/UrraTh721pgAl0VxBNR1es\"",
    "mtime": "2023-03-13T13:11:17.650Z",
    "size": 91,
    "path": "../public/_nuxt/_plugin-vue_export-helper.c27b6911.js"
  }
};

function readAsset (id) {
  const serverDir = dirname(fileURLToPath(globalThis._importMeta_.url));
  return promises.readFile(resolve(serverDir, assets[id].path))
}

const publicAssetBases = {"/_nuxt":{"maxAge":2592000}};

function isPublicAssetURL(id = '') {
  if (assets[id]) {
    return true
  }
  for (const base in publicAssetBases) {
    if (id.startsWith(base)) { return true }
  }
  return false
}

function getAsset (id) {
  return assets[id]
}

const METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
const EncodingMap = { gzip: ".gz", br: ".br" };
const _f4b49z = eventHandler((event) => {
  if (event.node.req.method && !METHODS.has(event.node.req.method)) {
    return;
  }
  let id = decodeURIComponent(
    withLeadingSlash(
      withoutTrailingSlash(parseURL(event.node.req.url).pathname)
    )
  );
  let asset;
  const encodingHeader = String(
    event.node.req.headers["accept-encoding"] || ""
  );
  const encodings = [
    ...encodingHeader.split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(),
    ""
  ];
  if (encodings.length > 1) {
    event.node.res.setHeader("Vary", "Accept-Encoding");
  }
  for (const encoding of encodings) {
    for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
      const _asset = getAsset(_id);
      if (_asset) {
        asset = _asset;
        id = _id;
        break;
      }
    }
  }
  if (!asset) {
    if (isPublicAssetURL(id)) {
      event.node.res.removeHeader("cache-control");
      throw createError({
        statusMessage: "Cannot find static asset " + id,
        statusCode: 404
      });
    }
    return;
  }
  const ifNotMatch = event.node.req.headers["if-none-match"] === asset.etag;
  if (ifNotMatch) {
    event.node.res.statusCode = 304;
    event.node.res.end();
    return;
  }
  const ifModifiedSinceH = event.node.req.headers["if-modified-since"];
  if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= new Date(asset.mtime)) {
    event.node.res.statusCode = 304;
    event.node.res.end();
    return;
  }
  if (asset.type && !event.node.res.getHeader("Content-Type")) {
    event.node.res.setHeader("Content-Type", asset.type);
  }
  if (asset.etag && !event.node.res.getHeader("ETag")) {
    event.node.res.setHeader("ETag", asset.etag);
  }
  if (asset.mtime && !event.node.res.getHeader("Last-Modified")) {
    event.node.res.setHeader("Last-Modified", asset.mtime);
  }
  if (asset.encoding && !event.node.res.getHeader("Content-Encoding")) {
    event.node.res.setHeader("Content-Encoding", asset.encoding);
  }
  if (asset.size > 0 && !event.node.res.getHeader("Content-Length")) {
    event.node.res.setHeader("Content-Length", asset.size);
  }
  return readAsset(id);
});

var __accessCheck = (obj, member, msg) => {
  if (!member.has(obj))
    throw TypeError("Cannot " + msg);
};
var __privateGet = (obj, member, getter) => {
  __accessCheck(obj, member, "read from private field");
  return getter ? getter.call(obj) : member.get(obj);
};
var __privateAdd = (obj, member, value) => {
  if (member.has(obj))
    throw TypeError("Cannot add the same private member more than once");
  member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
};
var __privateSet = (obj, member, value, setter) => {
  __accessCheck(obj, member, "write to private field");
  setter ? setter.call(obj, value) : member.set(obj, value);
  return value;
};
var _sid, _storage;
class SessionHandler {
  constructor(sid, sessionStorage) {
    __privateAdd(this, _sid, void 0);
    __privateAdd(this, _storage, void 0);
    __privateSet(this, _sid, sid);
    __privateSet(this, _storage, sessionStorage);
  }
  get sid() {
    return __privateGet(this, _sid);
  }
  async get(key) {
    const data = await this.getAll();
    return data[key];
  }
  async getAll() {
    const data = await __privateGet(this, _storage).getItem(__privateGet(this, _sid));
    if (!data || typeof data !== "object") {
      return {};
    }
    return data;
  }
  async set(key, value) {
    if (key === "sid") {
      throw new Error("Reserved key");
    }
    const data = await this.getAll();
    data[key] = value;
    return __privateGet(this, _storage).setItem(__privateGet(this, _sid), data);
  }
  async unset(key) {
    if (key === "sid") {
      throw new Error("Reserved key");
    }
    const data = await this.getAll();
    delete data[key];
    return __privateGet(this, _storage).setItem(__privateGet(this, _sid), data);
  }
  async clear() {
    return __privateGet(this, _storage).setItem(__privateGet(this, _sid), {
      sid: __privateGet(this, _sid)
    });
  }
}
_sid = new WeakMap();
_storage = new WeakMap();

async function authorizationCodeDigitalID(code, { DID_API_URL, DID_CLIENT_KEY, DID_LOGIN_CALLBACK, DID_VERIFY_CODE }) {
  const urlParams = new URLSearchParams();
  urlParams.set("grant_type", "authorization_code");
  urlParams.set("code", code);
  urlParams.set("redirect_uri", DID_LOGIN_CALLBACK);
  urlParams.set("code_verifier", DID_VERIFY_CODE);
  urlParams.set("client_id", DID_CLIENT_KEY);
  const url = new URL("/connect/token", DID_API_URL);
  const { data } = await axios.post(url.toString(), urlParams, {
    headers: {
      "Content-Type": "application/x-www-form-urlencoded"
    }
  });
  return data;
}
async function getUserInfoDigitalID(accessToken, { DID_API_URL }) {
  const url = new URL("/connect/userinfo", DID_API_URL);
  const { data } = await axios.get(url.toString(), {
    headers: {
      "Authorization": `Bearer ${accessToken}`
    }
  });
  return data;
}

const _nM8N81 = defineEventHandler(async (event) => {
  let sid = getCookie(event, "sid");
  const storage = useStorage();
  const sessionStorage = prefixStorage(storage, "session");
  const sessionExpired = dayjs().add(30, "minute").toDate();
  if (!sid) {
    sid = nanoid(32);
    await sessionStorage.setItem(sid, {
      sid
    });
  }
  setCookie(event, "sid", sid, {
    httpOnly: true,
    secure: true,
    sameSite: "lax",
    expires: sessionExpired
  });
  event.context.session = new SessionHandler(sid, sessionStorage);
  const userData = await event.context.session.get("userData");
  const { public: { DID_API_URL } } = useRuntimeConfig();
  if (userData) {
    try {
      const [{ permissions, createdAt, updatedAt }, digitalIdUserInfo] = await Promise.all([
        UserModel.ensureUserData(userData.userid),
        await getUserInfoDigitalID(userData.accessToken, { DID_API_URL })
      ]);
      if (digitalIdUserInfo.user_id !== userData.userid) {
        throw new Error("Mismatch userid");
      }
      event.context.userData = {
        userid: userData.userid,
        accessToken: userData.accessToken,
        idToken: userData.idToken,
        digitalIdUserInfo,
        permissions,
        createdAt,
        updatedAt
      };
    } catch (err) {
      await event.context.session.unset("userData");
    }
  }
});

const _lazy_chYYIA = () => import('./vote.post.mjs');
const _lazy_yKDLyu = () => import('./_id_.get.mjs');
const _lazy_VOHlQ0 = () => import('./txchain.get.mjs');
const _lazy_VwMs7H = () => import('./topics.get.mjs');
const _lazy_2RqgKa = () => import('./_id_.get2.mjs');
const _lazy_nEOdJG = () => import('./_id_.get3.mjs');
const _lazy_EUMiVJ = () => import('./_id_.post.mjs');
const _lazy_cPC6ug = () => import('./create.post.mjs');
const _lazy_6Y694L = () => import('./session.get.mjs');
const _lazy_2TbLyf = () => import('./_id_.post2.mjs');
const _lazy_kAkai8 = () => import('./lists.get.mjs');
const _lazy_F5pnBE = () => import('./create.post2.mjs');
const _lazy_CCKIWo = () => import('./_id_.post3.mjs');
const _lazy_bhkhmY = () => import('./_id_.post4.mjs');
const _lazy_A5I3V1 = () => import('./_id_.get4.mjs');
const _lazy_nqKO4m = () => import('./news.get.mjs');
const _lazy_YAQjhY = () => import('./_id_.post5.mjs');
const _lazy_pWdrEg = () => import('./create.post3.mjs');
const _lazy_ATyGaK = () => import('./logout.get.mjs');
const _lazy_BFKKzT = () => import('./login.get.mjs');
const _lazy_A93wj9 = () => import('./logout.get2.mjs');
const _lazy_hpiyMT = () => import('./login.get2.mjs');
const _lazy_GQw9b6 = () => import('./renderer.mjs');

const handlers = [
  { route: '', handler: _f4b49z, lazy: false, middleware: true, method: undefined },
  { route: '', handler: _nM8N81, lazy: false, middleware: true, method: undefined },
  { route: '/api/vote', handler: _lazy_chYYIA, lazy: true, middleware: false, method: "post" },
  { route: '/api/tx/:id', handler: _lazy_yKDLyu, lazy: true, middleware: false, method: "get" },
  { route: '/api/txchain', handler: _lazy_VOHlQ0, lazy: true, middleware: false, method: "get" },
  { route: '/api/topics', handler: _lazy_VwMs7H, lazy: true, middleware: false, method: "get" },
  { route: '/api/topic/result/:id', handler: _lazy_2RqgKa, lazy: true, middleware: false, method: "get" },
  { route: '/api/topic/info/:id', handler: _lazy_nEOdJG, lazy: true, middleware: false, method: "get" },
  { route: '/api/topic/edit/:id', handler: _lazy_EUMiVJ, lazy: true, middleware: false, method: "post" },
  { route: '/api/topic/create', handler: _lazy_cPC6ug, lazy: true, middleware: false, method: "post" },
  { route: '/api/session', handler: _lazy_6Y694L, lazy: true, middleware: false, method: "get" },
  { route: '/api/permissions/withdraw/:id', handler: _lazy_2TbLyf, lazy: true, middleware: false, method: "post" },
  { route: '/api/permissions/request/lists', handler: _lazy_kAkai8, lazy: true, middleware: false, method: "get" },
  { route: '/api/permissions/request/create', handler: _lazy_F5pnBE, lazy: true, middleware: false, method: "post" },
  { route: '/api/permissions/approve/:id', handler: _lazy_CCKIWo, lazy: true, middleware: false, method: "post" },
  { route: '/api/permissions/add/:id', handler: _lazy_bhkhmY, lazy: true, middleware: false, method: "post" },
  { route: '/api/news/info/:id', handler: _lazy_A5I3V1, lazy: true, middleware: false, method: "get" },
  { route: '/api/news', handler: _lazy_nqKO4m, lazy: true, middleware: false, method: "get" },
  { route: '/api/news/edit/:id', handler: _lazy_YAQjhY, lazy: true, middleware: false, method: "post" },
  { route: '/api/news/create', handler: _lazy_pWdrEg, lazy: true, middleware: false, method: "post" },
  { route: '/api/logout', handler: _lazy_ATyGaK, lazy: true, middleware: false, method: "get" },
  { route: '/api/login', handler: _lazy_BFKKzT, lazy: true, middleware: false, method: "get" },
  { route: '/api/callback/logout', handler: _lazy_A93wj9, lazy: true, middleware: false, method: "get" },
  { route: '/api/callback/login', handler: _lazy_hpiyMT, lazy: true, middleware: false, method: "get" },
  { route: '/__nuxt_error', handler: _lazy_GQw9b6, lazy: true, middleware: false, method: undefined },
  { route: '/**', handler: _lazy_GQw9b6, lazy: true, middleware: false, method: undefined }
];

function createNitroApp() {
  const config = useRuntimeConfig();
  const hooks = createHooks();
  const h3App = createApp({
    debug: destr(false),
    onError: errorHandler
  });
  const router = createRouter$1();
  h3App.use(createRouteRulesHandler());
  const localCall = createCall(toNodeListener(h3App));
  const localFetch = createFetch(localCall, globalThis.fetch);
  const $fetch = createFetch$1({
    fetch: localFetch,
    Headers,
    defaults: { baseURL: config.app.baseURL }
  });
  globalThis.$fetch = $fetch;
  h3App.use(
    eventHandler((event) => {
      const envContext = event.node.req.__unenv__;
      if (envContext) {
        Object.assign(event.context, envContext);
      }
      event.fetch = (req, init) => fetchWithEvent(event, req, init, { fetch: localFetch });
      event.$fetch = (req, init) => fetchWithEvent(event, req, init, { fetch: $fetch });
    })
  );
  for (const h of handlers) {
    let handler = h.lazy ? lazyEventHandler(h.handler) : h.handler;
    if (h.middleware || !h.route) {
      const middlewareBase = (config.app.baseURL + (h.route || "/")).replace(
        /\/+/g,
        "/"
      );
      h3App.use(middlewareBase, handler);
    } else {
      const routeRules = getRouteRulesForPath(
        h.route.replace(/:\w+|\*\*/g, "_")
      );
      if (routeRules.cache) {
        handler = cachedEventHandler(handler, {
          group: "nitro/routes",
          ...routeRules.cache
        });
      }
      router.use(h.route, handler, h.method);
    }
  }
  h3App.use(config.app.baseURL, router);
  const app = {
    hooks,
    h3App,
    router,
    localCall,
    localFetch
  };
  for (const plugin of plugins) {
    plugin(app);
  }
  return app;
}
const nitroApp = createNitroApp();
const useNitroApp = () => nitroApp;

const cert = process.env.NITRO_SSL_CERT;
const key = process.env.NITRO_SSL_KEY;
const server = cert && key ? new Server({ key, cert }, toNodeListener(nitroApp.h3App)) : new Server$1(toNodeListener(nitroApp.h3App));
const port = destr(process.env.NITRO_PORT || process.env.PORT) || 3e3;
const host = process.env.NITRO_HOST || process.env.HOST;
const s = server.listen(port, host, (err) => {
  if (err) {
    console.error(err);
    process.exit(1);
  }
  const protocol = cert && key ? "https" : "http";
  const i = s.address();
  const baseURL = (useRuntimeConfig().app.baseURL || "").replace(/\/$/, "");
  const url = `${protocol}://${i.family === "IPv6" ? `[${i.address}]` : i.address}:${i.port}${baseURL}`;
  console.log(`Listening ${url}`);
});
{
  process.on(
    "unhandledRejection",
    (err) => console.error("[nitro] [dev] [unhandledRejection] " + err)
  );
  process.on(
    "uncaughtException",
    (err) => console.error("[nitro] [dev] [uncaughtException] " + err)
  );
}
const nodeServer = {};

export { UserModel as U, checkPermissionSelections as a, combinePermissions as b, checkPermissionNeeds as c, authorizationCodeDigitalID as d, useNitroApp as e, getRouteRules as f, getUserInfoDigitalID as g, isContainsAdvancePermissions as i, nodeServer as n, removePermissions as r, useRuntimeConfig as u };
//# sourceMappingURL=node-server.mjs.map
