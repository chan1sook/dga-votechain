import { defineEventHandler, createError, readBody } from 'h3';
import dayjs from 'dayjs';
import { T as TopicModel } from './topic.mjs';
import { a as isTopicFormValid } from './topic2.mjs';
import { a as checkPermissionSelections, c as checkPermissionNeeds } from './node-server.mjs';
import 'mongoose';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'unstorage/drivers/redis';
import 'defu';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'nanoid';
import 'axios';

const create_post = defineEventHandler(async (event) => {
  const userData = event.context.userData;
  if (!userData || !checkPermissionSelections(userData.permissions, "create-topic", "request-topic")) {
    throw createError({
      statusCode: 403,
      statusMessage: "Forbidden"
    });
  }
  const topicFormData = await readBody(event);
  if (!isTopicFormValid(topicFormData)) {
    throw createError({
      statusCode: 400,
      statusMessage: "Input Invalid"
    });
  }
  const canBypassCreate = checkPermissionNeeds(userData.permissions, "create-topic");
  const newTopicData = {
    name: topicFormData.name,
    description: topicFormData.description,
    choices: topicFormData.choices,
    status: canBypassCreate && !topicFormData.forcePending ? "approved" : "pending",
    createdBy: userData.userid,
    updatedBy: userData.userid,
    createdAt: /* @__PURE__ */ new Date(),
    updatedAt: /* @__PURE__ */ new Date(),
    voteStartAt: dayjs(topicFormData.voteStartAt).toDate(),
    voteExpiredAt: dayjs(topicFormData.voteExpiredAt).toDate()
  };
  const topicData = await new TopicModel(newTopicData).save();
  const topic = {
    _id: topicData._id.toString(),
    status: topicData.status,
    name: topicData.name,
    description: topicData.description,
    choices: topicData.choices,
    voteStartAt: dayjs(topicData.voteStartAt).toISOString(),
    voteExpiredAt: dayjs(topicData.voteExpiredAt).toISOString(),
    createdAt: dayjs(topicData.createdAt).toISOString(),
    updatedAt: dayjs(topicData.updatedAt).toISOString()
  };
  return {
    topic
  };
});

export { create_post as default };
//# sourceMappingURL=create.post.mjs.map
