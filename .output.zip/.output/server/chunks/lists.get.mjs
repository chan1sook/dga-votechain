import { defineEventHandler, createError } from 'h3';
import { R as RequestPermissionsModel } from './reqpermission.mjs';
import { a as checkPermissionSelections, c as checkPermissionNeeds, i as isContainsAdvancePermissions } from './node-server.mjs';
import 'mongoose';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'unstorage/drivers/redis';
import 'defu';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'dayjs';
import 'nanoid';
import 'axios';

const lists_get = defineEventHandler(async (event) => {
  const userData = event.context.userData;
  if (!userData || !checkPermissionSelections(userData.permissions, "change-permissions:basic", "change-permissions:advance")) {
    throw createError({
      statusCode: 403,
      statusMessage: "Forbidden"
    });
  }
  let permissionArr = await RequestPermissionsModel.find({
    status: "pending"
  });
  if (!checkPermissionNeeds(userData.permissions, "change-permissions:advance")) {
    permissionArr = permissionArr.filter((ele) => {
      return !isContainsAdvancePermissions(...ele.permissions);
    });
  }
  const requestPermissions = permissionArr.map((doc) => {
    return {
      _id: `${doc._id}`,
      status: doc.status,
      userid: doc.userid,
      permissions: doc.permissions,
      note: doc.note,
      digitalIdUserInfo: doc.digitalIdUserInfo
    };
  });
  return {
    requestPermissions
  };
});

export { lists_get as default };
//# sourceMappingURL=lists.get.mjs.map
