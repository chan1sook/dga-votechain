import { defineEventHandler, createError } from 'h3';
import dayjs from 'dayjs';
import { N as NewsModel } from './news.mjs';
import 'mongoose';

const _id__get = defineEventHandler(async (event) => {
  var _a;
  const newsDoc = await NewsModel.findById((_a = event.context.params) == null ? void 0 : _a.id);
  if (!newsDoc) {
    throw createError({
      statusCode: 404,
      statusMessage: "News not found"
    });
  }
  const news = {
    _id: `${newsDoc._id}`,
    visibility: newsDoc.visibility,
    title: newsDoc.title,
    author: newsDoc.author,
    content: newsDoc.content,
    references: newsDoc.references,
    createdBy: newsDoc.createdBy,
    updatedBy: newsDoc.updatedBy,
    newsPublishAt: dayjs(newsDoc.newsPublishAt).toString(),
    newsExpiredAt: newsDoc.newsExpiredAt ? dayjs(newsDoc.newsExpiredAt).toString() : null,
    createdAt: dayjs(newsDoc.createdAt).toString(),
    updatedAt: dayjs(newsDoc.updatedAt).toString()
  };
  return {
    news
  };
});

export { _id__get as default };
//# sourceMappingURL=_id_.get4.mjs.map
