const error_vue_vue_type_style_index_0_lang = ".dga-error-container{align-items:center;display:flex;flex-direction:column;height:100vh;justify-content:center}.dga-error-container>div{padding-bottom:4rem;padding-top:4rem;width:100%}";

const errorStyles_7030143b = [error_vue_vue_type_style_index_0_lang];

export { errorStyles_7030143b as default };
//# sourceMappingURL=error-styles.7030143b.mjs.map
