import { _ as __nuxt_component_0 } from './MaterialIcon-25e5e22f.mjs';
import { u as useHead, w as webAppName } from './server.mjs';
import { defineComponent, ref, computed, mergeProps, unref, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderAttr, ssrIncludeBooleanAttr, ssrLooseContain, ssrRenderComponent } from 'vue/server-renderer';
import dayjs from 'dayjs';
import { i as isNewsFormValid, u as useWatchNewsDateTimes } from './news-f283fe82.mjs';
import './_plugin-vue_export-helper-cc2b3d55.mjs';
import 'ofetch';
import 'hookable';
import 'unctx';
import '@unhead/vue';
import '@unhead/dom';
import '@unhead/ssr';
import 'vue-router';
import 'h3';
import 'ufo';
import 'defu';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'unstorage/drivers/redis';
import 'radix3';
import 'mongoose';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'nanoid';
import 'axios';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "create",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: `${webAppName} - Create News`
    });
    const publishDate = dayjs().millisecond(0).toDate();
    const expiredDate = dayjs().add(1, "year").hour(0).minute(0).second(0).millisecond(0).toDate();
    const publishDateStr = ref(dayjs(publishDate).format("YYYY-MM-DD"));
    const publishTimeStr = ref(dayjs(publishDate).format("HH:MM"));
    const expiredDateStr = ref(dayjs(expiredDate).format("YYYY-MM-DD"));
    const expiredTimeStr = ref(dayjs(expiredDate).format("HH:MM"));
    const startExpiredDateStr = computed(() => dayjs(publishDateStr.value, "YYYY-MM-DD").add(1, "day").format("YYYY-MM-DD"));
    const isNewsExpired = ref(false);
    const newsData = ref({
      title: "",
      visibility: "public",
      author: "",
      content: "",
      references: "",
      newsPublishAt: publishDate,
      newsExpiredAt: null
    });
    const isFormValid = computed(() => isNewsFormValid(newsData.value));
    useWatchNewsDateTimes(newsData, publishDateStr, publishTimeStr, expiredDateStr, expiredTimeStr, isNewsExpired);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_MaterialIcon = __nuxt_component_0;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "p-4 w-full mx-auto" }, _attrs))}><div class="border-2 border-gray-200 rounded-lg shadow p-4"><h1 class="text-3xl font-bold text-center mb-4">${ssrInterpolate(unref(webAppName))}</h1><h2 class="text-2xl font-bold text-center mb-4"> Create News </h2><div class="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-7xl mx-auto my-4"><div class="md:col-span-2 p-2 pb-0 flex flex-row items-center gap-2"><label class="flex-none">Title</label><input${ssrRenderAttr("value", unref(newsData).title)} type="text" class="dga-evote-input w-0 flex-1" placeholder="News title"><span class="text-red-500" title="Required">*</span></div><div class="md:col-span-2 p-2 pb-0 flex flex-row items-center gap-2"><label class="flex-none">Author</label><input${ssrRenderAttr("value", unref(newsData).author)} type="text" class="dga-evote-input w-0 flex-1" placeholder="News author"></div><div class="md:col-span-2 p-2 pb-0 flex flex-row items-start gap-2"><label class="flex-none">Content</label><textarea class="dga-evote-input w-0 flex-1 h-32" placeholder="News content">${ssrInterpolate(unref(newsData).content)}</textarea><span class="text-red-500" title="Required">*</span></div><div class="md:col-span-2 p-2 pb-0 flex flex-row items-center gap-2"><label class="flex-none">References</label><input${ssrRenderAttr("value", unref(newsData).references)} type="text" class="dga-evote-input w-0 flex-1" placeholder="News references"></div><div class="md:col-span-2 p-2 pb-0 flex flex-row items-center gap-2"><label class="flex-none">Publish Time</label><input${ssrRenderAttr("value", unref(publishDateStr))} type="date" class="dga-evote-input w-0 flex-1" placeholder="Publish Date"><input${ssrRenderAttr("value", unref(publishTimeStr))} type="time" class="dga-evote-input w-0 flex-1" placeholder="Publish Time"></div><div class="md:col-span-2 p-2 pb-0 flex flex-row items-center gap-2"><input${ssrIncludeBooleanAttr(Array.isArray(unref(isNewsExpired)) ? ssrLooseContain(unref(isNewsExpired), null) : unref(isNewsExpired)) ? " checked" : ""} type="checkbox" class="scale-125"><label class="flex-none">Expired</label></div><div class="md:col-span-2 p-2 pb-0 flex flex-row items-center gap-2"><label class="flex-none">Expired Time</label><input${ssrRenderAttr("value", unref(expiredDateStr))} type="date" class="dga-evote-input w-0 flex-1"${ssrRenderAttr("min", unref(startExpiredDateStr))} placeholder="Expired Date"${ssrIncludeBooleanAttr(!unref(isNewsExpired)) ? " disabled" : ""}><input${ssrRenderAttr("value", unref(expiredTimeStr))} type="time" class="dga-evote-input w-0 flex-1" placeholder="Expired Time"${ssrIncludeBooleanAttr(!unref(isNewsExpired)) ? " disabled" : ""}></div><div class="md:col-span-2 my-2 text-center"><button type="button" class="dga-evote-btn w-full max-w-sm inline-flex gap-2 items-center justify-center" title="Create News"${ssrIncludeBooleanAttr(!unref(isFormValid)) ? " disabled" : ""}>`);
      _push(ssrRenderComponent(_component_MaterialIcon, { icon: "newspaper" }, null, _parent));
      _push(`<span class="truncate">Create News</span></button></div></div></div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/news/create.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=create-18426957.mjs.map
