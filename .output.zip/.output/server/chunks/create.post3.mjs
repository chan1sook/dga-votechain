import { defineEventHandler, createError, readBody } from 'h3';
import dayjs from 'dayjs';
import { N as NewsModel } from './news.mjs';
import { i as isNewsFormValid } from './news2.mjs';
import { a as checkPermissionSelections } from './node-server.mjs';
import 'mongoose';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'unstorage/drivers/redis';
import 'defu';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'nanoid';
import 'axios';

const create_post = defineEventHandler(async (event) => {
  const userData = event.context.userData;
  if (!userData || !checkPermissionSelections(userData.permissions, "create-news")) {
    throw createError({
      statusCode: 403,
      statusMessage: "Forbidden"
    });
  }
  const newsFormData = await readBody(event);
  const newNewsData = {
    visibility: newsFormData.visibility,
    title: newsFormData.title,
    author: newsFormData.author,
    content: newsFormData.content,
    references: newsFormData.references,
    createdBy: userData.userid,
    updatedBy: userData.userid,
    createdAt: /* @__PURE__ */ new Date(),
    updatedAt: /* @__PURE__ */ new Date(),
    newsPublishAt: dayjs(newsFormData.newsPublishAt).toDate(),
    newsExpiredAt: newsFormData.newsExpiredAt ? dayjs(newsFormData.newsPublishAt).toDate() : null
  };
  if (!isNewsFormValid(newNewsData)) {
    throw createError({
      statusCode: 400,
      statusMessage: "Input Invalid"
    });
  }
  const newsData = await new NewsModel(newNewsData).save();
  const news = {
    _id: newsData._id.toString(),
    visibility: newsData.visibility,
    title: newsData.title,
    author: newsData.author,
    content: newsData.content,
    references: newsData.references,
    createdBy: newsData.createdBy,
    updatedBy: newsData.updatedBy,
    newsPublishAt: dayjs(newsData.newsPublishAt).toString(),
    newsExpiredAt: newsData.newsExpiredAt ? dayjs(newsData.newsExpiredAt).toString() : null,
    createdAt: dayjs(newsData.createdAt).toString(),
    updatedAt: dayjs(newsData.updatedAt).toString()
  };
  return {
    news
  };
});

export { create_post as default };
//# sourceMappingURL=create.post3.mjs.map
