function legacyRoleToPermissionsExcludes(role) {
  switch (role) {
    case "voter":
      return ["access-pages:user", "request-permissions", "vote-topic", "request-topic"];
    case "admin":
      return [
        "access-pages:admin",
        "create-topic",
        "change-topic",
        "create-news",
        "change-news",
        "change-permissions:basic"
      ];
    case "developer":
      return ["access-pages:developer", "change-permissions:advance"];
    default:
      return [];
  }
}
function getRequestablePermissions() {
  return combinePermissions(
    legacyRoleToPermissionsExcludes("admin"),
    ...legacyRoleToPermissionsExcludes("developer")
  );
}
function getPresetPermissions(value) {
  switch (value) {
    case "admin":
      return legacyRoleToPermissionsExcludes("admin");
    case "developer":
      return combinePermissions(
        legacyRoleToPermissionsExcludes("admin"),
        ...legacyRoleToPermissionsExcludes("developer")
      );
    default:
      return legacyRoleToPermissionsExcludes("admin");
  }
}
function checkPermissionNeeds(availables, ...needs) {
  const needsArrs = removePermissions(needs, ...availables);
  return needsArrs.length === 0;
}
function checkPermissionSelections(availables, ...selections) {
  for (const permission of availables) {
    if (selections.includes(permission)) {
      return true;
    }
  }
  return false;
}
function combinePermissions(a, ...others) {
  const result = a.slice(0);
  for (const permission of others) {
    if (!result.includes(permission)) {
      result.push(permission);
    }
  }
  return result;
}
function removePermissions(target, ...removed) {
  const result = target.slice(0);
  for (const permission of removed) {
    const targetIndex = result.indexOf(permission);
    if (targetIndex !== -1) {
      result.splice(targetIndex, 1);
    }
  }
  return result;
}
const permissionMap = {
  "access-pages:user": "Access User Pages",
  "access-pages:admin": "Access Admin Pages",
  "access-pages:developer": "Access Developer Pages",
  "request-permissions": "Request More Permissions",
  "banned": "Mark Banned User",
  "vote-topic": "Vote Topics",
  "request-topic": "Request New Topics",
  "create-topic": "Create New Topics Directly",
  "change-topic": "Change Topic Data",
  "create-news": "Create News",
  "change-news": "Change News Data",
  "change-permissions:basic": "Allow Change Other User Basic Permissions",
  "change-permissions:advance": "Allow Change Other User Advance Permissions"
};
function getFullPermissionTitle(permission) {
  return permissionMap[permission] ? permissionMap[permission] : "";
}

export { getPresetPermissions as a, getRequestablePermissions as b, checkPermissionNeeds as c, checkPermissionSelections as d, getFullPermissionTitle as g };
//# sourceMappingURL=permissions-2a4aee66.mjs.map
