import { model, Schema } from 'mongoose';

const schema = new Schema({
  userid: {
    type: String,
    required: true
  },
  digitalIdUserInfo: {
    type: Object,
    required: true
  },
  note: {
    type: String
  },
  permissions: [String],
  status: {
    type: String,
    required: true
  }
}, { timestamps: true });
const RequestPermissionsModel = model("reqpermissions", schema);

export { RequestPermissionsModel as R };
//# sourceMappingURL=reqpermission.mjs.map
