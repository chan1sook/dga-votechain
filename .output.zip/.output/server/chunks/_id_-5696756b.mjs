import { _ as __nuxt_component_0 } from './DetailCard-846b0085.mjs';
import { _ as __nuxt_component_0$1 } from './MaterialIcon-25e5e22f.mjs';
import { d as useRoute, u as useHead, w as webAppName, s as showError } from './server.mjs';
import { useSSRContext, defineComponent, withAsyncContext, ref, computed, mergeProps, unref, withCtx, createTextVNode, createVNode, toDisplayString } from 'vue';
import { u as useFetch } from './fetch-f8b573e2.mjs';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent, ssrRenderList, ssrIncludeBooleanAttr, ssrRenderAttr, ssrRenderClass } from 'vue/server-renderer';
import dayjs from 'dayjs';
import { _ as _export_sfc } from './_plugin-vue_export-helper-cc2b3d55.mjs';
import 'ofetch';
import 'hookable';
import 'unctx';
import '@unhead/vue';
import '@unhead/dom';
import '@unhead/ssr';
import 'vue-router';
import 'h3';
import 'ufo';
import 'defu';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'unstorage/drivers/redis';
import 'radix3';
import 'mongoose';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'nanoid';
import 'axios';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "[id]",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const { id } = useRoute().params;
    const topicid = Array.isArray(id) ? id[id.length - 1] : id;
    useHead({
      title: `${webAppName} - Vote #${topicid}`
    });
    const { data } = ([__temp, __restore] = withAsyncContext(() => useFetch(`/api/topic/info/${topicid}`, {
      query: { withVote: "1" }
    }, "$TppiF1moq9")), __temp = await __temp, __restore(), __temp);
    const topic = ref(void 0);
    const yourVote = ref(void 0);
    const withImage = computed(() => topic.value && topic.value.choices.choices.some((ele) => ele.image));
    const canVote = computed(() => {
      const topicCondition = topic.value && Date.now() <= dayjs(topic.value.voteExpiredAt).valueOf();
      const voteCondition = !yourVote.value;
      return voteCondition && topicCondition;
    });
    const currentChoice = ref(null);
    const customOption = ref("");
    const isChooseAbstention = ref(false);
    const isChooseCustom = ref(false);
    const isFormValid = computed(() => {
      return canVote && (isChooseAbstention.value || isChooseCustom.value && customOption.value !== "" || currentChoice.value !== null);
    });
    if (!data.value) {
      showError("Topic not found");
    } else {
      const { topic: _topic, yourVote: _yourVote } = data.value;
      topic.value = _topic;
      yourVote.value = _yourVote;
      if (yourVote.value) {
        currentChoice.value = yourVote.value.choice ? yourVote.value.choice : null;
        isChooseAbstention.value = !yourVote.value.choice;
      }
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_DetailCard = __nuxt_component_0;
      const _component_MaterialIcon = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "p-4 w-full mx-auto" }, _attrs))} data-v-182f14df>`);
      if (unref(topic)) {
        _push(`<div class="border-2 border-gray-200 rounded-lg shadow p-4" data-v-182f14df><h1 class="text-3xl font-bold text-center mb-4" data-v-182f14df>${ssrInterpolate(unref(webAppName))}</h1><h2 class="text-2xl font-bold text-center mb-0" data-v-182f14df>${ssrInterpolate(unref(topic).name)}</h2><div class="text-sm text-center text-gray-700 mb-4" data-v-182f14df>#${ssrInterpolate(unref(topicid))}</div><div class="grid grid-cols-1 md:grid-cols-3 gap-4 my-2" data-v-182f14df>`);
        _push(ssrRenderComponent(_component_DetailCard, { class: "self-start" }, {
          header: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`\u0E23\u0E32\u0E22\u0E25\u0E30\u0E40\u0E2D\u0E35\u0E22\u0E14`);
            } else {
              return [
                createTextVNode("\u0E23\u0E32\u0E22\u0E25\u0E30\u0E40\u0E2D\u0E35\u0E22\u0E14")
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="p-2" data-v-182f14df${_scopeId}>${ssrInterpolate(unref(topic).description)}</div>`);
            } else {
              return [
                createVNode("div", { class: "p-2" }, toDisplayString(unref(topic).description), 1)
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`<div class="md:col-span-2" data-v-182f14df><div class="flex flex-row flex-wrap justify-center gap-2" data-v-182f14df>`);
        if (unref(withImage)) {
          _push(`<!--[-->`);
          ssrRenderList(unref(topic).choices.choices, (choice) => {
            _push(`<button type="button" class="dga-evote-btn with-img w-36 inline-flex flex-wrap gap-2 items-center justify-center relative"${ssrIncludeBooleanAttr(!unref(canVote)) ? " disabled" : ""}${ssrRenderAttr("title", choice.name)} data-v-182f14df><img${ssrRenderAttr("src", choice.image)} data-v-182f14df><span class="truncate" data-v-182f14df>${ssrInterpolate(choice.name)}</span>`);
            if (!unref(isChooseAbstention) && choice.name === unref(currentChoice)) {
              _push(ssrRenderComponent(_component_MaterialIcon, {
                icon: "check",
                class: "absolute right-2 bottom-2"
              }, null, _parent));
            } else {
              _push(`<!---->`);
            }
            _push(`</button>`);
          });
          _push(`<!--]-->`);
        } else {
          _push(`<!--[-->`);
          ssrRenderList(unref(topic).choices.choices, (choice) => {
            _push(`<button type="button" class="dga-evote-btn without-img w-full max-w-3xl inline-flex gap-2 items-center justify-center relative"${ssrIncludeBooleanAttr(!unref(canVote)) ? " disabled" : ""}${ssrRenderAttr("title", choice.name)} data-v-182f14df><span class="truncate" data-v-182f14df>${ssrInterpolate(choice.name)}</span>`);
            if (!unref(isChooseAbstention) && choice.name === unref(currentChoice)) {
              _push(ssrRenderComponent(_component_MaterialIcon, {
                icon: "check",
                class: "absolute right-2"
              }, null, _parent));
            } else {
              _push(`<!---->`);
            }
            _push(`</button>`);
          });
          _push(`<!--]-->`);
        }
        _push(`</div><div class="my-2 flex flex-col flex-wrap items-center gap-2" data-v-182f14df>`);
        if (unref(topic).choices.customable) {
          _push(`<button class="dga-evote-btn without-img w-full max-w-3xl inline-flex gap-2 items-center justify-center relative"${ssrIncludeBooleanAttr(!unref(canVote)) ? " disabled" : ""}${ssrRenderAttr("title", unref(customOption) || "Custom Option")} data-v-182f14df><span class="truncate" data-v-182f14df>Custom: </span><input${ssrRenderAttr("value", unref(customOption))} type="text" class="dga-evote-input text-gray-700" placeholder="Custom Option"${ssrIncludeBooleanAttr(!unref(canVote)) ? " disabled" : ""} data-v-182f14df>`);
          if (!unref(isChooseAbstention) && unref(isChooseCustom)) {
            _push(ssrRenderComponent(_component_MaterialIcon, {
              icon: "check",
              class: "absolute right-2"
            }, null, _parent));
          } else {
            _push(`<!---->`);
          }
          _push(`</button>`);
        } else {
          _push(`<!---->`);
        }
        _push(`<button type="button" class="dga-evote-btn vote-abstention w-full max-w-3xl inline-flex gap-2 items-center justify-center relative"${ssrIncludeBooleanAttr(!unref(canVote)) ? " disabled" : ""} title="Vote No" data-v-182f14df><span class="truncate" data-v-182f14df>Vote No</span>`);
        if (unref(isChooseAbstention)) {
          _push(ssrRenderComponent(_component_MaterialIcon, {
            icon: "check",
            class: "absolute right-2"
          }, null, _parent));
        } else {
          _push(`<!---->`);
        }
        _push(`</button></div><div class="my-2 mt-8 flex flex-col flex-wrap items-center gap-2" data-v-182f14df><button type="button" class="${ssrRenderClass([{ "invisible": !unref(canVote) }, "dga-evote-btn vote-confirm w-full max-w-3xl inline-flex gap-2 items-center justify-center relative"])}"${ssrIncludeBooleanAttr(!unref(isFormValid)) ? " disabled" : ""} title="Confirm Vote" data-v-182f14df><span class="truncate" data-v-182f14df>`);
        if (unref(isChooseAbstention)) {
          _push(`<!--[-->Confirm No Vote<!--]-->`);
        } else if (unref(isChooseCustom) && unref(customOption)) {
          _push(`<!--[-->Confirm Vote [${ssrInterpolate(unref(customOption))}]<!--]-->`);
        } else if (unref(currentChoice)) {
          _push(`<!--[-->Confirm Vote [${ssrInterpolate(unref(currentChoice))}]<!--]-->`);
        } else {
          _push(`<!--[-->Confirm Vote<!--]-->`);
        }
        _push(`</span></button><button type="button" class="dga-evote-btn vote-later w-full max-w-3xl inline-flex gap-2 items-center justify-center relative"${ssrRenderAttr("title", unref(canVote) ? "Vote Later" : "Back")} data-v-182f14df><span class="truncate" data-v-182f14df>`);
        if (unref(canVote)) {
          _push(`<!--[-->Vote Later<!--]-->`);
        } else {
          _push(`<!--[-->Back<!--]-->`);
        }
        _push(`</span></button></div></div></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/vote/[id].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const _id_ = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-182f14df"]]);

export { _id_ as default };
//# sourceMappingURL=_id_-5696756b.mjs.map
