import { useSSRContext, defineComponent, useAttrs, mergeProps } from 'vue';
import { ssrRenderAttrs, ssrRenderClass, ssrRenderSlot } from 'vue/server-renderer';
import { _ as _export_sfc } from './_plugin-vue_export-helper-cc2b3d55.mjs';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "BasicListItem",
  __ssrInlineRender: true,
  props: {
    headerClass: {
      type: String,
      default: "w-8"
    },
    noAnimation: {
      type: Boolean,
      default: false
    },
    unlimitLines: {
      type: Boolean,
      default: false
    }
  },
  setup(__props) {
    const { headerClass, noAnimation, unlimitLines } = __props;
    const { onClick } = useAttrs();
    const topClass = {
      "cursor-pointer": Boolean(onClick),
      "no-animation": noAnimation,
      "unlimit-lines": unlimitLines
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: ["dga-evote-basic-list hover:bg-gradient-to-r hover:from-slate-300/50 hover:to-slate-100/50", topClass]
      }, _attrs))} data-v-e057ec2d><div class="${ssrRenderClass([__props.headerClass, "header"])}" data-v-e057ec2d>`);
      ssrRenderSlot(_ctx.$slots, "header", {}, () => {
        _push(`1.`);
      }, _push, _parent);
      _push(`</div><div class="content" data-v-e057ec2d>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/BasicListItem.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-e057ec2d"]]);

export { __nuxt_component_0 as _ };
//# sourceMappingURL=BasicListItem-36ba5b36.mjs.map
