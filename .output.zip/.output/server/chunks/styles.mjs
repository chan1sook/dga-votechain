const interopDefault = r => r.default || r || [];
const styles = {
  "app.vue": () => import('./app-styles.37a7359e.mjs').then(interopDefault),
  "pages/vote/[id].vue": () => import('./_id_-styles.7c6383f3.mjs').then(interopDefault),
  "error.vue": () => import('./error-styles.7030143b.mjs').then(interopDefault)
};

export { styles as default };
//# sourceMappingURL=styles.mjs.map
