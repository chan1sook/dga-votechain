const app_vue_vue_type_style_index_0_lang = '.material-symbols-outlined{font-variation-settings:"FILL" 0,"wght" 400,"GRAD" 0,"opsz" 48}';

const appStyles_37a7359e = [app_vue_vue_type_style_index_0_lang];

export { appStyles_37a7359e as default };
//# sourceMappingURL=app-styles.37a7359e.mjs.map
