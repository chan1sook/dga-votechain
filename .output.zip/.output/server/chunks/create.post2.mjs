import { defineEventHandler, createError, readBody } from 'h3';
import { R as RequestPermissionsModel } from './reqpermission.mjs';
import { c as checkPermissionNeeds } from './node-server.mjs';
import 'mongoose';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'unstorage/drivers/redis';
import 'defu';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'dayjs';
import 'nanoid';
import 'axios';

const create_post = defineEventHandler(async (event) => {
  const userData = event.context.userData;
  if (!userData || !checkPermissionNeeds(userData.permissions, "request-permissions")) {
    throw createError({
      statusCode: 403,
      statusMessage: "Forbidden"
    });
  }
  const reqPermissionsData = await readBody(event);
  const reqPermissionsDoc = {
    userid: userData.userid,
    status: "pending",
    digitalIdUserInfo: userData.digitalIdUserInfo,
    permissions: reqPermissionsData.permissions,
    note: reqPermissionsData.note,
    createdAt: /* @__PURE__ */ new Date(),
    updatedAt: /* @__PURE__ */ new Date()
  };
  await new RequestPermissionsModel(reqPermissionsDoc).save();
  const requestPermissions = {
    _id: `${reqPermissionsDoc._id}`,
    status: reqPermissionsDoc.status,
    userid: reqPermissionsDoc.userid,
    permissions: reqPermissionsDoc.permissions,
    note: reqPermissionsDoc.note
  };
  return {
    requestPermissions
  };
});

export { create_post as default };
//# sourceMappingURL=create.post2.mjs.map
