import { executeAsync } from 'unctx';
import { g as defineNuxtRouteMiddleware, n as navigateTo } from './server.mjs';
import { u as useFetch } from './fetch-f8b573e2.mjs';
import { u as useUserId } from './useUserId-e792a6e0.mjs';
import { u as usePermissions } from './usePermissions-f45a7a74.mjs';
import { d as checkPermissionSelections } from './permissions-2a4aee66.mjs';
import 'vue';
import 'ofetch';
import 'hookable';
import '@unhead/vue';
import '@unhead/dom';
import '@unhead/ssr';
import 'vue-router';
import 'h3';
import 'ufo';
import 'vue/server-renderer';
import 'defu';
import 'dayjs';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'unstorage/drivers/redis';
import 'radix3';
import 'mongoose';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'nanoid';
import 'axios';

const authGuest = defineNuxtRouteMiddleware(async (to, from) => {
  let __temp, __restore;
  const { data } = ([__temp, __restore] = executeAsync(() => useFetch("/api/session", "$SagDe3GkXh")), __temp = await __temp, __restore(), __temp);
  if (data.value) {
    useUserId().value = data.value.userid;
    usePermissions().value = data.value.permissions;
  } else {
    useUserId().value = void 0;
    usePermissions().value = [];
  }
  if (checkPermissionSelections(usePermissions().value, "access-pages:user", "access-pages:admin", "access-pages:developer")) {
    return navigateTo("/");
  }
});

export { authGuest as default };
//# sourceMappingURL=auth-guest-cd021fbf.mjs.map
