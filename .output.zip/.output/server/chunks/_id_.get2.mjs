import { defineEventHandler, createError } from 'h3';
import dayjs from 'dayjs';
import { i as isTopicExpired } from './topic2.mjs';
import { T as TopicModel } from './topic.mjs';
import { V as VoteModel } from './vote.mjs';
import 'mongoose';

const _id__get = defineEventHandler(async (event) => {
  var _a;
  const topicDoc = await TopicModel.findById((_a = event.context.params) == null ? void 0 : _a.id);
  if (!topicDoc) {
    throw createError({
      statusCode: 404,
      statusMessage: "Topic not found"
    });
  }
  if (topicDoc.status !== "approved" || !isTopicExpired(topicDoc)) {
    throw createError({
      statusCode: 404,
      statusMessage: "Topic not expired or not approved"
    });
  }
  const allVotes = await VoteModel.find({ topicid: topicDoc._id });
  const voteRecords = [];
  for (const vote of allVotes) {
    const target = voteRecords.find((ele) => ele.choice === vote.choice);
    if (target) {
      target.count += 1;
    } else {
      voteRecords.push({ choice: vote.choice, count: 1 });
    }
  }
  allVotes.reduce((prev, current) => {
    return prev;
  }, voteRecords);
  const voteResult = {
    _id: `${topicDoc._id}`,
    status: topicDoc.status,
    name: topicDoc.name,
    description: topicDoc.description,
    choices: topicDoc.choices,
    voteStartAt: dayjs(topicDoc.voteStartAt).toString(),
    voteExpiredAt: dayjs(topicDoc.voteExpiredAt).toString(),
    createdAt: dayjs(topicDoc.createdAt).toString(),
    updatedAt: dayjs(topicDoc.updatedAt).toString(),
    votes: voteRecords
  };
  return {
    voteResult
  };
});

export { _id__get as default };
//# sourceMappingURL=_id_.get2.mjs.map
