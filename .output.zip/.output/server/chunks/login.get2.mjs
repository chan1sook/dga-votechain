import { defineEventHandler, getQuery, createError, sendRedirect } from 'h3';
import { u as useRuntimeConfig, d as authorizationCodeDigitalID, g as getUserInfoDigitalID, U as UserModel, c as checkPermissionNeeds } from './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'unstorage/drivers/redis';
import 'defu';
import 'radix3';
import 'mongoose';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'dayjs';
import 'nanoid';
import 'axios';

const login_get = defineEventHandler(async (event) => {
  const { code } = getQuery(event);
  const { DID_CLIENT_KEY, DID_LOGIN_CALLBACK, DID_VERIFY_CODE, public: { DID_API_URL } } = useRuntimeConfig();
  if (typeof code === "string") {
    const { id_token, access_token } = await authorizationCodeDigitalID(code, { DID_API_URL, DID_CLIENT_KEY, DID_LOGIN_CALLBACK, DID_VERIFY_CODE });
    const digitalIdUserInfo = await getUserInfoDigitalID(access_token, { DID_API_URL });
    const { permissions, createdAt, updatedAt } = await UserModel.ensureUserData(digitalIdUserInfo.user_id);
    if (checkPermissionNeeds(permissions, "banned")) {
      throw createError({
        statusCode: 403,
        statusMessage: "Forbidden: Banned"
      });
    }
    event.context.userData = {
      userid: digitalIdUserInfo.user_id,
      idToken: id_token,
      accessToken: access_token,
      digitalIdUserInfo,
      permissions,
      createdAt,
      updatedAt
    };
    await event.context.session.set("userData", {
      userid: digitalIdUserInfo.user_id,
      accessToken: access_token,
      idToken: id_token
    });
    return sendRedirect(event, "/");
  }
  return sendRedirect(event, "/login");
});

export { login_get as default };
//# sourceMappingURL=login.get2.mjs.map
