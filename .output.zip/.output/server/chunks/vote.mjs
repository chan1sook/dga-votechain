import { model, Schema, Types } from 'mongoose';

const schema = new Schema({
  userid: {
    type: String,
    required: true
  },
  topicid: {
    type: Schema.Types.ObjectId,
    ref: "topic",
    required: true
  },
  choice: {
    type: String
  }
}, { timestamps: true });
schema.static("getLastestVotes", function getLastestVotes(pagesize, startid, filterKeyword) {
  var _a;
  const query = {
    $and: []
  };
  if (startid) {
    query.$and.push({
      _id: { $lt: new Types.ObjectId(startid) }
    });
  }
  if (filterKeyword) {
    query.$and.push({ $or: [
      { _id: new Types.ObjectId(filterKeyword) },
      { userid: filterKeyword },
      { topicid: new Types.ObjectId(filterKeyword) }
    ] });
  }
  if (((_a = query.$and) == null ? void 0 : _a.length) === 0) {
    delete query.$and;
  }
  return this.find(query).limit(pagesize || 50).sort({ _id: -1 });
});
schema.static("getLastestVotesByUserid", function getLastestVotesByUserid(userid, pagesize, startid) {
  const query = {
    userid
  };
  if (startid) {
    query._id = { $lt: new Types.ObjectId(startid) };
  }
  return this.find(query).limit(pagesize || 50).sort({ topicid: -1, _id: -1 });
});
const VoteModel = model("vote", schema);

export { VoteModel as V };
//# sourceMappingURL=vote.mjs.map
