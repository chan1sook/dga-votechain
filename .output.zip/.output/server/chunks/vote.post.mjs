import { defineEventHandler, createError, readBody } from 'h3';
import { Types } from 'mongoose';
import dayjs from 'dayjs';
import { T as TopicModel } from './topic.mjs';
import { V as VoteModel } from './vote.mjs';
import { c as checkPermissionNeeds } from './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'unstorage/drivers/redis';
import 'defu';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'nanoid';
import 'axios';

const vote_post = defineEventHandler(async (event) => {
  const userData = event.context.userData;
  if (!userData || !checkPermissionNeeds(userData.permissions, "vote-topic")) {
    throw createError({
      statusCode: 403,
      statusMessage: "Forbidden"
    });
  }
  const voteFormData = await readBody(event);
  const topicDoc = await TopicModel.findById(voteFormData.topicid);
  if (!topicDoc) {
    throw createError({
      statusCode: 404,
      statusMessage: "Topic not found"
    });
  }
  const voteDoc = await VoteModel.findOne({ userid: userData.userid, topicid: topicDoc._id });
  if (voteDoc) {
    throw createError({
      statusCode: 400,
      statusMessage: "Can't vote again"
    });
  }
  const voteData = {
    userid: userData.userid,
    topicid: new Types.ObjectId(voteFormData.topicid),
    choice: voteFormData.choice,
    createdAt: /* @__PURE__ */ new Date()
  };
  const newVoteDoc = await new VoteModel(voteData).save();
  const vote = {
    _id: `${newVoteDoc._id}`,
    userid: newVoteDoc.userid,
    topicid: `${newVoteDoc.topicid}`,
    choice: newVoteDoc.choice,
    createdAt: dayjs(newVoteDoc.createdAt).toString()
  };
  return {
    vote
  };
});

export { vote_post as default };
//# sourceMappingURL=vote.post.mjs.map
