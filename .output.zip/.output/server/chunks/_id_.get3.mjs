import { defineEventHandler, getQuery, createError } from 'h3';
import dayjs from 'dayjs';
import { T as TopicModel } from './topic.mjs';
import { V as VoteModel } from './vote.mjs';
import { c as checkPermissionNeeds } from './node-server.mjs';
import { i as isTopicExpired } from './topic2.mjs';
import 'mongoose';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'unstorage/drivers/redis';
import 'defu';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'nanoid';
import 'axios';

const _id__get = defineEventHandler(async (event) => {
  var _a;
  const { withVote } = getQuery(event);
  const topicDoc = await TopicModel.findById((_a = event.context.params) == null ? void 0 : _a.id);
  if (!topicDoc) {
    throw createError({
      statusCode: 404,
      statusMessage: "Topic not found"
    });
  }
  const topic = {
    _id: `${topicDoc._id}`,
    status: topicDoc.status,
    name: topicDoc.name,
    description: topicDoc.description,
    choices: topicDoc.choices,
    voteStartAt: dayjs(topicDoc.voteStartAt).toString(),
    voteExpiredAt: dayjs(topicDoc.voteExpiredAt).toString(),
    createdAt: dayjs(topicDoc.createdAt).toString(),
    updatedAt: dayjs(topicDoc.updatedAt).toString()
  };
  let yourVote;
  if (withVote && !isTopicExpired(topicDoc)) {
    const userData = event.context.userData;
    if (userData && checkPermissionNeeds(userData.permissions, "vote-topic")) {
      const voteDoc = await VoteModel.findOne({ userid: userData.userid, topicid: topicDoc._id });
      if (voteDoc) {
        yourVote = {
          _id: `${voteDoc._id}`,
          userid: userData.userid,
          topicid: `${topic._id}`,
          choice: voteDoc.choice,
          createdAt: dayjs(voteDoc.createdAt).toString()
        };
      }
    }
  }
  return {
    topic,
    yourVote
  };
});

export { _id__get as default };
//# sourceMappingURL=_id_.get3.mjs.map
