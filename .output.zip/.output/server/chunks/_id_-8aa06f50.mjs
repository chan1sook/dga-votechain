import { _ as __nuxt_component_0 } from './BasicListItem-36ba5b36.mjs';
import { _ as __nuxt_component_0$1 } from './MaterialIcon-25e5e22f.mjs';
import { _ as __nuxt_component_2 } from './nuxt-link-c6bcda1e.mjs';
import { d as useRoute, u as useHead, w as webAppName, s as showError, f as formatDateTime, t as toFirstCapitalState } from './server.mjs';
import { defineComponent, computed, withAsyncContext, ref, mergeProps, unref, withCtx, createTextVNode, toDisplayString, openBlock, createBlock, Fragment, createVNode, useSSRContext } from 'vue';
import { u as useFetch } from './fetch-f8b573e2.mjs';
import { u as usePermissions } from './usePermissions-f45a7a74.mjs';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent } from 'vue/server-renderer';
import { a as isTopicExpired } from './topic-61a2c6cd.mjs';
import { c as checkPermissionNeeds } from './permissions-2a4aee66.mjs';
import './_plugin-vue_export-helper-cc2b3d55.mjs';
import 'ufo';
import 'ofetch';
import 'hookable';
import 'unctx';
import '@unhead/vue';
import '@unhead/dom';
import '@unhead/ssr';
import 'vue-router';
import 'h3';
import 'defu';
import 'dayjs';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'unstorage/drivers/redis';
import 'radix3';
import 'mongoose';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'nanoid';
import 'axios';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "[id]",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const { id } = useRoute().params;
    let topicid = Array.isArray(id) ? id[id.length - 1] : id;
    useHead({
      title: `${webAppName} - Topic Info #${topicid}`
    });
    const isAdminRole = computed(() => {
      return checkPermissionNeeds(usePermissions().value, "access-pages:admin");
    });
    const { data } = ([__temp, __restore] = withAsyncContext(() => useFetch(`/api/topic/info/${topicid}`, "$yWFUV6qFN0")), __temp = await __temp, __restore(), __temp);
    const topic = ref(void 0);
    if (!data.value) {
      showError("Topic not found");
    } else {
      const { topic: _topic } = data.value;
      topic.value = _topic;
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_BasicListItem = __nuxt_component_0;
      const _component_MaterialIcon = __nuxt_component_0$1;
      const _component_NuxtLink = __nuxt_component_2;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "p-4 w-full mx-auto" }, _attrs))}>`);
      if (unref(topic)) {
        _push(`<div class="border-2 border-gray-200 rounded-lg shadow p-4"><h1 class="text-3xl font-bold text-center mb-4">${ssrInterpolate(unref(webAppName))}</h1><h2 class="text-2xl font-bold text-center mb-0"> Topic Info </h2><div class="text-sm text-center text-gray-700 mb-4">#${ssrInterpolate(unref(topicid))}</div><div class="my-2">`);
        _push(ssrRenderComponent(_component_BasicListItem, { "header-class": "w-40" }, {
          header: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`Topic ID`);
            } else {
              return [
                createTextVNode("Topic ID")
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(` ${ssrInterpolate(unref(topic)._id)}`);
            } else {
              return [
                createTextVNode(" " + toDisplayString(unref(topic)._id), 1)
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(ssrRenderComponent(_component_BasicListItem, { "header-class": "w-40" }, {
          header: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`Created Time`);
            } else {
              return [
                createTextVNode("Created Time")
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(` ${ssrInterpolate(unref(formatDateTime)(unref(topic).createdAt))}`);
            } else {
              return [
                createTextVNode(" " + toDisplayString(unref(formatDateTime)(unref(topic).createdAt)), 1)
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(ssrRenderComponent(_component_BasicListItem, { "header-class": "w-40" }, {
          header: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`Updated Time`);
            } else {
              return [
                createTextVNode("Updated Time")
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(` ${ssrInterpolate(unref(formatDateTime)(unref(topic).updatedAt))}`);
            } else {
              return [
                createTextVNode(" " + toDisplayString(unref(formatDateTime)(unref(topic).updatedAt)), 1)
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(ssrRenderComponent(_component_BasicListItem, { "header-class": "w-40" }, {
          header: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`Status`);
            } else {
              return [
                createTextVNode("Status")
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(` ${ssrInterpolate(unref(toFirstCapitalState)(unref(topic).status))}`);
            } else {
              return [
                createTextVNode(" " + toDisplayString(unref(toFirstCapitalState)(unref(topic).status)), 1)
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(ssrRenderComponent(_component_BasicListItem, { "header-class": "w-40" }, {
          header: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`Name`);
            } else {
              return [
                createTextVNode("Name")
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(` ${ssrInterpolate(unref(topic).name)}`);
            } else {
              return [
                createTextVNode(" " + toDisplayString(unref(topic).name), 1)
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(ssrRenderComponent(_component_BasicListItem, { "header-class": "w-40" }, {
          header: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`Description`);
            } else {
              return [
                createTextVNode("Description")
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(` ${ssrInterpolate(unref(topic).description)}`);
            } else {
              return [
                createTextVNode(" " + toDisplayString(unref(topic).description), 1)
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(ssrRenderComponent(_component_BasicListItem, { "header-class": "w-40" }, {
          header: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`Choices`);
            } else {
              return [
                createTextVNode("Choices")
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(` ${ssrInterpolate(unref(topic).choices.choices.map((ele) => ele.name).join(", "))}`);
            } else {
              return [
                createTextVNode(" " + toDisplayString(unref(topic).choices.choices.map((ele) => ele.name).join(", ")), 1)
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(ssrRenderComponent(_component_BasicListItem, { "header-class": "w-40" }, {
          header: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`User customable`);
            } else {
              return [
                createTextVNode("User customable")
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              if (unref(topic).choices.customable) {
                _push2(`<!--[-->`);
                _push2(ssrRenderComponent(_component_MaterialIcon, { icon: "check" }, null, _parent2, _scopeId));
                _push2(` Yes <!--]-->`);
              } else {
                _push2(`<!--[-->`);
                _push2(ssrRenderComponent(_component_MaterialIcon, { icon: "Close" }, null, _parent2, _scopeId));
                _push2(` No <!--]-->`);
              }
            } else {
              return [
                unref(topic).choices.customable ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                  createVNode(_component_MaterialIcon, { icon: "check" }),
                  createTextVNode(" Yes ")
                ], 64)) : (openBlock(), createBlock(Fragment, { key: 1 }, [
                  createVNode(_component_MaterialIcon, { icon: "Close" }),
                  createTextVNode(" No ")
                ], 64))
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(ssrRenderComponent(_component_BasicListItem, { "header-class": "w-40" }, {
          header: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`Voteable`);
            } else {
              return [
                createTextVNode("Voteable")
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              if (unref(isTopicExpired)(unref(topic))) {
                _push2(`<!--[-->`);
                _push2(ssrRenderComponent(_component_MaterialIcon, { icon: "check" }, null, _parent2, _scopeId));
                _push2(` Yes <!--]-->`);
              } else {
                _push2(`<!--[-->`);
                _push2(ssrRenderComponent(_component_MaterialIcon, { icon: "Close" }, null, _parent2, _scopeId));
                _push2(` No <!--]-->`);
              }
            } else {
              return [
                unref(isTopicExpired)(unref(topic)) ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                  createVNode(_component_MaterialIcon, { icon: "check" }),
                  createTextVNode(" Yes ")
                ], 64)) : (openBlock(), createBlock(Fragment, { key: 1 }, [
                  createVNode(_component_MaterialIcon, { icon: "Close" }),
                  createTextVNode(" No ")
                ], 64))
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(ssrRenderComponent(_component_BasicListItem, { "header-class": "w-40" }, {
          header: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`Expired`);
            } else {
              return [
                createTextVNode("Expired")
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              if (unref(isTopicExpired)(unref(topic))) {
                _push2(`<!--[-->`);
                _push2(ssrRenderComponent(_component_MaterialIcon, { icon: "check" }, null, _parent2, _scopeId));
                _push2(` Yes <!--]-->`);
              } else {
                _push2(`<!--[-->`);
                _push2(ssrRenderComponent(_component_MaterialIcon, { icon: "Close" }, null, _parent2, _scopeId));
                _push2(` No <!--]-->`);
              }
            } else {
              return [
                unref(isTopicExpired)(unref(topic)) ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                  createVNode(_component_MaterialIcon, { icon: "check" }),
                  createTextVNode(" Yes ")
                ], 64)) : (openBlock(), createBlock(Fragment, { key: 1 }, [
                  createVNode(_component_MaterialIcon, { icon: "Close" }),
                  createTextVNode(" No ")
                ], 64))
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div>`);
        if (unref(topic).status === "pending") {
          _push(`<div class="my-2 flex flex-col sm:flex-row sm:justify-center items-center flex-wrap gap-2"><button type="button" class="dga-evote-btn w-full sm:w-48 inline-flex gap-2 items-center justify-center" title="Approve Topic">`);
          _push(ssrRenderComponent(_component_MaterialIcon, { icon: "check" }, null, _parent));
          _push(`<span class="truncate">Approve Topic</span></button><button type="button" class="dga-evote-btn w-full sm:w-48 inline-flex gap-2 items-center justify-center" title="Reject Topic">`);
          _push(ssrRenderComponent(_component_MaterialIcon, { icon: "close" }, null, _parent));
          _push(`<span class="truncate">Reject Topic</span></button></div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`<div class="my-2 flex flex-col sm:flex-row sm:justify-center flex-wrap gap-2">`);
        if (unref(isAdminRole)) {
          _push(ssrRenderComponent(_component_NuxtLink, {
            to: `/topic/edit/${unref(topicid)}`,
            class: "w-full sm:w-64 block"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`<button type="button" class="dga-evote-btn w-full inline-flex gap-2 items-center justify-center" title="Edit Topic"${_scopeId}>`);
                _push2(ssrRenderComponent(_component_MaterialIcon, { icon: "edit" }, null, _parent2, _scopeId));
                _push2(`<span class="truncate"${_scopeId}>Edit Topic</span></button>`);
              } else {
                return [
                  createVNode("button", {
                    type: "button",
                    class: "dga-evote-btn w-full inline-flex gap-2 items-center justify-center",
                    title: "Edit Topic"
                  }, [
                    createVNode(_component_MaterialIcon, { icon: "edit" }),
                    createVNode("span", { class: "truncate" }, "Edit Topic")
                  ])
                ];
              }
            }),
            _: 1
          }, _parent));
        } else {
          _push(`<!---->`);
        }
        _push(`<button type="button" class="dga-evote-btn w-full sm:w-48 inline-flex gap-2 items-center justify-center" title="Back"><span class="truncate">Back</span></button></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/topic/info/[id].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_id_-8aa06f50.mjs.map
