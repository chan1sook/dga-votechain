import { defineEventHandler, getQuery, createError } from 'h3';
import dayjs from 'dayjs';
import { T as TopicModel } from './topic.mjs';
import { V as VoteModel } from './vote.mjs';
import { c as checkPermissionNeeds } from './node-server.mjs';
import 'mongoose';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'unstorage/drivers/redis';
import 'defu';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'nanoid';
import 'axios';

const topics_get = defineEventHandler(async (event) => {
  const { type, pagesize, startid } = getQuery(event);
  let topicsData = [];
  let voteIds = [];
  if (type === "notvoted" || type === "voted") {
    const userData = event.context.userData;
    if (!userData || !checkPermissionNeeds(userData.permissions, "vote-topic")) {
      throw createError({
        statusCode: 403,
        statusMessage: "Forbidden"
      });
    }
    const votes = await VoteModel.getLastestVotesByUserid(userData.userid, pagesize, startid);
    voteIds = votes.reduce((prev, current) => {
      if (current.topicid) {
        prev.push(current.topicid);
      }
      return prev;
    }, voteIds);
  }
  switch (type) {
    case "available":
      topicsData = await TopicModel.getLastestAvalaibleTopics(pagesize, startid);
      break;
    case "waiting":
      topicsData = await TopicModel.getLastestWaitingTopics(pagesize, startid);
      break;
    case "active":
      topicsData = await TopicModel.getLastestActiveTopics(pagesize, startid);
      break;
    case "notvoted":
      topicsData = await TopicModel.getLastestActiveTopics(pagesize, startid, voteIds);
      break;
    case "voted":
      topicsData = await TopicModel.getSelectedTopics(voteIds);
      break;
    case "finished":
      topicsData = await TopicModel.getLastestFinishedTopics(pagesize, startid);
      break;
    case "pending":
      topicsData = await TopicModel.getLastestPendingTopics(pagesize, startid);
      break;
    case "all":
      topicsData = await TopicModel.find(startid ? { _id: { $lt: startid } } : {}).limit(pagesize || 50).sort({ _id: -1 });
      break;
    default:
      topicsData = await TopicModel.getLastestAvalaibleTopics(pagesize, startid);
      break;
  }
  const topics = topicsData.map((topicData, i) => {
    return {
      _id: `${topicData._id}`,
      status: topicData.status,
      name: topicData.name,
      description: topicData.description,
      choices: topicData.choices,
      createdAt: dayjs(topicData.createdAt).toISOString(),
      updatedAt: dayjs(topicData.updatedAt).toISOString(),
      voteStartAt: dayjs(topicData.voteStartAt).toISOString(),
      voteExpiredAt: dayjs(topicData.voteExpiredAt).toISOString()
    };
  });
  return {
    topics
  };
});

export { topics_get as default };
//# sourceMappingURL=topics.get.mjs.map
