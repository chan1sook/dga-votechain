import { defineEventHandler, createError, readBody } from 'h3';
import dayjs from 'dayjs';
import { N as NewsModel } from './news.mjs';
import { i as isNewsFormValid } from './news2.mjs';
import { a as checkPermissionSelections } from './node-server.mjs';
import 'mongoose';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'unstorage/drivers/redis';
import 'defu';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'nanoid';
import 'axios';

const _id__post = defineEventHandler(async (event) => {
  var _a;
  const userData = event.context.userData;
  if (!userData || !checkPermissionSelections(userData.permissions, "change-news")) {
    throw createError({
      statusCode: 403,
      statusMessage: "Forbidden"
    });
  }
  const topicFormData = await readBody(event);
  const newsData = await NewsModel.findById((_a = event.context.params) == null ? void 0 : _a.id);
  if (!newsData) {
    throw createError({
      statusCode: 400,
      statusMessage: "News not found"
    });
  }
  newsData.updatedBy = userData.userid;
  newsData.updatedAt = /* @__PURE__ */ new Date();
  if (topicFormData.visibility !== void 0) {
    newsData.visibility = topicFormData.visibility;
  }
  if (topicFormData.title !== void 0) {
    newsData.title = topicFormData.title;
  }
  if (topicFormData.content !== void 0) {
    newsData.content = topicFormData.content;
  }
  if (topicFormData.author !== void 0) {
    newsData.author = topicFormData.author;
  }
  if (topicFormData.references !== void 0) {
    newsData.references = topicFormData.references;
  }
  if (topicFormData.newsPublishAt !== void 0) {
    newsData.newsPublishAt = dayjs(topicFormData.newsPublishAt).toDate();
  }
  if (topicFormData.newsExpiredAt !== void 0) {
    newsData.newsExpiredAt = topicFormData.newsExpiredAt ? dayjs(topicFormData.newsExpiredAt).toDate() : null;
  }
  if (!isNewsFormValid(newsData)) {
    throw createError({
      statusCode: 400,
      statusMessage: "Input Invalid"
    });
  }
  await newsData.save();
  const news = {
    _id: `${newsData._id}`,
    visibility: newsData.visibility,
    title: newsData.title,
    author: newsData.author,
    content: newsData.content,
    references: newsData.references,
    createdBy: newsData.createdBy,
    updatedBy: newsData.updatedBy,
    newsPublishAt: dayjs(newsData.newsPublishAt).toString(),
    newsExpiredAt: newsData.newsExpiredAt ? dayjs(newsData.newsExpiredAt).toString() : null,
    createdAt: dayjs(newsData.createdAt).toString(),
    updatedAt: dayjs(newsData.updatedAt).toString()
  };
  return {
    news
  };
});

export { _id__post as default };
//# sourceMappingURL=_id_.post5.mjs.map
