function isNewsFormValid(newsData) {
  return newsData.title !== "" && newsData.content !== "";
}

export { isNewsFormValid as i };
//# sourceMappingURL=news2.mjs.map
