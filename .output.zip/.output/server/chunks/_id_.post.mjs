import { defineEventHandler, createError, readBody } from 'h3';
import dayjs from 'dayjs';
import { T as TopicModel } from './topic.mjs';
import { a as isTopicFormValid } from './topic2.mjs';
import { a as checkPermissionSelections } from './node-server.mjs';
import 'mongoose';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'unstorage/drivers/redis';
import 'defu';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'nanoid';
import 'axios';

const _id__post = defineEventHandler(async (event) => {
  var _a;
  const userData = event.context.userData;
  if (!userData || !checkPermissionSelections(userData.permissions, "change-topic")) {
    throw createError({
      statusCode: 403,
      statusMessage: "Forbidden"
    });
  }
  const topicFormData = await readBody(event);
  const topicData = await TopicModel.findById((_a = event.context.params) == null ? void 0 : _a.id);
  if (!topicData) {
    throw createError({
      statusCode: 400,
      statusMessage: "Topic not found"
    });
  }
  topicData.updatedBy = userData.userid;
  topicData.updatedAt = /* @__PURE__ */ new Date();
  if (topicFormData.name !== void 0) {
    topicData.name = topicFormData.name;
  }
  if (topicFormData.description !== void 0) {
    topicData.description = topicFormData.description;
  }
  if (topicFormData.choices !== void 0) {
    topicData.choices = topicFormData.choices;
  }
  if (topicFormData.status !== void 0) {
    topicData.status = topicFormData.status;
  }
  if (topicFormData.voteStartAt !== void 0) {
    topicData.voteStartAt = dayjs(topicFormData.voteStartAt).toDate();
  }
  if (topicFormData.voteExpiredAt !== void 0) {
    topicData.voteExpiredAt = dayjs(topicFormData.voteExpiredAt).toDate();
  }
  if (!isTopicFormValid(topicData)) {
    throw createError({
      statusCode: 400,
      statusMessage: "Input Invalid"
    });
  }
  await topicData.save();
  const topic = {
    _id: topicData._id.toString(),
    status: topicData.status,
    name: topicData.name,
    description: topicData.description,
    choices: topicData.choices,
    voteStartAt: dayjs(topicData.voteStartAt).toISOString(),
    voteExpiredAt: dayjs(topicData.voteExpiredAt).toISOString(),
    createdAt: dayjs(topicData.createdAt).toISOString(),
    updatedAt: dayjs(topicData.updatedAt).toISOString()
  };
  return {
    topic
  };
});

export { _id__post as default };
//# sourceMappingURL=_id_.post.mjs.map
