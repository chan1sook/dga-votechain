import { h as useState } from './server.mjs';

const usePermissions = () => {
  return useState("permissions", () => []);
};

export { usePermissions as u };
//# sourceMappingURL=usePermissions-f45a7a74.mjs.map
