import { watch } from 'vue';
import dayjs from 'dayjs';

function useWatchNewsDateTimes(newsData, publishDateStr, publishTimeStr, expiredDateStr, expiredTimeStr, isNewsExpired) {
  watch(publishDateStr, (newValue) => {
    const newsPublishAt = dayjs(`${newValue} ${publishTimeStr.value}`, "YYYY-MM-DD HH:MM").toDate();
    const newsExpiredAt = dayjs(newsPublishAt).add(1, "year").toDate();
    newsData.value.newsPublishAt = newsPublishAt;
    newsData.value.newsExpiredAt = isNewsExpired.value ? newsPublishAt : null;
    expiredDateStr.value = dayjs(newsExpiredAt).format("YYYY-MM-DD");
    expiredTimeStr.value = dayjs(newsExpiredAt).format("HH:MM");
  });
  watch(publishTimeStr, (newValue) => {
    const newsPublishAt = dayjs(`${publishDateStr.value} ${newValue}`, "YYYY-MM-DD HH:MM").toDate();
    const newsExpiredAt = dayjs(newsPublishAt).add(1, "year").toDate();
    newsData.value.newsPublishAt = newsPublishAt;
    newsData.value.newsExpiredAt = isNewsExpired.value ? newsPublishAt : null;
    expiredDateStr.value = dayjs(newsExpiredAt).format("YYYY-MM-DD");
    expiredTimeStr.value = dayjs(newsExpiredAt).format("HH:MM");
  });
  watch(expiredDateStr, (newValue) => {
    newsData.value.newsExpiredAt = newValue ? dayjs(`${newValue} ${expiredTimeStr.value}`, "YYYY-MM-DD HH:MM").toDate() : null;
  });
  watch(expiredTimeStr, (newValue) => {
    newsData.value.newsExpiredAt = newValue ? dayjs(`${expiredDateStr.value} ${newValue}`, "YYYY-MM-DD HH:MM").toDate() : null;
  });
  watch(isNewsExpired, (newValue) => {
    newsData.value.newsExpiredAt = newValue ? dayjs(`${expiredDateStr.value} ${expiredTimeStr.value}`, "YYYY-MM-DD HH:MM").toDate() : null;
  });
}
function isNewsFormValid(newsData) {
  return newsData.title !== "" && newsData.content !== "";
}

export { isNewsFormValid as i, useWatchNewsDateTimes as u };
//# sourceMappingURL=news-f283fe82.mjs.map
