import { _ as __nuxt_component_0 } from './MaterialIcon-25e5e22f.mjs';
import { u as useHead, w as webAppName } from './server.mjs';
import { defineComponent, ref, computed, mergeProps, unref, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderAttr, ssrRenderList, ssrRenderComponent, ssrRenderClass, ssrIncludeBooleanAttr, ssrLooseContain } from 'vue/server-renderer';
import dayjs from 'dayjs';
import { g as getPresetChoices, i as isTopicFormValid, u as useWatchVoteDateTimes } from './topic-61a2c6cd.mjs';
import './_plugin-vue_export-helper-cc2b3d55.mjs';
import 'ofetch';
import 'hookable';
import 'unctx';
import '@unhead/vue';
import '@unhead/dom';
import '@unhead/ssr';
import 'vue-router';
import 'h3';
import 'ufo';
import 'defu';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'unstorage/drivers/redis';
import 'radix3';
import 'mongoose';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'nanoid';
import 'axios';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "request",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: `${webAppName} - Request Topic`
    });
    const startDate = dayjs().millisecond(0).toDate();
    const expiredDate = dayjs().add(1, "month").hour(0).minute(0).second(0).millisecond(0).toDate();
    const startDateStr = ref(dayjs(startDate).format("YYYY-MM-DD"));
    const startTimeStr = ref(dayjs(startDate).format("HH:MM"));
    const expiredDateStr = ref(dayjs(expiredDate).format("YYYY-MM-DD"));
    const expiredTimeStr = ref(dayjs(expiredDate).format("HH:MM"));
    const startExpiredDateStr = computed(() => dayjs(startDateStr.value, "YYYY-MM-DD").add(1, "day").format("YYYY-MM-DD"));
    const topicData = ref({
      name: "",
      description: "",
      choices: getPresetChoices(),
      voteStartAt: startDate,
      voteExpiredAt: expiredDate
    });
    const choiceEditable = ref(false);
    const newChoiceValue = ref("");
    const isNewValueValid = computed(() => {
      return newChoiceValue.value !== "" && !topicData.value.choices.choices.find((ele) => ele.name === newChoiceValue.value);
    });
    const isFormValid = computed(() => isTopicFormValid(topicData.value));
    useWatchVoteDateTimes(topicData, startDateStr, startTimeStr, expiredDateStr, expiredTimeStr);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_MaterialIcon = __nuxt_component_0;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "p-4 w-full mx-auto" }, _attrs))}><div class="border-2 border-gray-200 rounded-lg shadow p-4"><h1 class="text-3xl font-bold text-center mb-4">${ssrInterpolate(unref(webAppName))}</h1><h2 class="text-2xl font-bold text-center mb-4"> Request Topic </h2><div class="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-7xl mx-auto my-4"><div class="md:col-span-2 p-2 pb-0 flex flex-row items-center gap-2"><label class="flex-none">Name</label><input${ssrRenderAttr("value", unref(topicData).name)} type="text" class="dga-evote-input w-0 flex-1" placeholder="Topic name" required><span class="text-red-500" title="Required">*</span></div><div class="md:col-span-2 p-2 pb-0 flex flex-row items-start gap-2"><label class="flex-none">Description</label><textarea class="dga-evote-input w-0 flex-1 h-32" placeholder="Description" required>${ssrInterpolate(unref(topicData).description)}</textarea><span class="text-red-500" title="Required">*</span></div><div class="p-2 pb-0 flex flex-row items-center gap-2"><label class="flex-none">Vote Start</label><input${ssrRenderAttr("value", unref(startDateStr))} type="date" class="dga-evote-input w-0 flex-1" placeholder="Start Date"><input${ssrRenderAttr("value", unref(startTimeStr))} type="time" class="dga-evote-input w-0 flex-1" placeholder="Start Time"></div><div class="p-2 pb-0 flex flex-row items-center gap-2"><label class="flex-none">Vote Expired</label><input${ssrRenderAttr("value", unref(expiredDateStr))} type="date" class="dga-evote-input w-0 flex-1"${ssrRenderAttr("min", unref(startExpiredDateStr))} placeholder="Expired Date"><input${ssrRenderAttr("value", unref(expiredTimeStr))} type="time" class="dga-evote-input w-0 flex-1" placeholder="Expired Time"></div><div class="md:col-span-2 p-2 pb-0 flex flex-row items-center gap-2"><label class="flex-none">Preset Choices</label><select class="dga-evote-input w-0 flex-1"><option value="yesno">Yes/No</option><option value="custom">Custom</option></select></div><div class="md:col-span-2 p-2 pb-0 flex flex-row items-center gap-2"> Choices </div><div class="md:col-span-2 p-2 pb-0 flex flex-row flex-wrap items-center gap-2"><!--[-->`);
      ssrRenderList(unref(topicData).choices.choices, (choice, i) => {
        _push(`<div class="w-full md:w-[calc(50%-0.5rem)] lg:w-[calc(33.33%-0.5rem)] flex flex-row items-center">`);
        _push(ssrRenderComponent(_component_MaterialIcon, { icon: "chevron_right" }, null, _parent));
        _push(`<input${ssrRenderAttr("value", choice.name)} type="text" class="${ssrRenderClass([{
          "rounded-r-none": unref(choiceEditable) && i >= 2
        }, "dga-evote-input w-0 flex-1"])}">`);
        if (unref(choiceEditable) && i >= 2) {
          _push(`<button type="button" class="dga-evote-btn px-2 py-1 rounded-l-none rounded-r-md inline-flex flex-row items-center"${ssrRenderAttr("title", `Remove Choice [${choice.name}]`)}>`);
          _push(ssrRenderComponent(_component_MaterialIcon, { icon: "remove" }, null, _parent));
          _push(`</button>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      });
      _push(`<!--]-->`);
      if (unref(choiceEditable)) {
        _push(`<div class="w-full md:w-[calc(50%-0.5rem)] lg:w-[calc(33.33%-0.5rem)] flex flex-row items-center">`);
        _push(ssrRenderComponent(_component_MaterialIcon, { icon: "chevron_right" }, null, _parent));
        _push(`<div class="flex-1 inline-flex flex-row"><input${ssrRenderAttr("value", unref(newChoiceValue))} type="text" class="dga-evote-input w-0 flex-1 rounded-r-none" placeholder="New Choice"><button type="button" class="dga-evote-btn px-2 py-1 rounded-l-none rounded-r-md inline-flex flex-row items-center" title="Add Choice"${ssrIncludeBooleanAttr(!unref(isNewValueValid)) ? " disabled" : ""}>`);
        _push(ssrRenderComponent(_component_MaterialIcon, { icon: "add" }, null, _parent));
        _push(`</button></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="md:col-span-2 p-2 pb-0 flex flex-row items-center gap-2"><input${ssrIncludeBooleanAttr(Array.isArray(unref(topicData).choices.customable) ? ssrLooseContain(unref(topicData).choices.customable, null) : unref(topicData).choices.customable) ? " checked" : ""} type="checkbox"${ssrIncludeBooleanAttr(!unref(choiceEditable)) ? " disabled" : ""} class="scale-125"><label class="flex-none">Voter can custom choice</label></div><div class="md:col-span-2 my-2 text-center"><button type="button" class="dga-evote-btn w-full max-w-sm inline-flex gap-2 items-center justify-center" title="Request Topic"${ssrIncludeBooleanAttr(!unref(isFormValid)) ? " disabled" : ""}>`);
      _push(ssrRenderComponent(_component_MaterialIcon, { icon: "ballot" }, null, _parent));
      _push(`<span class="truncate">Request Topic</span></button></div></div></div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/topic/request.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=request-018eefcb.mjs.map
