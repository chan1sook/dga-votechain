import { defineEventHandler, sendRedirect } from 'h3';

const logout_get = defineEventHandler(async (event) => {
  await event.context.session.unset("userData");
  delete event.context.userData;
  return sendRedirect(event, "/");
});

export { logout_get as default };
//# sourceMappingURL=logout.get2.mjs.map
