import { _ as __nuxt_component_0 } from './BasicListItem-36ba5b36.mjs';
import { d as useRoute, u as useHead, w as webAppName, s as showError, f as formatDateTime } from './server.mjs';
import { defineComponent, withAsyncContext, ref, mergeProps, unref, withCtx, createTextVNode, toDisplayString, createVNode, openBlock, createBlock, Fragment, useSSRContext } from 'vue';
import { u as useFetch } from './fetch-f8b573e2.mjs';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent } from 'vue/server-renderer';
import './_plugin-vue_export-helper-cc2b3d55.mjs';
import 'ofetch';
import 'hookable';
import 'unctx';
import '@unhead/vue';
import '@unhead/dom';
import '@unhead/ssr';
import 'vue-router';
import 'h3';
import 'ufo';
import 'defu';
import 'dayjs';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'unstorage/drivers/redis';
import 'radix3';
import 'mongoose';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'nanoid';
import 'axios';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "[id]",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const { id: txid } = useRoute().params;
    useHead({
      title: `${webAppName} - TX Info #${txid}`
    });
    const { data } = ([__temp, __restore] = withAsyncContext(() => useFetch(`/api/tx/${txid}`, "$lQwBiaO6z6")), __temp = await __temp, __restore(), __temp);
    const tx = ref(void 0);
    if (!data.value) {
      showError("TX not found");
    } else {
      tx.value = data.value.tx;
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_BasicListItem = __nuxt_component_0;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "p-4 w-full mx-auto" }, _attrs))}>`);
      if (unref(tx)) {
        _push(`<div class="border-2 border-gray-200 rounded-lg shadow p-4"><h1 class="text-3xl font-bold text-center mb-4">${ssrInterpolate(unref(webAppName))}</h1><h2 class="text-2xl font-bold text-center mb-0"> TX Info </h2><div class="text-sm text-center text-gray-700 mb-4">#${ssrInterpolate(unref(txid))}</div><div class="my-2">`);
        _push(ssrRenderComponent(_component_BasicListItem, { "header-class": "w-40" }, {
          header: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`TX ID`);
            } else {
              return [
                createTextVNode("TX ID")
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(` ${ssrInterpolate(unref(tx)._id)}`);
            } else {
              return [
                createTextVNode(" " + toDisplayString(unref(tx)._id), 1)
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(ssrRenderComponent(_component_BasicListItem, { "header-class": "w-40" }, {
          header: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`Timestamp`);
            } else {
              return [
                createTextVNode("Timestamp")
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(` ${ssrInterpolate(unref(formatDateTime)(unref(tx).createdAt))}`);
            } else {
              return [
                createTextVNode(" " + toDisplayString(unref(formatDateTime)(unref(tx).createdAt)), 1)
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(ssrRenderComponent(_component_BasicListItem, { "header-class": "w-40" }, {
          header: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`Voted <abbr title="Digital ID UserID"${_scopeId}>UserID</abbr>`);
            } else {
              return [
                createTextVNode("Voted "),
                createVNode("abbr", { title: "Digital ID UserID" }, "UserID")
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(` ${ssrInterpolate(unref(tx).userid)}`);
            } else {
              return [
                createTextVNode(" " + toDisplayString(unref(tx).userid), 1)
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(ssrRenderComponent(_component_BasicListItem, { "header-class": "w-40" }, {
          header: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`Voted Topic ID`);
            } else {
              return [
                createTextVNode("Voted Topic ID")
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(` ${ssrInterpolate(unref(tx).topicid)}`);
            } else {
              return [
                createTextVNode(" " + toDisplayString(unref(tx).topicid), 1)
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(ssrRenderComponent(_component_BasicListItem, { "header-class": "w-40" }, {
          header: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`Choice`);
            } else {
              return [
                createTextVNode("Choice")
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              if (unref(tx).choice) {
                _push2(`<!--[-->${ssrInterpolate(unref(tx).choice)}<!--]-->`);
              } else {
                _push2(`<span class="italic"${_scopeId}>No Vote</span>`);
              }
            } else {
              return [
                unref(tx).choice ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                  createTextVNode(toDisplayString(unref(tx).choice), 1)
                ], 64)) : (openBlock(), createBlock("span", {
                  key: 1,
                  class: "italic"
                }, "No Vote"))
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div><div class="my-2 flex flex-col sm:flex-row sm:justify-center flex-wrap gap-2"><button type="button" class="dga-evote-btn w-full sm:w-48 inline-flex gap-2 items-center justify-center" title="Back"><span class="truncate">Back</span></button></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/tx/[id].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_id_-4f256e20.mjs.map
