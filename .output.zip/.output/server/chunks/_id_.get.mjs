import { defineEventHandler, createError } from 'h3';
import dayjs from 'dayjs';
import { V as VoteModel } from './vote.mjs';
import 'mongoose';

const _id__get = defineEventHandler(async (event) => {
  var _a;
  const voteDoc = await VoteModel.findById((_a = event.context.params) == null ? void 0 : _a.id);
  if (!voteDoc) {
    throw createError({
      statusCode: 404,
      statusMessage: "TX not found"
    });
  }
  const tx = {
    _id: `${voteDoc._id}`,
    userid: voteDoc.userid,
    topicid: `${voteDoc.topicid}`,
    choice: voteDoc.choice,
    createdAt: dayjs(voteDoc.createdAt).toString()
  };
  return {
    tx
  };
});

export { _id__get as default };
//# sourceMappingURL=_id_.get.mjs.map
