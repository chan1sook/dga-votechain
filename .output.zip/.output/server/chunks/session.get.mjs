import { defineEventHandler } from 'h3';

const session_get = defineEventHandler(async (event) => {
  const userData = event.context.userData;
  if (!userData) {
    return {
      permissions: []
    };
  } else {
    return {
      userid: userData.userid,
      permissions: userData.permissions
    };
  }
});

export { session_get as default };
//# sourceMappingURL=session.get.mjs.map
