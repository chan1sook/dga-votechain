import { _ as __nuxt_component_0 } from './DetailCard-846b0085.mjs';
import { _ as __nuxt_component_1 } from './BasicCard-350a4da3.mjs';
import { _ as __nuxt_component_0$1 } from './BasicListItem-36ba5b36.mjs';
import { d as useRoute, u as useHead, w as webAppName, s as showError } from './server.mjs';
import { defineComponent, withAsyncContext, ref, computed, mergeProps, unref, withCtx, createTextVNode, createVNode, toDisplayString, openBlock, createBlock, Fragment, renderList, createCommentVNode, useSSRContext } from 'vue';
import { u as useFetch } from './fetch-f8b573e2.mjs';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent, ssrRenderList } from 'vue/server-renderer';
import './_plugin-vue_export-helper-cc2b3d55.mjs';
import 'ofetch';
import 'hookable';
import 'unctx';
import '@unhead/vue';
import '@unhead/dom';
import '@unhead/ssr';
import 'vue-router';
import 'h3';
import 'ufo';
import 'defu';
import 'dayjs';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'unstorage/drivers/redis';
import 'radix3';
import 'mongoose';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'nanoid';
import 'axios';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "[id]",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const { id } = useRoute().params;
    let topicid = Array.isArray(id) ? id[id.length - 1] : id;
    useHead({
      title: `${webAppName} - Vote Result #${id}`
    });
    const { data } = ([__temp, __restore] = withAsyncContext(() => useFetch(`/api/topic/result/${topicid}`, "$fNesNuvuJT")), __temp = await __temp, __restore(), __temp);
    const voteResult = ref(void 0);
    const votes = computed(() => voteResult.value ? voteResult.value.votes : []);
    const choiceVoteResults = computed(() => {
      return votes.value.filter((ele) => ele.choice);
    });
    const novoteResult = computed(() => {
      return votes.value.find((ele) => !ele.choice);
    });
    const totalVotes = computed(() => {
      return votes.value.reduce((prev, current) => prev + current.count, 0);
    });
    if (!data.value) {
      showError("Topic not found or not finished");
    } else {
      const { voteResult: _voteResult } = data.value;
      voteResult.value = _voteResult;
    }
    function getPercentOf(vote) {
      if (totalVotes.value <= 0 || !vote) {
        return 0;
      }
      return vote.count * 100 / totalVotes.value;
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_DetailCard = __nuxt_component_0;
      const _component_BasicCard = __nuxt_component_1;
      const _component_BasicListItem = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "p-4 w-full mx-auto" }, _attrs))}>`);
      if (unref(voteResult)) {
        _push(`<div class="border-2 border-gray-200 rounded-lg shadow p-4"><h1 class="text-3xl font-bold text-center mb-4">${ssrInterpolate(unref(webAppName))}</h1><h2 class="text-2xl font-bold text-center mb-0"> Vote Result </h2><div class="text-base font-bold text-center text-gray-700">${ssrInterpolate(unref(voteResult).name)}</div><div class="text-sm text-center text-gray-700 mb-4">#${ssrInterpolate(unref(topicid))}</div><div class="grid grid-cols-1 md:grid-cols-3 gap-4 my-2">`);
        _push(ssrRenderComponent(_component_DetailCard, { class: "self-start" }, {
          header: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`\u0E23\u0E32\u0E22\u0E25\u0E30\u0E40\u0E2D\u0E35\u0E22\u0E14`);
            } else {
              return [
                createTextVNode("\u0E23\u0E32\u0E22\u0E25\u0E30\u0E40\u0E2D\u0E35\u0E22\u0E14")
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="p-2"${_scopeId}>${ssrInterpolate(unref(voteResult).description)}</div>`);
            } else {
              return [
                createVNode("div", { class: "p-2" }, toDisplayString(unref(voteResult).description), 1)
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`<div class="md:col-span-2">`);
        _push(ssrRenderComponent(_component_BasicCard, null, {
          header: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`\u0E1C\u0E25\u0E01\u0E32\u0E23\u0E42\u0E2B\u0E27\u0E15`);
            } else {
              return [
                createTextVNode("\u0E1C\u0E25\u0E01\u0E32\u0E23\u0E42\u0E2B\u0E27\u0E15")
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="p-2 overflow-auto max-h-60"${_scopeId}><!--[-->`);
              ssrRenderList(unref(choiceVoteResults), (vote) => {
                _push2(ssrRenderComponent(_component_BasicListItem, { "header-class": "w-20" }, {
                  header: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(`${ssrInterpolate(getPercentOf(vote).toFixed(2))}%`);
                    } else {
                      return [
                        createTextVNode(toDisplayString(getPercentOf(vote).toFixed(2)) + "%", 1)
                      ];
                    }
                  }),
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(` ${ssrInterpolate(vote.choice)} (${ssrInterpolate(vote.count)}) `);
                    } else {
                      return [
                        createTextVNode(" " + toDisplayString(vote.choice) + " (" + toDisplayString(vote.count) + ") ", 1)
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
              });
              _push2(`<!--]-->`);
              if (unref(choiceVoteResults).length > 0) {
                _push2(`<hr class="my-2 border-t-2"${_scopeId}>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(ssrRenderComponent(_component_BasicListItem, { "header-class": "w-20" }, {
                header: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`${ssrInterpolate(getPercentOf(unref(novoteResult)).toFixed(2))}%`);
                  } else {
                    return [
                      createTextVNode(toDisplayString(getPercentOf(unref(novoteResult)).toFixed(2)) + "%", 1)
                    ];
                  }
                }),
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(` Total Votes (${ssrInterpolate(unref(totalVotes))}) `);
                  } else {
                    return [
                      createTextVNode(" Total Votes (" + toDisplayString(unref(totalVotes)) + ") ", 1)
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push2(`</div>`);
            } else {
              return [
                createVNode("div", { class: "p-2 overflow-auto max-h-60" }, [
                  (openBlock(true), createBlock(Fragment, null, renderList(unref(choiceVoteResults), (vote) => {
                    return openBlock(), createBlock(_component_BasicListItem, { "header-class": "w-20" }, {
                      header: withCtx(() => [
                        createTextVNode(toDisplayString(getPercentOf(vote).toFixed(2)) + "%", 1)
                      ]),
                      default: withCtx(() => [
                        createTextVNode(" " + toDisplayString(vote.choice) + " (" + toDisplayString(vote.count) + ") ", 1)
                      ]),
                      _: 2
                    }, 1024);
                  }), 256)),
                  unref(choiceVoteResults).length > 0 ? (openBlock(), createBlock("hr", {
                    key: 0,
                    class: "my-2 border-t-2"
                  })) : createCommentVNode("", true),
                  createVNode(_component_BasicListItem, { "header-class": "w-20" }, {
                    header: withCtx(() => [
                      createTextVNode(toDisplayString(getPercentOf(unref(novoteResult)).toFixed(2)) + "%", 1)
                    ]),
                    default: withCtx(() => [
                      createTextVNode(" Total Votes (" + toDisplayString(unref(totalVotes)) + ") ", 1)
                    ]),
                    _: 1
                  })
                ])
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/topic/result/[id].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_id_-9f8fbd05.mjs.map
