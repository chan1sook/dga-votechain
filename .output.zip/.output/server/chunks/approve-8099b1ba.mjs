import { _ as __nuxt_component_1 } from './BasicCard-350a4da3.mjs';
import { _ as __nuxt_component_0 } from './BasicListItem-36ba5b36.mjs';
import { _ as __nuxt_component_0$1 } from './MaterialIcon-25e5e22f.mjs';
import { u as useHead, w as webAppName, s as showError } from './server.mjs';
import { defineComponent, withAsyncContext, ref, mergeProps, unref, withCtx, createTextVNode, createVNode, toDisplayString, openBlock, createBlock, createCommentVNode, Fragment, renderList, useSSRContext } from 'vue';
import { u as useFetch } from './fetch-f8b573e2.mjs';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent, ssrRenderList, ssrRenderAttr } from 'vue/server-renderer';
import { g as getFullPermissionTitle } from './permissions-2a4aee66.mjs';
import './_plugin-vue_export-helper-cc2b3d55.mjs';
import 'ofetch';
import 'hookable';
import 'unctx';
import '@unhead/vue';
import '@unhead/dom';
import '@unhead/ssr';
import 'vue-router';
import 'h3';
import 'ufo';
import 'defu';
import 'dayjs';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'unstorage/drivers/redis';
import 'radix3';
import 'mongoose';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'nanoid';
import 'axios';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "approve",
  __ssrInlineRender: true,
  async setup(__props) {
    var _a;
    let __temp, __restore;
    useHead({
      title: `${webAppName} - Approve Request Permissions`
    });
    const { data } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/permissions/request/lists", "$SNMpSvGDPd")), __temp = await __temp, __restore(), __temp);
    const permissionsList = ref([]);
    if (!data.value) {
      showError("Can't get Request Permissions List");
    } else {
      permissionsList.value = (_a = data.value) == null ? void 0 : _a.requestPermissions;
    }
    function formatFullName(digitalIdData) {
      const { given_name, family_name, middle_name } = digitalIdData;
      let result = given_name;
      if (middle_name) {
        result += ` (${middle_name})`;
      }
      result += ` ${family_name}`;
      return result;
    }
    async function setApprovePermissions(id, status) {
      var _a2;
      await useFetch(`/api/permissions/approve/${id}`, {
        method: "POST",
        body: {
          status
        }
      }, "$q5bIAnzg6Q");
      const { data: data2 } = await useFetch("/api/permissions/request/lists", "$jIi9KO2Coe");
      if (!data2.value) {
        showError("Can't get Request Permissions List");
      } else {
        permissionsList.value = (_a2 = data2.value) == null ? void 0 : _a2.requestPermissions;
      }
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_BasicCard = __nuxt_component_1;
      const _component_BasicListItem = __nuxt_component_0;
      const _component_MaterialIcon = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "p-4 w-full mx-auto" }, _attrs))}><div class="border-2 border-gray-200 rounded-lg shadow p-4"><h1 class="text-3xl font-bold text-center mb-4">${ssrInterpolate(unref(webAppName))}</h1><h2 class="text-2xl font-bold text-center mb-4"> Approve Request Permissions </h2><div class="grid grid-cols-1 gap-4 max-w-7xl mx-auto my-4">`);
      _push(ssrRenderComponent(_component_BasicCard, null, {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Request Permissions`);
          } else {
            return [
              createTextVNode("Request Permissions")
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            if (unref(permissionsList).length > 0) {
              _push2(`<div class="p-2 overflow-auto max-h-60"${_scopeId}><!--[-->`);
              ssrRenderList(unref(permissionsList), (data2) => {
                _push2(ssrRenderComponent(_component_BasicListItem, {
                  "header-class": "w-16",
                  "no-animation": "",
                  "unlimit-lines": ""
                }, {
                  header: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(`<button type="button" class="inline-flex gap-2 items-center justify-center" title="Approve"${_scopeId2}>`);
                      _push3(ssrRenderComponent(_component_MaterialIcon, { icon: "check" }, null, _parent3, _scopeId2));
                      _push3(`</button><button type="button" class="inline-flex gap-2 items-center justify-center" title="Reject"${_scopeId2}>`);
                      _push3(ssrRenderComponent(_component_MaterialIcon, { icon: "close" }, null, _parent3, _scopeId2));
                      _push3(`</button>`);
                    } else {
                      return [
                        createVNode("button", {
                          type: "button",
                          class: "inline-flex gap-2 items-center justify-center",
                          title: "Approve",
                          onClick: ($event) => setApprovePermissions(data2._id, "approved")
                        }, [
                          createVNode(_component_MaterialIcon, { icon: "check" })
                        ], 8, ["onClick"]),
                        createVNode("button", {
                          type: "button",
                          class: "inline-flex gap-2 items-center justify-center",
                          title: "Reject",
                          onClick: ($event) => setApprovePermissions(data2._id, "rejected")
                        }, [
                          createVNode(_component_MaterialIcon, { icon: "close" })
                        ], 8, ["onClick"])
                      ];
                    }
                  }),
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(`<div class="flex flex-row gap-2 flex-wrap"${_scopeId2}><b${_scopeId2}>Userid:</b><span${_scopeId2}>${ssrInterpolate(data2.userid)}</span></div><div class="flex flex-row gap-2 flex-wrap"${_scopeId2}><b${_scopeId2}>Some DID Data:</b><abbr title="Citizen ID"${_scopeId2}>${ssrInterpolate(data2.digitalIdUserInfo.citizen_id)}</abbr><abbr title="Name"${_scopeId2}>${ssrInterpolate(formatFullName(data2.digitalIdUserInfo))}</abbr>`);
                      if (data2.digitalIdUserInfo.email) {
                        _push3(`<abbr title="Email"${_scopeId2}>${ssrInterpolate(data2.digitalIdUserInfo.email)}</abbr>`);
                      } else {
                        _push3(`<!---->`);
                      }
                      _push3(`</div><div class="flex flex-row gap-2 flex-wrap"${_scopeId2}><b${_scopeId2}>Note:</b>`);
                      if (data2.note) {
                        _push3(`<span${_scopeId2}>${ssrInterpolate(data2.note)}</span>`);
                      } else {
                        _push3(`<span class="italic"${_scopeId2}>None</span>`);
                      }
                      _push3(`</div><div class="flex flex-row gap-x-2 flex-wrap"${_scopeId2}><b${_scopeId2}>Permissions: </b><!--[-->`);
                      ssrRenderList(data2.permissions, (permission) => {
                        _push3(`<abbr${ssrRenderAttr("title", unref(getFullPermissionTitle)(permission))}${_scopeId2}>${ssrInterpolate(permission)}</abbr>`);
                      });
                      _push3(`<!--]--></div>`);
                    } else {
                      return [
                        createVNode("div", { class: "flex flex-row gap-2 flex-wrap" }, [
                          createVNode("b", null, "Userid:"),
                          createVNode("span", null, toDisplayString(data2.userid), 1)
                        ]),
                        createVNode("div", { class: "flex flex-row gap-2 flex-wrap" }, [
                          createVNode("b", null, "Some DID Data:"),
                          createVNode("abbr", { title: "Citizen ID" }, toDisplayString(data2.digitalIdUserInfo.citizen_id), 1),
                          createVNode("abbr", { title: "Name" }, toDisplayString(formatFullName(data2.digitalIdUserInfo)), 1),
                          data2.digitalIdUserInfo.email ? (openBlock(), createBlock("abbr", {
                            key: 0,
                            title: "Email"
                          }, toDisplayString(data2.digitalIdUserInfo.email), 1)) : createCommentVNode("", true)
                        ]),
                        createVNode("div", { class: "flex flex-row gap-2 flex-wrap" }, [
                          createVNode("b", null, "Note:"),
                          data2.note ? (openBlock(), createBlock("span", { key: 0 }, toDisplayString(data2.note), 1)) : (openBlock(), createBlock("span", {
                            key: 1,
                            class: "italic"
                          }, "None"))
                        ]),
                        createVNode("div", { class: "flex flex-row gap-x-2 flex-wrap" }, [
                          createVNode("b", null, "Permissions: "),
                          (openBlock(true), createBlock(Fragment, null, renderList(data2.permissions, (permission) => {
                            return openBlock(), createBlock("abbr", {
                              title: unref(getFullPermissionTitle)(permission)
                            }, toDisplayString(permission), 9, ["title"]);
                          }), 256))
                        ])
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
              });
              _push2(`<!--]--></div>`);
            } else {
              _push2(`<div class="p-2 text-center italic"${_scopeId}>Not found</div>`);
            }
          } else {
            return [
              unref(permissionsList).length > 0 ? (openBlock(), createBlock("div", {
                key: 0,
                class: "p-2 overflow-auto max-h-60"
              }, [
                (openBlock(true), createBlock(Fragment, null, renderList(unref(permissionsList), (data2) => {
                  return openBlock(), createBlock(_component_BasicListItem, {
                    "header-class": "w-16",
                    "no-animation": "",
                    "unlimit-lines": ""
                  }, {
                    header: withCtx(() => [
                      createVNode("button", {
                        type: "button",
                        class: "inline-flex gap-2 items-center justify-center",
                        title: "Approve",
                        onClick: ($event) => setApprovePermissions(data2._id, "approved")
                      }, [
                        createVNode(_component_MaterialIcon, { icon: "check" })
                      ], 8, ["onClick"]),
                      createVNode("button", {
                        type: "button",
                        class: "inline-flex gap-2 items-center justify-center",
                        title: "Reject",
                        onClick: ($event) => setApprovePermissions(data2._id, "rejected")
                      }, [
                        createVNode(_component_MaterialIcon, { icon: "close" })
                      ], 8, ["onClick"])
                    ]),
                    default: withCtx(() => [
                      createVNode("div", { class: "flex flex-row gap-2 flex-wrap" }, [
                        createVNode("b", null, "Userid:"),
                        createVNode("span", null, toDisplayString(data2.userid), 1)
                      ]),
                      createVNode("div", { class: "flex flex-row gap-2 flex-wrap" }, [
                        createVNode("b", null, "Some DID Data:"),
                        createVNode("abbr", { title: "Citizen ID" }, toDisplayString(data2.digitalIdUserInfo.citizen_id), 1),
                        createVNode("abbr", { title: "Name" }, toDisplayString(formatFullName(data2.digitalIdUserInfo)), 1),
                        data2.digitalIdUserInfo.email ? (openBlock(), createBlock("abbr", {
                          key: 0,
                          title: "Email"
                        }, toDisplayString(data2.digitalIdUserInfo.email), 1)) : createCommentVNode("", true)
                      ]),
                      createVNode("div", { class: "flex flex-row gap-2 flex-wrap" }, [
                        createVNode("b", null, "Note:"),
                        data2.note ? (openBlock(), createBlock("span", { key: 0 }, toDisplayString(data2.note), 1)) : (openBlock(), createBlock("span", {
                          key: 1,
                          class: "italic"
                        }, "None"))
                      ]),
                      createVNode("div", { class: "flex flex-row gap-x-2 flex-wrap" }, [
                        createVNode("b", null, "Permissions: "),
                        (openBlock(true), createBlock(Fragment, null, renderList(data2.permissions, (permission) => {
                          return openBlock(), createBlock("abbr", {
                            title: unref(getFullPermissionTitle)(permission)
                          }, toDisplayString(permission), 9, ["title"]);
                        }), 256))
                      ])
                    ]),
                    _: 2
                  }, 1024);
                }), 256))
              ])) : (openBlock(), createBlock("div", {
                key: 1,
                class: "p-2 text-center italic"
              }, "Not found"))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/permissions/approve.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=approve-8099b1ba.mjs.map
