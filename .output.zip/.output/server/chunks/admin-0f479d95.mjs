import { _ as __nuxt_component_1 } from './BasicCard-350a4da3.mjs';
import { _ as __nuxt_component_2 } from './nuxt-link-c6bcda1e.mjs';
import { _ as __nuxt_component_0 } from './BasicListItem-36ba5b36.mjs';
import { _ as __nuxt_component_0$1 } from './MaterialIcon-25e5e22f.mjs';
import { u as useHead, w as webAppName, f as formatDateTime } from './server.mjs';
import { defineComponent, computed, ref, withAsyncContext, mergeProps, unref, withCtx, createTextVNode, toDisplayString, createVNode, openBlock, createBlock, Fragment, renderList, createCommentVNode, useSSRContext } from 'vue';
import { u as useFetch } from './fetch-f8b573e2.mjs';
import { u as usePermissions } from './usePermissions-f45a7a74.mjs';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent, ssrRenderList } from 'vue/server-renderer';
import { c as checkPermissionNeeds } from './permissions-2a4aee66.mjs';
import './_plugin-vue_export-helper-cc2b3d55.mjs';
import 'ufo';
import 'ofetch';
import 'hookable';
import 'unctx';
import '@unhead/vue';
import '@unhead/dom';
import '@unhead/ssr';
import 'vue-router';
import 'h3';
import 'defu';
import 'dayjs';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'unstorage/drivers/redis';
import 'radix3';
import 'mongoose';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'nanoid';
import 'axios';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "admin",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    useHead({
      title: `${webAppName} - Admin Page`
    });
    computed(() => {
      return checkPermissionNeeds(usePermissions().value, "access-pages:developer");
    });
    const loadedTopics = ref({
      pending: [],
      available: []
    });
    const news = ref([]);
    const pagesize = ref(50);
    const startids = computed(() => {
      const pendingStartid = loadedTopics.value.pending.length > 0 ? loadedTopics.value.pending[loadedTopics.value.pending.length - 1]._id : void 0;
      const availableStartid = loadedTopics.value.available.length > 0 ? loadedTopics.value.available[loadedTopics.value.available.length - 1]._id : void 0;
      const newsStartid = news.value.length > 0 ? news.value[news.value.length - 1]._id : void 0;
      return {
        pending: pendingStartid,
        available: availableStartid,
        news: newsStartid
      };
    });
    const hasMoreTopics = ref({
      pending: false,
      available: false
    });
    const hasMoreNews = ref(false);
    const isLoadMoreTopics = ref({
      pending: false,
      available: false
    });
    const isLoadMoreNews = ref(false);
    async function fetchTopics(type, pagesize2, startid) {
      const fetchResult = await Promise.all([
        useFetch("/api/topics", {
          query: { type, pagesize: pagesize2, startid }
        }, "$4y9e2A2xrw")
      ]);
      const [topics] = fetchResult.map((ele) => ele.data.value);
      return topics;
    }
    async function loadMoreTopics(type) {
      isLoadMoreTopics.value[type] = true;
      const topics = await fetchTopics(type, pagesize.value, startids.value[type]);
      if (topics) {
        loadedTopics.value[type].push(...topics.topics);
        hasMoreTopics.value[type] = topics.topics.length === pagesize.value;
      }
      isLoadMoreTopics.value[type] = false;
    }
    async function fetchNews(pagesize2, startid) {
      const fetchResult = await Promise.all([
        useFetch("/api/news", {
          query: { type: "available", pagesize: pagesize2, startid }
        }, "$AGD8uqE2eg")
      ]);
      const [news2] = fetchResult.map((ele) => ele.data.value);
      return news2;
    }
    async function loadMoreNews() {
      isLoadMoreNews.value = true;
      const _news = await fetchNews(pagesize.value, startids.value.news);
      if (_news) {
        news.value.push(..._news.news);
        hasMoreNews.value = _news.news.length === pagesize.value;
      }
      isLoadMoreNews.value = true;
    }
    [__temp, __restore] = withAsyncContext(() => loadMoreTopics("available")), await __temp, __restore();
    [__temp, __restore] = withAsyncContext(() => loadMoreTopics("pending")), await __temp, __restore();
    [__temp, __restore] = withAsyncContext(() => loadMoreNews()), await __temp, __restore();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_BasicCard = __nuxt_component_1;
      const _component_NuxtLink = __nuxt_component_2;
      const _component_BasicListItem = __nuxt_component_0;
      const _component_MaterialIcon = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "p-4 w-full mx-auto" }, _attrs))}><div class="border-2 border-gray-200 rounded-lg shadow p-4"><h1 class="text-3xl font-bold text-center mb-4">${ssrInterpolate(unref(webAppName))}</h1><h2 class="text-2xl font-bold text-center mb-4"> Admin </h2><div class="grid grid-cols-1 gap-4 md:grid-cols-2 max-w-7xl mx-auto my-4">`);
      _push(ssrRenderComponent(_component_BasicCard, null, {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E42\u0E2B\u0E27\u0E15`);
          } else {
            return [
              createTextVNode("\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E42\u0E2B\u0E27\u0E15")
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            if (unref(loadedTopics).available.length > 0) {
              _push2(`<div class="p-2 overflow-auto max-h-60"${_scopeId}><!--[-->`);
              ssrRenderList(unref(loadedTopics).available, (topic, i) => {
                _push2(ssrRenderComponent(_component_NuxtLink, {
                  to: `/topic/info/${topic._id}`
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(ssrRenderComponent(_component_BasicListItem, null, {
                        header: withCtx((_3, _push4, _parent4, _scopeId3) => {
                          if (_push4) {
                            _push4(`${ssrInterpolate(i + 1)}.`);
                          } else {
                            return [
                              createTextVNode(toDisplayString(i + 1) + ".", 1)
                            ];
                          }
                        }),
                        default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                          if (_push4) {
                            _push4(` ${ssrInterpolate(topic.name)}`);
                          } else {
                            return [
                              createTextVNode(" " + toDisplayString(topic.name), 1)
                            ];
                          }
                        }),
                        _: 2
                      }, _parent3, _scopeId2));
                    } else {
                      return [
                        createVNode(_component_BasicListItem, null, {
                          header: withCtx(() => [
                            createTextVNode(toDisplayString(i + 1) + ".", 1)
                          ]),
                          default: withCtx(() => [
                            createTextVNode(" " + toDisplayString(topic.name), 1)
                          ]),
                          _: 2
                        }, 1024)
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
              });
              _push2(`<!--]-->`);
              if (unref(hasMoreTopics).available) {
                _push2(`<!--[-->`);
                if (!unref(isLoadMoreTopics).available) {
                  _push2(`<div class="my-2 flex flex-col sm:flex-row sm:justify-center flex-wrap gap-2"${_scopeId}><button type="button" class="dga-evote-btn w-full sm:w-48 inline-flex gap-2 items-center justify-center" title="Load More Topic"${_scopeId}>`);
                  _push2(ssrRenderComponent(_component_MaterialIcon, { icon: "autorenew" }, null, _parent2, _scopeId));
                  _push2(`<span class="truncate"${_scopeId}>Load More</span></button></div>`);
                } else {
                  _push2(`<div class="p-2 text-center italic"${_scopeId}>Loading...</div>`);
                }
                _push2(`<!--]-->`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div>`);
            } else {
              _push2(`<div class="p-2 text-center italic"${_scopeId}>Topics not found</div>`);
            }
          } else {
            return [
              unref(loadedTopics).available.length > 0 ? (openBlock(), createBlock("div", {
                key: 0,
                class: "p-2 overflow-auto max-h-60"
              }, [
                (openBlock(true), createBlock(Fragment, null, renderList(unref(loadedTopics).available, (topic, i) => {
                  return openBlock(), createBlock(_component_NuxtLink, {
                    to: `/topic/info/${topic._id}`
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_BasicListItem, null, {
                        header: withCtx(() => [
                          createTextVNode(toDisplayString(i + 1) + ".", 1)
                        ]),
                        default: withCtx(() => [
                          createTextVNode(" " + toDisplayString(topic.name), 1)
                        ]),
                        _: 2
                      }, 1024)
                    ]),
                    _: 2
                  }, 1032, ["to"]);
                }), 256)),
                unref(hasMoreTopics).available ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                  !unref(isLoadMoreTopics).available ? (openBlock(), createBlock("div", {
                    key: 0,
                    class: "my-2 flex flex-col sm:flex-row sm:justify-center flex-wrap gap-2"
                  }, [
                    createVNode("button", {
                      type: "button",
                      class: "dga-evote-btn w-full sm:w-48 inline-flex gap-2 items-center justify-center",
                      title: "Load More Topic",
                      onClick: ($event) => loadMoreTopics("available")
                    }, [
                      createVNode(_component_MaterialIcon, { icon: "autorenew" }),
                      createVNode("span", { class: "truncate" }, "Load More")
                    ], 8, ["onClick"])
                  ])) : (openBlock(), createBlock("div", {
                    key: 1,
                    class: "p-2 text-center italic"
                  }, "Loading..."))
                ], 64)) : createCommentVNode("", true)
              ])) : (openBlock(), createBlock("div", {
                key: 1,
                class: "p-2 text-center italic"
              }, "Topics not found"))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_BasicCard, null, {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E42\u0E2B\u0E27\u0E15\u0E23\u0E2D\u0E2D\u0E19\u0E38\u0E21\u0E31\u0E15\u0E34`);
          } else {
            return [
              createTextVNode("\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E42\u0E2B\u0E27\u0E15\u0E23\u0E2D\u0E2D\u0E19\u0E38\u0E21\u0E31\u0E15\u0E34")
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            if (unref(loadedTopics).pending.length > 0) {
              _push2(`<div class="p-2 overflow-auto max-h-60"${_scopeId}><!--[-->`);
              ssrRenderList(unref(loadedTopics).pending, (topic, i) => {
                _push2(ssrRenderComponent(_component_NuxtLink, {
                  to: `/topic/info/${topic._id}`
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(ssrRenderComponent(_component_BasicListItem, null, {
                        header: withCtx((_3, _push4, _parent4, _scopeId3) => {
                          if (_push4) {
                            _push4(`${ssrInterpolate(i + 1)}.`);
                          } else {
                            return [
                              createTextVNode(toDisplayString(i + 1) + ".", 1)
                            ];
                          }
                        }),
                        default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                          if (_push4) {
                            _push4(` ${ssrInterpolate(topic.name)}`);
                          } else {
                            return [
                              createTextVNode(" " + toDisplayString(topic.name), 1)
                            ];
                          }
                        }),
                        _: 2
                      }, _parent3, _scopeId2));
                    } else {
                      return [
                        createVNode(_component_BasicListItem, null, {
                          header: withCtx(() => [
                            createTextVNode(toDisplayString(i + 1) + ".", 1)
                          ]),
                          default: withCtx(() => [
                            createTextVNode(" " + toDisplayString(topic.name), 1)
                          ]),
                          _: 2
                        }, 1024)
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
              });
              _push2(`<!--]-->`);
              if (unref(hasMoreTopics).pending) {
                _push2(`<!--[-->`);
                if (!unref(isLoadMoreTopics).pending) {
                  _push2(`<div class="my-2 flex flex-col sm:flex-row sm:justify-center flex-wrap gap-2"${_scopeId}><button type="button" class="dga-evote-btn w-full sm:w-48 inline-flex gap-2 items-center justify-center" title="Load More Topic"${_scopeId}>`);
                  _push2(ssrRenderComponent(_component_MaterialIcon, { icon: "autorenew" }, null, _parent2, _scopeId));
                  _push2(`<span class="truncate"${_scopeId}>Load More</span></button></div>`);
                } else {
                  _push2(`<div class="p-2 text-center italic"${_scopeId}>Loading...</div>`);
                }
                _push2(`<!--]-->`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div>`);
            } else {
              _push2(`<div class="p-2 text-center italic"${_scopeId}>Topics not found</div>`);
            }
          } else {
            return [
              unref(loadedTopics).pending.length > 0 ? (openBlock(), createBlock("div", {
                key: 0,
                class: "p-2 overflow-auto max-h-60"
              }, [
                (openBlock(true), createBlock(Fragment, null, renderList(unref(loadedTopics).pending, (topic, i) => {
                  return openBlock(), createBlock(_component_NuxtLink, {
                    to: `/topic/info/${topic._id}`
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_BasicListItem, null, {
                        header: withCtx(() => [
                          createTextVNode(toDisplayString(i + 1) + ".", 1)
                        ]),
                        default: withCtx(() => [
                          createTextVNode(" " + toDisplayString(topic.name), 1)
                        ]),
                        _: 2
                      }, 1024)
                    ]),
                    _: 2
                  }, 1032, ["to"]);
                }), 256)),
                unref(hasMoreTopics).pending ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                  !unref(isLoadMoreTopics).pending ? (openBlock(), createBlock("div", {
                    key: 0,
                    class: "my-2 flex flex-col sm:flex-row sm:justify-center flex-wrap gap-2"
                  }, [
                    createVNode("button", {
                      type: "button",
                      class: "dga-evote-btn w-full sm:w-48 inline-flex gap-2 items-center justify-center",
                      title: "Load More Topic",
                      onClick: ($event) => loadMoreTopics("pending")
                    }, [
                      createVNode(_component_MaterialIcon, { icon: "autorenew" }),
                      createVNode("span", { class: "truncate" }, "Load More")
                    ], 8, ["onClick"])
                  ])) : (openBlock(), createBlock("div", {
                    key: 1,
                    class: "p-2 text-center italic"
                  }, "Loading..."))
                ], 64)) : createCommentVNode("", true)
              ])) : (openBlock(), createBlock("div", {
                key: 1,
                class: "p-2 text-center italic"
              }, "Topics not found"))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_BasicCard, null, {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u0E01\u0E23\u0E30\u0E14\u0E32\u0E19\u0E02\u0E48\u0E32\u0E27`);
          } else {
            return [
              createTextVNode("\u0E01\u0E23\u0E30\u0E14\u0E32\u0E19\u0E02\u0E48\u0E32\u0E27")
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            if (unref(news).length > 0) {
              _push2(`<div class="p-2 overflow-auto max-h-60"${_scopeId}><!--[-->`);
              ssrRenderList(unref(news), (data) => {
                _push2(ssrRenderComponent(_component_NuxtLink, {
                  to: `/news/info/${data._id}`
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(ssrRenderComponent(_component_BasicListItem, { "header-class": "w-44" }, {
                        header: withCtx((_3, _push4, _parent4, _scopeId3) => {
                          if (_push4) {
                            _push4(`${ssrInterpolate(unref(formatDateTime)(data.newsPublishAt))}.`);
                          } else {
                            return [
                              createTextVNode(toDisplayString(unref(formatDateTime)(data.newsPublishAt)) + ".", 1)
                            ];
                          }
                        }),
                        default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                          if (_push4) {
                            _push4(` ${ssrInterpolate(data.title)}`);
                          } else {
                            return [
                              createTextVNode(" " + toDisplayString(data.title), 1)
                            ];
                          }
                        }),
                        _: 2
                      }, _parent3, _scopeId2));
                    } else {
                      return [
                        createVNode(_component_BasicListItem, { "header-class": "w-44" }, {
                          header: withCtx(() => [
                            createTextVNode(toDisplayString(unref(formatDateTime)(data.newsPublishAt)) + ".", 1)
                          ]),
                          default: withCtx(() => [
                            createTextVNode(" " + toDisplayString(data.title), 1)
                          ]),
                          _: 2
                        }, 1024)
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
              });
              _push2(`<!--]-->`);
              if (unref(hasMoreNews)) {
                _push2(`<!--[-->`);
                if (!unref(isLoadMoreNews)) {
                  _push2(`<div class="my-2 flex flex-col sm:flex-row sm:justify-center flex-wrap gap-2"${_scopeId}><button type="button" class="dga-evote-btn w-full sm:w-48 inline-flex gap-2 items-center justify-center" title="Load More News"${_scopeId}>`);
                  _push2(ssrRenderComponent(_component_MaterialIcon, { icon: "autorenew" }, null, _parent2, _scopeId));
                  _push2(`<span class="truncate"${_scopeId}>Load More</span></button></div>`);
                } else {
                  _push2(`<div class="p-2 text-center italic"${_scopeId}>Loading...</div>`);
                }
                _push2(`<!--]-->`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div>`);
            } else {
              _push2(`<div class="p-2 text-center italic"${_scopeId}>News not found</div>`);
            }
          } else {
            return [
              unref(news).length > 0 ? (openBlock(), createBlock("div", {
                key: 0,
                class: "p-2 overflow-auto max-h-60"
              }, [
                (openBlock(true), createBlock(Fragment, null, renderList(unref(news), (data) => {
                  return openBlock(), createBlock(_component_NuxtLink, {
                    to: `/news/info/${data._id}`
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_BasicListItem, { "header-class": "w-44" }, {
                        header: withCtx(() => [
                          createTextVNode(toDisplayString(unref(formatDateTime)(data.newsPublishAt)) + ".", 1)
                        ]),
                        default: withCtx(() => [
                          createTextVNode(" " + toDisplayString(data.title), 1)
                        ]),
                        _: 2
                      }, 1024)
                    ]),
                    _: 2
                  }, 1032, ["to"]);
                }), 256)),
                unref(hasMoreNews) ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                  !unref(isLoadMoreNews) ? (openBlock(), createBlock("div", {
                    key: 0,
                    class: "my-2 flex flex-col sm:flex-row sm:justify-center flex-wrap gap-2"
                  }, [
                    createVNode("button", {
                      type: "button",
                      class: "dga-evote-btn w-full sm:w-48 inline-flex gap-2 items-center justify-center",
                      title: "Load More News",
                      onClick: loadMoreNews
                    }, [
                      createVNode(_component_MaterialIcon, { icon: "autorenew" }),
                      createVNode("span", { class: "truncate" }, "Load More")
                    ])
                  ])) : (openBlock(), createBlock("div", {
                    key: 1,
                    class: "p-2 text-center italic"
                  }, "Loading..."))
                ], 64)) : createCommentVNode("", true)
              ])) : (openBlock(), createBlock("div", {
                key: 1,
                class: "p-2 text-center italic"
              }, "News not found"))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="my-2 flex flex-col sm:flex-row sm:justify-center flex-wrap gap-2">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/topic/create",
        class: "w-full sm:w-48 block"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<button type="button" class="dga-evote-btn w-full inline-flex gap-2 items-center justify-center" title="\u0E15\u0E31\u0E49\u0E07\u0E42\u0E2B\u0E27\u0E15"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_MaterialIcon, { icon: "ballot" }, null, _parent2, _scopeId));
            _push2(`<span class="truncate"${_scopeId}>\u0E15\u0E31\u0E49\u0E07\u0E42\u0E2B\u0E27\u0E15</span></button>`);
          } else {
            return [
              createVNode("button", {
                type: "button",
                class: "dga-evote-btn w-full inline-flex gap-2 items-center justify-center",
                title: "\u0E15\u0E31\u0E49\u0E07\u0E42\u0E2B\u0E27\u0E15"
              }, [
                createVNode(_component_MaterialIcon, { icon: "ballot" }),
                createVNode("span", { class: "truncate" }, "\u0E15\u0E31\u0E49\u0E07\u0E42\u0E2B\u0E27\u0E15")
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/news/create",
        class: "w-full sm:w-48 block"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<button type="button" class="dga-evote-btn w-full inline-flex gap-2 items-center justify-center" title="\u0E15\u0E31\u0E49\u0E07\u0E01\u0E23\u0E30\u0E14\u0E32\u0E19\u0E02\u0E48\u0E32\u0E27"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_MaterialIcon, { icon: "newspaper" }, null, _parent2, _scopeId));
            _push2(`<span class="truncate"${_scopeId}>\u0E15\u0E31\u0E49\u0E07\u0E01\u0E23\u0E30\u0E14\u0E32\u0E19\u0E02\u0E48\u0E32\u0E27</span></button>`);
          } else {
            return [
              createVNode("button", {
                type: "button",
                class: "dga-evote-btn w-full inline-flex gap-2 items-center justify-center",
                title: "\u0E15\u0E31\u0E49\u0E07\u0E01\u0E23\u0E30\u0E14\u0E32\u0E19\u0E02\u0E48\u0E32\u0E27"
              }, [
                createVNode(_component_MaterialIcon, { icon: "newspaper" }),
                createVNode("span", { class: "truncate" }, "\u0E15\u0E31\u0E49\u0E07\u0E01\u0E23\u0E30\u0E14\u0E32\u0E19\u0E02\u0E48\u0E32\u0E27")
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<button type="button" class="dga-evote-btn w-full sm:w-48 inline-flex gap-2 items-center justify-center" title="\u0E2A\u0E25\u0E31\u0E1A\u0E42\u0E2B\u0E21\u0E14">`);
      _push(ssrRenderComponent(_component_MaterialIcon, { icon: "autorenew" }, null, _parent));
      _push(`<span class="truncate">\u0E2A\u0E25\u0E31\u0E1A\u0E42\u0E2B\u0E21\u0E14</span></button></div></div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=admin-0f479d95.mjs.map
