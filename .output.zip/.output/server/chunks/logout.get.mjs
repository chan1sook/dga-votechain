import { defineEventHandler, sendRedirect } from 'h3';
import { u as useRuntimeConfig } from './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'unstorage/drivers/redis';
import 'defu';
import 'radix3';
import 'mongoose';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'dayjs';
import 'nanoid';
import 'axios';

const logout_get = defineEventHandler(async (event) => {
  const userData = event.context.userData;
  if (!userData) {
    return sendRedirect(event, "/login");
  }
  const { idToken } = userData;
  const { DID_LOGOUT_CALLBACK, public: { DID_API_URL } } = useRuntimeConfig();
  const urlParams = new URLSearchParams();
  urlParams.set("id_token_hint", idToken);
  urlParams.set("post_logout_redirect_uri", DID_LOGOUT_CALLBACK);
  const url = new URL(`/connect/endsession?${urlParams}`, DID_API_URL);
  return sendRedirect(event, url.toString());
});

export { logout_get as default };
//# sourceMappingURL=logout.get.mjs.map
