const client_manifest = {
  "BasicCard.css": {
    "resourceType": "style",
    "file": "BasicCard.b00ab4e8.css",
    "src": "BasicCard.css"
  },
  "BasicListItem.css": {
    "resourceType": "style",
    "file": "BasicListItem.bb203c09.css",
    "src": "BasicListItem.css"
  },
  "DetailCard.css": {
    "resourceType": "style",
    "file": "DetailCard.5956d7f2.css",
    "src": "DetailCard.css"
  },
  "MaterialIcon.css": {
    "resourceType": "style",
    "file": "MaterialIcon.88d58c50.css",
    "src": "MaterialIcon.css"
  },
  "_BasicCard.06fc7be8.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "BasicCard.b00ab4e8.css"
    ],
    "file": "BasicCard.06fc7be8.js",
    "imports": [
      "__plugin-vue_export-helper.c27b6911.js",
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "BasicCard.b00ab4e8.css": {
    "file": "BasicCard.b00ab4e8.css",
    "resourceType": "style"
  },
  "_BasicListItem.3bdc0d73.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "BasicListItem.bb203c09.css"
    ],
    "file": "BasicListItem.3bdc0d73.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "__plugin-vue_export-helper.c27b6911.js"
    ]
  },
  "BasicListItem.bb203c09.css": {
    "file": "BasicListItem.bb203c09.css",
    "resourceType": "style"
  },
  "_DetailCard.f95db50b.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "DetailCard.5956d7f2.css"
    ],
    "file": "DetailCard.f95db50b.js",
    "imports": [
      "__plugin-vue_export-helper.c27b6911.js",
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "DetailCard.5956d7f2.css": {
    "file": "DetailCard.5956d7f2.css",
    "resourceType": "style"
  },
  "_MaterialIcon.c16f6bf8.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "MaterialIcon.88d58c50.css"
    ],
    "file": "MaterialIcon.c16f6bf8.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "__plugin-vue_export-helper.c27b6911.js"
    ]
  },
  "MaterialIcon.88d58c50.css": {
    "file": "MaterialIcon.88d58c50.css",
    "resourceType": "style"
  },
  "__plugin-vue_export-helper.c27b6911.js": {
    "resourceType": "script",
    "module": true,
    "file": "_plugin-vue_export-helper.c27b6911.js"
  },
  "_fetch.035cb748.js": {
    "resourceType": "script",
    "module": true,
    "file": "fetch.035cb748.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "_news.2dced499.js": {
    "resourceType": "script",
    "module": true,
    "file": "news.2dced499.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "_nuxt-link.8943ed35.js": {
    "resourceType": "script",
    "module": true,
    "file": "nuxt-link.8943ed35.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "_permissions.9caf66cc.js": {
    "resourceType": "script",
    "module": true,
    "file": "permissions.9caf66cc.js"
  },
  "_topic.18f68b32.js": {
    "resourceType": "script",
    "module": true,
    "file": "topic.18f68b32.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "_usePermissions.dd9a085b.js": {
    "resourceType": "script",
    "module": true,
    "file": "usePermissions.dd9a085b.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "_useUserId.cde1cac3.js": {
    "resourceType": "script",
    "module": true,
    "file": "useUserId.cde1cac3.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "middleware/auth-admin.ts": {
    "resourceType": "script",
    "module": true,
    "file": "auth-admin.e66ad3ce.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_fetch.035cb748.js",
      "_useUserId.cde1cac3.js",
      "_usePermissions.dd9a085b.js",
      "_permissions.9caf66cc.js"
    ],
    "isDynamicEntry": true,
    "src": "middleware/auth-admin.ts"
  },
  "middleware/auth-dev.ts": {
    "resourceType": "script",
    "module": true,
    "file": "auth-dev.bdd5f21c.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_fetch.035cb748.js",
      "_useUserId.cde1cac3.js",
      "_usePermissions.dd9a085b.js",
      "_permissions.9caf66cc.js"
    ],
    "isDynamicEntry": true,
    "src": "middleware/auth-dev.ts"
  },
  "middleware/auth-guest.ts": {
    "resourceType": "script",
    "module": true,
    "file": "auth-guest.58b704bb.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_fetch.035cb748.js",
      "_useUserId.cde1cac3.js",
      "_usePermissions.dd9a085b.js",
      "_permissions.9caf66cc.js"
    ],
    "isDynamicEntry": true,
    "src": "middleware/auth-guest.ts"
  },
  "middleware/auth-voter.ts": {
    "resourceType": "script",
    "module": true,
    "file": "auth-voter.ef6cbf66.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_fetch.035cb748.js",
      "_useUserId.cde1cac3.js",
      "_usePermissions.dd9a085b.js",
      "_permissions.9caf66cc.js"
    ],
    "isDynamicEntry": true,
    "src": "middleware/auth-voter.ts"
  },
  "node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "file": "entry.7fc7b232.css",
    "src": "node_modules/nuxt/dist/app/entry.css"
  },
  "node_modules/nuxt/dist/app/entry.mjs": {
    "resourceType": "script",
    "module": true,
    "css": [
      "entry.7fc7b232.css"
    ],
    "dynamicImports": [
      "middleware/auth-admin.ts",
      "middleware/auth-dev.ts",
      "middleware/auth-guest.ts",
      "middleware/auth-voter.ts",
      "virtual:nuxt:C:/Users/chan1/Desktop/dga_votechain_2/.nuxt/error-component.mjs"
    ],
    "file": "entry.1f1a3be4.js",
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.mjs"
  },
  "entry.7fc7b232.css": {
    "file": "entry.7fc7b232.css",
    "resourceType": "style"
  },
  "pages/admin.vue": {
    "resourceType": "script",
    "module": true,
    "file": "admin.39175974.js",
    "imports": [
      "_BasicListItem.3bdc0d73.js",
      "_nuxt-link.8943ed35.js",
      "_MaterialIcon.c16f6bf8.js",
      "_BasicCard.06fc7be8.js",
      "node_modules/nuxt/dist/app/entry.mjs",
      "_fetch.035cb748.js",
      "_usePermissions.dd9a085b.js",
      "_permissions.9caf66cc.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin.vue"
  },
  "pages/developer.vue": {
    "resourceType": "script",
    "module": true,
    "file": "developer.6153a9e6.js",
    "imports": [
      "_MaterialIcon.c16f6bf8.js",
      "_BasicListItem.3bdc0d73.js",
      "_nuxt-link.8943ed35.js",
      "_BasicCard.06fc7be8.js",
      "node_modules/nuxt/dist/app/entry.mjs",
      "_fetch.035cb748.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/developer.vue"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.66066b73.js",
    "imports": [
      "_BasicListItem.3bdc0d73.js",
      "_nuxt-link.8943ed35.js",
      "_MaterialIcon.c16f6bf8.js",
      "_BasicCard.06fc7be8.js",
      "node_modules/nuxt/dist/app/entry.mjs",
      "_fetch.035cb748.js",
      "_usePermissions.dd9a085b.js",
      "_permissions.9caf66cc.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "pages/login.vue": {
    "resourceType": "script",
    "module": true,
    "file": "login.124534d5.js",
    "imports": [
      "_MaterialIcon.c16f6bf8.js",
      "_nuxt-link.8943ed35.js",
      "node_modules/nuxt/dist/app/entry.mjs",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/login.vue"
  },
  "pages/news/create.vue": {
    "resourceType": "script",
    "module": true,
    "file": "create.9765c711.js",
    "imports": [
      "_MaterialIcon.c16f6bf8.js",
      "node_modules/nuxt/dist/app/entry.mjs",
      "_fetch.035cb748.js",
      "_news.2dced499.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/news/create.vue"
  },
  "pages/news/edit/[id].vue": {
    "resourceType": "script",
    "module": true,
    "file": "_id_.3f8e9e75.js",
    "imports": [
      "_MaterialIcon.c16f6bf8.js",
      "node_modules/nuxt/dist/app/entry.mjs",
      "_fetch.035cb748.js",
      "_news.2dced499.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/news/edit/[id].vue"
  },
  "pages/news/info/[id].vue": {
    "resourceType": "script",
    "module": true,
    "file": "_id_.6b61a7b0.js",
    "imports": [
      "_BasicListItem.3bdc0d73.js",
      "_MaterialIcon.c16f6bf8.js",
      "_nuxt-link.8943ed35.js",
      "node_modules/nuxt/dist/app/entry.mjs",
      "_fetch.035cb748.js",
      "_usePermissions.dd9a085b.js",
      "_permissions.9caf66cc.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/news/info/[id].vue"
  },
  "pages/permissions/approve.vue": {
    "resourceType": "script",
    "module": true,
    "file": "approve.6e101083.js",
    "imports": [
      "_MaterialIcon.c16f6bf8.js",
      "_BasicListItem.3bdc0d73.js",
      "_BasicCard.06fc7be8.js",
      "node_modules/nuxt/dist/app/entry.mjs",
      "_fetch.035cb748.js",
      "_permissions.9caf66cc.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/permissions/approve.vue"
  },
  "pages/permissions/request.vue": {
    "resourceType": "script",
    "module": true,
    "file": "request.99133854.js",
    "imports": [
      "_BasicListItem.3bdc0d73.js",
      "_MaterialIcon.c16f6bf8.js",
      "node_modules/nuxt/dist/app/entry.mjs",
      "_fetch.035cb748.js",
      "_permissions.9caf66cc.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/permissions/request.vue"
  },
  "pages/topic/create.vue": {
    "resourceType": "script",
    "module": true,
    "file": "create.2d086bff.js",
    "imports": [
      "_MaterialIcon.c16f6bf8.js",
      "node_modules/nuxt/dist/app/entry.mjs",
      "_fetch.035cb748.js",
      "_topic.18f68b32.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/topic/create.vue"
  },
  "pages/topic/edit/[id].vue": {
    "resourceType": "script",
    "module": true,
    "file": "_id_.847d3e67.js",
    "imports": [
      "_MaterialIcon.c16f6bf8.js",
      "node_modules/nuxt/dist/app/entry.mjs",
      "_fetch.035cb748.js",
      "_topic.18f68b32.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/topic/edit/[id].vue"
  },
  "pages/topic/info/[id].vue": {
    "resourceType": "script",
    "module": true,
    "file": "_id_.74aeef9b.js",
    "imports": [
      "_BasicListItem.3bdc0d73.js",
      "_MaterialIcon.c16f6bf8.js",
      "_nuxt-link.8943ed35.js",
      "node_modules/nuxt/dist/app/entry.mjs",
      "_fetch.035cb748.js",
      "_usePermissions.dd9a085b.js",
      "_topic.18f68b32.js",
      "_permissions.9caf66cc.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/topic/info/[id].vue"
  },
  "pages/topic/request.vue": {
    "resourceType": "script",
    "module": true,
    "file": "request.c92999a3.js",
    "imports": [
      "_MaterialIcon.c16f6bf8.js",
      "node_modules/nuxt/dist/app/entry.mjs",
      "_fetch.035cb748.js",
      "_topic.18f68b32.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/topic/request.vue"
  },
  "pages/topic/result/[id].vue": {
    "resourceType": "script",
    "module": true,
    "file": "_id_.a3b625bc.js",
    "imports": [
      "_DetailCard.f95db50b.js",
      "_BasicListItem.3bdc0d73.js",
      "_BasicCard.06fc7be8.js",
      "node_modules/nuxt/dist/app/entry.mjs",
      "_fetch.035cb748.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/topic/result/[id].vue"
  },
  "pages/tx/[id].vue": {
    "resourceType": "script",
    "module": true,
    "file": "_id_.c2712f83.js",
    "imports": [
      "_BasicListItem.3bdc0d73.js",
      "node_modules/nuxt/dist/app/entry.mjs",
      "_fetch.035cb748.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/tx/[id].vue"
  },
  "pages/vote/[id].css": {
    "resourceType": "style",
    "file": "_id_.36f4e13c.css",
    "src": "pages/vote/[id].css"
  },
  "pages/vote/[id].vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "_id_.9dd470a7.js",
    "imports": [
      "_DetailCard.f95db50b.js",
      "_MaterialIcon.c16f6bf8.js",
      "node_modules/nuxt/dist/app/entry.mjs",
      "_fetch.035cb748.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/vote/[id].vue"
  },
  "_id_.36f4e13c.css": {
    "file": "_id_.36f4e13c.css",
    "resourceType": "style"
  },
  "virtual:nuxt:C:/Users/chan1/Desktop/dga_votechain_2/.nuxt/error-component.css": {
    "resourceType": "style",
    "file": "error-component.a34db7f6.css",
    "src": "virtual:nuxt:C:/Users/chan1/Desktop/dga_votechain_2/.nuxt/error-component.css"
  },
  "virtual:nuxt:C:/Users/chan1/Desktop/dga_votechain_2/.nuxt/error-component.mjs": {
    "resourceType": "script",
    "module": true,
    "css": [
      "error-component.a34db7f6.css"
    ],
    "file": "error-component.4338fec9.js",
    "imports": [
      "_MaterialIcon.c16f6bf8.js",
      "node_modules/nuxt/dist/app/entry.mjs",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "virtual:nuxt:C:/Users/chan1/Desktop/dga_votechain_2/.nuxt/error-component.mjs"
  },
  "error-component.a34db7f6.css": {
    "file": "error-component.a34db7f6.css",
    "resourceType": "style"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
