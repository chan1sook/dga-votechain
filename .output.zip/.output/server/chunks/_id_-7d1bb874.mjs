import { _ as __nuxt_component_0 } from './BasicListItem-36ba5b36.mjs';
import { _ as __nuxt_component_2 } from './nuxt-link-c6bcda1e.mjs';
import { _ as __nuxt_component_0$1 } from './MaterialIcon-25e5e22f.mjs';
import { d as useRoute, u as useHead, w as webAppName, s as showError, f as formatDateTime } from './server.mjs';
import { defineComponent, computed, withAsyncContext, ref, mergeProps, unref, withCtx, createTextVNode, openBlock, createBlock, Fragment, toDisplayString, createVNode, useSSRContext } from 'vue';
import { u as useFetch } from './fetch-f8b573e2.mjs';
import { u as usePermissions } from './usePermissions-f45a7a74.mjs';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent, ssrRenderList } from 'vue/server-renderer';
import { c as checkPermissionNeeds } from './permissions-2a4aee66.mjs';
import './_plugin-vue_export-helper-cc2b3d55.mjs';
import 'ufo';
import 'ofetch';
import 'hookable';
import 'unctx';
import '@unhead/vue';
import '@unhead/dom';
import '@unhead/ssr';
import 'vue-router';
import 'h3';
import 'defu';
import 'dayjs';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'unstorage/drivers/redis';
import 'radix3';
import 'mongoose';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'nanoid';
import 'axios';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "[id]",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const { id } = useRoute().params;
    let newsid = Array.isArray(id) ? id[id.length - 1] : id;
    useHead({
      title: `${webAppName} - News #${newsid}`
    });
    const isAdminRole = computed(() => {
      return checkPermissionNeeds(usePermissions().value, "access-pages:admin");
    });
    const { data } = ([__temp, __restore] = withAsyncContext(() => useFetch(`/api/news/info/${newsid}`, "$Qv0cW0PiWN")), __temp = await __temp, __restore(), __temp);
    const news = ref(void 0);
    if (!data.value) {
      showError("News not found");
    } else {
      const { news: _news } = data.value;
      news.value = _news;
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_BasicListItem = __nuxt_component_0;
      const _component_NuxtLink = __nuxt_component_2;
      const _component_MaterialIcon = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "p-4 w-full mx-auto" }, _attrs))}>`);
      if (unref(news)) {
        _push(`<div class="border-2 border-gray-200 rounded-lg shadow p-4"><h1 class="text-3xl font-bold text-center mb-4">${ssrInterpolate(unref(webAppName))}</h1><h2 class="text-2xl font-bold text-center mb-0">${ssrInterpolate(unref(news).title)}</h2><div class="text-sm text-center text-gray-700 mb-4">#${ssrInterpolate(unref(newsid))}</div><div class="my-2">`);
        _push(ssrRenderComponent(_component_BasicListItem, { "header-class": "w-24" }, {
          header: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`Author`);
            } else {
              return [
                createTextVNode("Author")
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              if (unref(news).author) {
                _push2(`<!--[-->${ssrInterpolate(unref(news).author)}<!--]-->`);
              } else {
                _push2(`<span class="italic"${_scopeId}>Anonymous</span>`);
              }
            } else {
              return [
                unref(news).author ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                  createTextVNode(toDisplayString(unref(news).author), 1)
                ], 64)) : (openBlock(), createBlock("span", {
                  key: 1,
                  class: "italic"
                }, "Anonymous"))
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(ssrRenderComponent(_component_BasicListItem, { "header-class": "w-24" }, {
          header: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`Publish At`);
            } else {
              return [
                createTextVNode("Publish At")
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(` ${ssrInterpolate(unref(formatDateTime)(unref(news).newsPublishAt))}`);
            } else {
              return [
                createTextVNode(" " + toDisplayString(unref(formatDateTime)(unref(news).newsPublishAt)), 1)
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div><hr><div class="my-4"><!--[-->`);
        ssrRenderList(unref(news).content.split("\n"), (content) => {
          _push(`<p class="empty:my-4 peer-empty:my-0">${ssrInterpolate(content)}</p>`);
        });
        _push(`<!--]--></div><hr><div class="my-2">`);
        _push(ssrRenderComponent(_component_BasicListItem, { "header-class": "w-32" }, {
          header: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`References`);
            } else {
              return [
                createTextVNode("References")
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              if (unref(news).references) {
                _push2(`<!--[-->${ssrInterpolate(unref(news).references)}<!--]-->`);
              } else {
                _push2(`<span class="italic"${_scopeId}>None</span>`);
              }
            } else {
              return [
                unref(news).references ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                  createTextVNode(toDisplayString(unref(news).references), 1)
                ], 64)) : (openBlock(), createBlock("span", {
                  key: 1,
                  class: "italic"
                }, "None"))
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div><div class="my-2 flex flex-col sm:flex-row sm:justify-center flex-wrap gap-2">`);
        if (unref(isAdminRole)) {
          _push(ssrRenderComponent(_component_NuxtLink, {
            to: `/news/edit/${unref(newsid)}`,
            class: "w-full sm:w-64 block"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`<button type="button" class="dga-evote-btn w-full inline-flex gap-2 items-center justify-center" title="Edit News"${_scopeId}>`);
                _push2(ssrRenderComponent(_component_MaterialIcon, { icon: "edit" }, null, _parent2, _scopeId));
                _push2(`<span class="truncate"${_scopeId}>Edit News</span></button>`);
              } else {
                return [
                  createVNode("button", {
                    type: "button",
                    class: "dga-evote-btn w-full inline-flex gap-2 items-center justify-center",
                    title: "Edit News"
                  }, [
                    createVNode(_component_MaterialIcon, { icon: "edit" }),
                    createVNode("span", { class: "truncate" }, "Edit News")
                  ])
                ];
              }
            }),
            _: 1
          }, _parent));
        } else {
          _push(`<!---->`);
        }
        _push(`<button type="button" class="dga-evote-btn w-full sm:w-48 inline-flex gap-2 items-center justify-center" title="Back"><span class="truncate">Back</span></button></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/news/info/[id].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_id_-7d1bb874.mjs.map
