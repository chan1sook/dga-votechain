import { model, Schema, Types } from 'mongoose';

const schema = new Schema({
  name: {
    type: String,
    required: true
  },
  description: {
    type: String,
    required: true
  },
  status: {
    type: String,
    required: true
  },
  choices: {
    type: new Schema({
      choices: {
        type: [new Schema({
          name: {
            type: String,
            required: true
          },
          image: {
            type: String
          }
        })],
        required: true
      },
      customable: {
        type: Boolean,
        required: true
      }
    }),
    required: true
  },
  createdBy: {
    type: String,
    required: true
  },
  updatedBy: {
    type: String,
    required: true
  },
  voteStartAt: {
    type: Date,
    required: true
  },
  voteExpiredAt: {
    type: Date,
    required: true
  }
}, { timestamps: true });
schema.static("getLastestPendingTopics", function getLastestPendingTopics(pagesize, startid) {
  const query = {
    status: "pending",
    voteExpiredAt: { $gte: /* @__PURE__ */ new Date() }
  };
  if (startid) {
    query._id = { $lt: new Types.ObjectId(startid) };
  }
  return this.find(query).limit(pagesize || 50).sort({ _id: -1 });
});
schema.static("getLastestAvalaibleTopics", function getLastestAvalaibleTopics(pagesize, startid) {
  const query = {
    status: "approved",
    voteExpiredAt: { $gte: /* @__PURE__ */ new Date() }
  };
  if (startid) {
    query._id = { $lt: new Types.ObjectId(startid) };
  }
  return this.find(query).limit(pagesize || 50).sort({ _id: -1 });
});
schema.static("getLastestWaitingTopics", function getLastestWaitingTopics(pagesize, startid) {
  const query = {
    status: "approved",
    voteStartAt: { $gte: /* @__PURE__ */ new Date() }
  };
  if (startid) {
    query._id = { $lt: new Types.ObjectId(startid) };
  }
  return this.find(query).limit(pagesize || 50).sort({ _id: -1 });
});
schema.static("getLastestActiveTopics", function getLastestActiveTopics(pagesize, startid, excludedIds) {
  const query = {
    status: "approved",
    voteStartAt: { $lt: /* @__PURE__ */ new Date() },
    voteExpiredAt: { $gte: /* @__PURE__ */ new Date() }
  };
  if (Array.isArray(excludedIds)) {
    query._id = { $nin: excludedIds };
  }
  if (startid) {
    query._id = { $lt: new Types.ObjectId(startid) };
  }
  return this.find(query).limit(pagesize || 50).sort({ _id: -1 });
});
schema.static("getLastestFinishedTopics", function getLastestFinishedTopics(pagesize, startid) {
  const query = {
    status: "approved",
    voteExpiredAt: { $lt: /* @__PURE__ */ new Date() }
  };
  if (startid) {
    query._id = { $lt: new Types.ObjectId(startid) };
  }
  return this.find(query).limit(pagesize || 50).sort({ _id: -1 });
});
schema.static("getSelectedTopics", function getSelectedTopics(filterIds) {
  const query = {
    _id: { $in: filterIds }
  };
  return this.find(query).sort({ _id: -1 });
});
const TopicModel = model("topic", schema);

export { TopicModel as T };
//# sourceMappingURL=topic.mjs.map
