import { _ as __nuxt_component_0 } from './MaterialIcon-25e5e22f.mjs';
import { _ as __nuxt_component_2 } from './nuxt-link-c6bcda1e.mjs';
import { u as useHead, w as webAppName, b as useRuntimeConfig } from './server.mjs';
import { defineComponent, computed, mergeProps, unref, withCtx, createVNode, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent } from 'vue/server-renderer';
import './_plugin-vue_export-helper-cc2b3d55.mjs';
import 'ufo';
import 'ofetch';
import 'hookable';
import 'unctx';
import '@unhead/vue';
import '@unhead/dom';
import '@unhead/ssr';
import 'vue-router';
import 'h3';
import 'defu';
import 'dayjs';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'unstorage/drivers/redis';
import 'radix3';
import 'mongoose';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'nanoid';
import 'axios';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "login",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: `${webAppName} - Login`
    });
    const { DID_API_URL } = useRuntimeConfig();
    const registerUrl = computed(() => new URL("/Account/Register", DID_API_URL).toString());
    return (_ctx, _push, _parent, _attrs) => {
      const _component_MaterialIcon = __nuxt_component_0;
      const _component_NuxtLink = __nuxt_component_2;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "p-4 w-full max-w-3xl mx-auto" }, _attrs))}><div class="border-2 border-gray-200 rounded-lg shadow p-4"><h1 class="text-3xl font-bold text-center mb-4">${ssrInterpolate(unref(webAppName))}</h1><h2 class="text-2xl font-bold text-center mb-4"> Login </h2><div class="my-2 text-center"><a href="/api/login"><button type="button" class="dga-evote-btn w-full max-w-sm inline-flex gap-2 items-center justify-center" title="Login with Digital ID">`);
      _push(ssrRenderComponent(_component_MaterialIcon, { icon: "fingerprint" }, null, _parent));
      _push(`<span class="truncate">Login with Digital ID</span></button></a></div><div class="my-2 text-center">`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: unref(registerUrl) }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<button type="button" class="dga-evote-btn w-full max-w-sm inline-flex gap-2 items-center justify-center" title="Register"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_MaterialIcon, { icon: "how_to_reg" }, null, _parent2, _scopeId));
            _push2(`<span class="truncate"${_scopeId}>Register</span></button>`);
          } else {
            return [
              createVNode("button", {
                type: "button",
                class: "dga-evote-btn w-full max-w-sm inline-flex gap-2 items-center justify-center",
                title: "Register"
              }, [
                createVNode(_component_MaterialIcon, { icon: "how_to_reg" }),
                createVNode("span", { class: "truncate" }, "Register")
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/login.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=login-fb394a6d.mjs.map
