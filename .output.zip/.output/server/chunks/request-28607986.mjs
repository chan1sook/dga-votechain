import { _ as __nuxt_component_0 } from './BasicListItem-36ba5b36.mjs';
import { _ as __nuxt_component_0$1 } from './MaterialIcon-25e5e22f.mjs';
import { u as useHead, w as webAppName } from './server.mjs';
import { defineComponent, ref, computed, mergeProps, unref, withCtx, withDirectives, createVNode, vModelCheckbox, toDisplayString, createTextVNode, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderList, ssrRenderComponent, ssrIncludeBooleanAttr, ssrLooseContain, ssrRenderAttr } from 'vue/server-renderer';
import { a as getPresetPermissions, b as getRequestablePermissions, g as getFullPermissionTitle } from './permissions-2a4aee66.mjs';
import './_plugin-vue_export-helper-cc2b3d55.mjs';
import 'ofetch';
import 'hookable';
import 'unctx';
import '@unhead/vue';
import '@unhead/dom';
import '@unhead/ssr';
import 'vue-router';
import 'h3';
import 'ufo';
import 'defu';
import 'dayjs';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'unstorage/drivers/redis';
import 'radix3';
import 'mongoose';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'nanoid';
import 'axios';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "request",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: `${webAppName} - Request Permissions`
    });
    const permissionsData = ref({
      permissions: getPresetPermissions(),
      note: ""
    });
    const permissionEditable = ref(false);
    const consentPeronalId = ref(false);
    const isFormValid = computed(() => consentPeronalId.value && permissionsData.value.permissions.length > 0);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_BasicListItem = __nuxt_component_0;
      const _component_MaterialIcon = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "p-4 w-full mx-auto" }, _attrs))}><div class="border-2 border-gray-200 rounded-lg shadow p-4"><h1 class="text-3xl font-bold text-center mb-4">${ssrInterpolate(unref(webAppName))}</h1><h2 class="text-2xl font-bold text-center mb-4"> Request Permissions </h2><div class="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-7xl mx-auto my-4"><div class="md:col-span-2 p-2 pb-0 flex flex-row items-start gap-2"><label class="flex-none">Note for approver</label><textarea class="dga-evote-input w-0 flex-1 h-32" placeholder="Note">${ssrInterpolate(unref(permissionsData).note)}</textarea></div><div class="md:col-span-2 p-2 pb-0 flex flex-row items-center gap-2"><label class="flex-none">Presets Permissions</label><select class="dga-evote-input w-0 flex-1"><option value="admin">Admin</option><option value="developer">Developer</option><option value="custom">Custom</option></select></div><div class="md:col-span-2"><!--[-->`);
      ssrRenderList(unref(getRequestablePermissions)(), (permission) => {
        _push(ssrRenderComponent(_component_BasicListItem, { "no-animation": "" }, {
          header: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<input${ssrIncludeBooleanAttr(Array.isArray(unref(permissionsData).permissions) ? ssrLooseContain(unref(permissionsData).permissions, permission) : unref(permissionsData).permissions) ? " checked" : ""} type="checkbox"${ssrRenderAttr("value", permission)}${ssrIncludeBooleanAttr(!unref(permissionEditable)) ? " disabled" : ""} class="scale-125"${_scopeId}>`);
            } else {
              return [
                withDirectives(createVNode("input", {
                  "onUpdate:modelValue": ($event) => unref(permissionsData).permissions = $event,
                  type: "checkbox",
                  value: permission,
                  disabled: !unref(permissionEditable),
                  class: "scale-125"
                }, null, 8, ["onUpdate:modelValue", "value", "disabled"]), [
                  [vModelCheckbox, unref(permissionsData).permissions]
                ])
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<b${_scopeId}>${ssrInterpolate(permission)}</b> ${ssrInterpolate(unref(getFullPermissionTitle)(permission))}`);
            } else {
              return [
                createVNode("b", null, toDisplayString(permission), 1),
                createTextVNode(" " + toDisplayString(unref(getFullPermissionTitle)(permission)), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
      });
      _push(`<!--]--></div><div class="md:col-span-2 my-2 text-center"><input${ssrIncludeBooleanAttr(Array.isArray(unref(consentPeronalId)) ? ssrLooseContain(unref(consentPeronalId), null) : unref(consentPeronalId)) ? " checked" : ""} type="checkbox" class="scale-125" required> Allow to use Digital ID for Request Permissions </div><div class="md:col-span-2 my-2 text-center"><button type="button" class="dga-evote-btn w-full max-w-sm inline-flex gap-2 items-center justify-center" title="Request Permissions"${ssrIncludeBooleanAttr(!unref(isFormValid)) ? " disabled" : ""}>`);
      _push(ssrRenderComponent(_component_MaterialIcon, { icon: "ballot" }, null, _parent));
      _push(`<span class="truncate">Request Permissions</span></button></div></div></div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/permissions/request.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=request-28607986.mjs.map
