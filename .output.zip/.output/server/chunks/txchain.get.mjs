import { defineEventHandler, getQuery } from 'h3';
import dayjs from 'dayjs';
import { V as VoteModel } from './vote.mjs';
import 'mongoose';

const txchain_get = defineEventHandler(async (event) => {
  const { keyword, pagesize, startid } = getQuery(event);
  const txDocs = await VoteModel.getLastestVotes(pagesize, startid, keyword);
  const txChain = txDocs.map((tx) => {
    return {
      _id: `${tx._id}`,
      userid: tx.userid,
      topicid: `${tx.topicid}`,
      choice: tx.choice,
      createdAt: dayjs(tx.createdAt).toString()
    };
  });
  return {
    txChain
  };
});

export { txchain_get as default };
//# sourceMappingURL=txchain.get.mjs.map
