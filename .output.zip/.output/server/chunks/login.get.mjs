import { defineEventHandler, sendRedirect } from 'h3';
import crypto from 'crypto';
import { u as useRuntimeConfig } from './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'unstorage/drivers/redis';
import 'defu';
import 'radix3';
import 'mongoose';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'dayjs';
import 'nanoid';
import 'axios';

const login_get = defineEventHandler(async (event) => {
  const { DID_CLIENT_KEY, DID_LOGIN_CALLBACK, DID_VERIFY_CODE, public: { DID_API_URL } } = useRuntimeConfig();
  const urlParams = new URLSearchParams();
  urlParams.set("response_type", "code");
  urlParams.set("client_id", DID_CLIENT_KEY);
  urlParams.set("redirect_uri", DID_LOGIN_CALLBACK);
  const scopes = [
    "openid",
    "user_id",
    "citizen_id",
    "given_name",
    "email",
    "middle_name",
    "family_name"
  ];
  urlParams.set("scope", scopes.join(" "));
  urlParams.set("code_challenge_method", "S256");
  const hash = crypto.createHash("sha256").update(DID_VERIFY_CODE).digest();
  const challengeCode = hash.toString("base64url");
  urlParams.set("code_challenge", challengeCode);
  const url = new URL(`/connect/authorize?${urlParams}`, DID_API_URL);
  return sendRedirect(event, url.toString());
});

export { login_get as default };
//# sourceMappingURL=login.get.mjs.map
