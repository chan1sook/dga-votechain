import { _ as __nuxt_component_1 } from './BasicCard-350a4da3.mjs';
import { _ as __nuxt_component_0 } from './MaterialIcon-25e5e22f.mjs';
import { _ as __nuxt_component_2 } from './nuxt-link-c6bcda1e.mjs';
import { _ as __nuxt_component_0$1 } from './BasicListItem-36ba5b36.mjs';
import { u as useHead, w as webAppName } from './server.mjs';
import { defineComponent, ref, computed, watch, withAsyncContext, mergeProps, unref, withCtx, createTextVNode, toDisplayString, createVNode, withDirectives, isRef, vModelText, openBlock, createBlock, Fragment, renderList, createCommentVNode, useSSRContext } from 'vue';
import { u as useFetch } from './fetch-f8b573e2.mjs';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent, ssrRenderAttr, ssrRenderList } from 'vue/server-renderer';
import debounce from 'debounce';
import './_plugin-vue_export-helper-cc2b3d55.mjs';
import 'ufo';
import 'ofetch';
import 'hookable';
import 'unctx';
import '@unhead/vue';
import '@unhead/dom';
import '@unhead/ssr';
import 'vue-router';
import 'h3';
import 'defu';
import 'dayjs';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'unstorage/drivers/redis';
import 'radix3';
import 'mongoose';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'nanoid';
import 'axios';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "developer",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    useHead({
      title: `${webAppName} - Developer Page`
    });
    const txArr = ref([]);
    const pagesize = ref(50);
    const startid = computed(() => txArr.value.length > 0 ? txArr.value[txArr.value.length - 1]._id : void 0);
    const hasMoreTx = ref(false);
    const isLoadMoreTx = ref(false);
    const searchKeyword = ref("");
    const actualSearchKeyword = ref("");
    const searching = ref(false);
    const searchFunction = debounce(async (keyword) => {
      searching.value = true;
      actualSearchKeyword.value = keyword;
      txArr.value = [];
      hasMoreTx.value = false;
      await loadMoreTx();
      searching.value = false;
    }, 500);
    watch(searchKeyword, searchFunction);
    async function fetchTxFiltered(keyword, pagesize2, startid2) {
      const fetchResult = await Promise.all([
        useFetch("/api/txchain", {
          query: { keyword, pagesize: pagesize2, startid: startid2 }
        }, "$5Sij3Sbavf")
      ]);
      const [txDocs] = fetchResult.map((ele) => ele.data.value);
      return txDocs;
    }
    async function loadMoreTx() {
      isLoadMoreTx.value = true;
      const txChain = await fetchTxFiltered(actualSearchKeyword.value, pagesize.value, startid.value);
      if (txChain) {
        txArr.value.push(...txChain.txChain);
        hasMoreTx.value = txChain.txChain.length === pagesize.value;
      }
      isLoadMoreTx.value = false;
    }
    [__temp, __restore] = withAsyncContext(() => loadMoreTx()), await __temp, __restore();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_BasicCard = __nuxt_component_1;
      const _component_MaterialIcon = __nuxt_component_0;
      const _component_NuxtLink = __nuxt_component_2;
      const _component_BasicListItem = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "p-4 w-full mx-auto" }, _attrs))}><div class="border-2 border-gray-200 rounded-lg shadow p-4"><h1 class="text-3xl font-bold text-center mb-4">${ssrInterpolate(unref(webAppName))}</h1><h2 class="text-2xl font-bold text-center mb-4"> Developer </h2><div class="grid grid-cols-1 gap-4 max-w-7xl mx-auto my-4">`);
      _push(ssrRenderComponent(_component_BasicCard, null, {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Monitor Chain`);
          } else {
            return [
              createTextVNode("Monitor Chain")
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="p-2 pb-0 flex flex-row items-center gap-2"${_scopeId}><label class="flex-none"${_scopeId}>Search</label><div class="flex-1 inline-flex flex-row"${_scopeId}><input${ssrRenderAttr("value", unref(searchKeyword))} type="search" class="dga-evote-input rounded-r-none w-0 flex-1" placeholder="TX/ID Search"${_scopeId}><button type="button" class="dga-evote-btn px-2 py-1 rounded-l-none rounded-r-md inline-flex flex-row items-center" title="Search"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_MaterialIcon, { icon: "search" }, null, _parent2, _scopeId));
            _push2(`</button></div></div>`);
            if (unref(searching)) {
              _push2(`<div class="p-2 text-center"${_scopeId}>Searching</div>`);
            } else if (unref(txArr).length === 0) {
              _push2(`<div class="p-2 text-center italic"${_scopeId}>Not found [${ssrInterpolate(unref(actualSearchKeyword))}]</div>`);
            } else {
              _push2(`<div class="p-2 overflow-auto max-h-60"${_scopeId}><!--[-->`);
              ssrRenderList(unref(txArr), (tx) => {
                _push2(ssrRenderComponent(_component_NuxtLink, {
                  to: `/tx/${tx._id}`
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(ssrRenderComponent(_component_BasicListItem, { "header-class": "w-64" }, {
                        header: withCtx((_3, _push4, _parent4, _scopeId3) => {
                          if (_push4) {
                            _push4(`#${ssrInterpolate(tx._id)}`);
                          } else {
                            return [
                              createTextVNode("#" + toDisplayString(tx._id), 1)
                            ];
                          }
                        }),
                        default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                          if (_push4) {
                            _push4(`<div class="flex flex-col"${_scopeId3}><div class="truncate"${_scopeId3}>User #${ssrInterpolate(tx.userid)}</div><div class="truncate"${_scopeId3}>=&gt; Topic #${ssrInterpolate(tx.topicid)}</div><div class="truncate"${_scopeId3}>=&gt; Choose [${ssrInterpolate(tx.choice)}]</div></div>`);
                          } else {
                            return [
                              createVNode("div", { class: "flex flex-col" }, [
                                createVNode("div", { class: "truncate" }, "User #" + toDisplayString(tx.userid), 1),
                                createVNode("div", { class: "truncate" }, "=> Topic #" + toDisplayString(tx.topicid), 1),
                                createVNode("div", { class: "truncate" }, "=> Choose [" + toDisplayString(tx.choice) + "]", 1)
                              ])
                            ];
                          }
                        }),
                        _: 2
                      }, _parent3, _scopeId2));
                    } else {
                      return [
                        createVNode(_component_BasicListItem, { "header-class": "w-64" }, {
                          header: withCtx(() => [
                            createTextVNode("#" + toDisplayString(tx._id), 1)
                          ]),
                          default: withCtx(() => [
                            createVNode("div", { class: "flex flex-col" }, [
                              createVNode("div", { class: "truncate" }, "User #" + toDisplayString(tx.userid), 1),
                              createVNode("div", { class: "truncate" }, "=> Topic #" + toDisplayString(tx.topicid), 1),
                              createVNode("div", { class: "truncate" }, "=> Choose [" + toDisplayString(tx.choice) + "]", 1)
                            ])
                          ]),
                          _: 2
                        }, 1024)
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
              });
              _push2(`<!--]-->`);
              if (!unref(searching) && unref(hasMoreTx)) {
                _push2(`<!--[-->`);
                if (!unref(isLoadMoreTx)) {
                  _push2(`<div class="my-2 flex flex-col sm:flex-row sm:justify-center flex-wrap gap-2"${_scopeId}><button type="button" class="dga-evote-btn w-full sm:w-48 inline-flex gap-2 items-center justify-center" title="Load More TX"${_scopeId}>`);
                  _push2(ssrRenderComponent(_component_MaterialIcon, { icon: "autorenew" }, null, _parent2, _scopeId));
                  _push2(`<span class="truncate"${_scopeId}>Load More TX</span></button></div>`);
                } else {
                  _push2(`<div class="p-2 text-center italic"${_scopeId}>Loading...</div>`);
                }
                _push2(`<!--]-->`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div>`);
            }
          } else {
            return [
              createVNode("div", { class: "p-2 pb-0 flex flex-row items-center gap-2" }, [
                createVNode("label", { class: "flex-none" }, "Search"),
                createVNode("div", { class: "flex-1 inline-flex flex-row" }, [
                  withDirectives(createVNode("input", {
                    "onUpdate:modelValue": ($event) => isRef(searchKeyword) ? searchKeyword.value = $event : null,
                    type: "search",
                    class: "dga-evote-input rounded-r-none w-0 flex-1",
                    placeholder: "TX/ID Search"
                  }, null, 8, ["onUpdate:modelValue"]), [
                    [vModelText, unref(searchKeyword)]
                  ]),
                  createVNode("button", {
                    type: "button",
                    class: "dga-evote-btn px-2 py-1 rounded-l-none rounded-r-md inline-flex flex-row items-center",
                    title: "Search"
                  }, [
                    createVNode(_component_MaterialIcon, { icon: "search" })
                  ])
                ])
              ]),
              unref(searching) ? (openBlock(), createBlock("div", {
                key: 0,
                class: "p-2 text-center"
              }, "Searching")) : unref(txArr).length === 0 ? (openBlock(), createBlock("div", {
                key: 1,
                class: "p-2 text-center italic"
              }, "Not found [" + toDisplayString(unref(actualSearchKeyword)) + "]", 1)) : (openBlock(), createBlock("div", {
                key: 2,
                class: "p-2 overflow-auto max-h-60"
              }, [
                (openBlock(true), createBlock(Fragment, null, renderList(unref(txArr), (tx) => {
                  return openBlock(), createBlock(_component_NuxtLink, {
                    to: `/tx/${tx._id}`
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_BasicListItem, { "header-class": "w-64" }, {
                        header: withCtx(() => [
                          createTextVNode("#" + toDisplayString(tx._id), 1)
                        ]),
                        default: withCtx(() => [
                          createVNode("div", { class: "flex flex-col" }, [
                            createVNode("div", { class: "truncate" }, "User #" + toDisplayString(tx.userid), 1),
                            createVNode("div", { class: "truncate" }, "=> Topic #" + toDisplayString(tx.topicid), 1),
                            createVNode("div", { class: "truncate" }, "=> Choose [" + toDisplayString(tx.choice) + "]", 1)
                          ])
                        ]),
                        _: 2
                      }, 1024)
                    ]),
                    _: 2
                  }, 1032, ["to"]);
                }), 256)),
                !unref(searching) && unref(hasMoreTx) ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                  !unref(isLoadMoreTx) ? (openBlock(), createBlock("div", {
                    key: 0,
                    class: "my-2 flex flex-col sm:flex-row sm:justify-center flex-wrap gap-2"
                  }, [
                    createVNode("button", {
                      type: "button",
                      class: "dga-evote-btn w-full sm:w-48 inline-flex gap-2 items-center justify-center",
                      title: "Load More TX",
                      onClick: loadMoreTx
                    }, [
                      createVNode(_component_MaterialIcon, { icon: "autorenew" }),
                      createVNode("span", { class: "truncate" }, "Load More TX")
                    ])
                  ])) : (openBlock(), createBlock("div", {
                    key: 1,
                    class: "p-2 text-center italic"
                  }, "Loading..."))
                ], 64)) : createCommentVNode("", true)
              ]))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="my-2 flex flex-col sm:flex-row sm:justify-center flex-wrap gap-2">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/permissions/approve",
        class: "w-full sm:w-72 block"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<button type="button" class="dga-evote-btn w-full inline-flex gap-2 items-center justify-center" title="\u0E15\u0E31\u0E49\u0E07\u0E42\u0E2B\u0E27\u0E15"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_MaterialIcon, { icon: "how_to_reg" }, null, _parent2, _scopeId));
            _push2(`<span class="truncate"${_scopeId}>Approve Permissions</span></button>`);
          } else {
            return [
              createVNode("button", {
                type: "button",
                class: "dga-evote-btn w-full inline-flex gap-2 items-center justify-center",
                title: "\u0E15\u0E31\u0E49\u0E07\u0E42\u0E2B\u0E27\u0E15"
              }, [
                createVNode(_component_MaterialIcon, { icon: "how_to_reg" }),
                createVNode("span", { class: "truncate" }, "Approve Permissions")
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<button type="button" class="dga-evote-btn w-full sm:w-48 inline-flex gap-2 items-center justify-center" title="\u0E2A\u0E25\u0E31\u0E1A\u0E42\u0E2B\u0E21\u0E14">`);
      _push(ssrRenderComponent(_component_MaterialIcon, { icon: "autorenew" }, null, _parent));
      _push(`<span class="truncate">\u0E2A\u0E25\u0E31\u0E1A\u0E42\u0E2B\u0E21\u0E14</span></button></div></div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/developer.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=developer-e999cb7f.mjs.map
