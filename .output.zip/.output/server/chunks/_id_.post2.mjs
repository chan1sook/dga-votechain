import { defineEventHandler, createError, readBody } from 'h3';
import { a as checkPermissionSelections, i as isContainsAdvancePermissions, c as checkPermissionNeeds, U as UserModel, r as removePermissions } from './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'unstorage/drivers/redis';
import 'defu';
import 'radix3';
import 'mongoose';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'dayjs';
import 'nanoid';
import 'axios';

const _id__post = defineEventHandler(async (event) => {
  var _a;
  const userData = event.context.userData;
  if (!userData || !checkPermissionSelections(userData.permissions, "change-permissions:basic", "change-permissions:advance")) {
    throw createError({
      statusCode: 403,
      statusMessage: "Forbidden"
    });
  }
  const { permissions } = await readBody(event);
  if (isContainsAdvancePermissions(...permissions) && !checkPermissionNeeds(userData.permissions, "change-permissions:advance")) {
    throw createError({
      statusCode: 403,
      statusMessage: "Forbidden"
    });
  }
  const userDoc = await UserModel.findById((_a = event.context.params) == null ? void 0 : _a.id);
  if (!userDoc) {
    throw createError({
      statusCode: 400,
      statusMessage: "User not found"
    });
  }
  userDoc.permissions = removePermissions(userDoc.permissions, ...permissions);
  await userDoc.save();
  if (userData.userid === userDoc.userid) {
    userData.permissions = userDoc.permissions;
  }
  const permissionsResponse = {
    userid: userDoc.userid,
    permissions: userDoc.permissions
  };
  return {
    permissionsResponse
  };
});

export { _id__post as default };
//# sourceMappingURL=_id_.post2.mjs.map
