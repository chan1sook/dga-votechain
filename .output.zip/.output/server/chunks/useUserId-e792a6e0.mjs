import { h as useState } from './server.mjs';

const useUserId = () => {
  return useState("userId", () => void 0);
};

export { useUserId as u };
//# sourceMappingURL=useUserId-e792a6e0.mjs.map
