import dayjs from 'dayjs';

function isTopicFormValid(topicData) {
  const voteStartAt = dayjs(topicData.voteStartAt);
  const voteExpiredAt = dayjs(topicData.voteExpiredAt);
  return topicData.name !== "" && topicData.description !== "" && topicData.choices.choices.every((ele) => ele.name) && voteStartAt.isValid() && voteExpiredAt.isValid() && voteStartAt.valueOf() < voteExpiredAt.valueOf();
}
function isTopicExpired(topic) {
  return Date.now() >= dayjs(topic.voteExpiredAt).valueOf();
}

export { isTopicFormValid as a, isTopicExpired as i };
//# sourceMappingURL=topic2.mjs.map
